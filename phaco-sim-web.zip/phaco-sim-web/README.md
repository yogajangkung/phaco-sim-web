# Phaco Sim 3D — versi Web (HTML · CSS · JavaScript · three.js)

Port penuh dari proyek Godot `phaco-sim` (lihat `ARSITEKTUR.md`) ke web: simulator edukasi
**fakoemulsifikasi katarak 11 langkah** dengan model mata 3D prosedural dan instrumen bedah di
**three.js r160** (disertakan lokal di `vendor/`, jadi tetap jalan tanpa internet).

> ⚠️ Untuk edukasi/latihan keterampilan saja — **bukan alat medis**.

## Menjalankan

ES modules tidak bisa dibuka lewat `file://`, jadi pakai server lokal:

```bash
cd ~/phaco-sim-web
./serve.sh            # http://localhost:8090  (port lain: ./serve.sh 9000)
```

**Di HP (satu Wi-Fi dengan laptop):** `./serve.sh` mencetak alamat LAN, mis. `http://192.168.1.10:8090`.
Buka di Chrome Android → menu ⋮ → *Add to Home screen* agar tampil layar penuh landscape (PWA).
Catatan: lewat `http://` non-localhost, audio memakai fallback `ScriptProcessor` (tetap bunyi);
getaran memakai Vibration API (Android; iOS tidak mendukung getar).

## Kontrol

| Fungsi | Layar sentuh | Keyboard |
|---|---|---|
| Instrumen utama (kanan) | Joystick kanan bawah | `W A S D` |
| Kedalaman kanan | Slider di kiri joystick kanan | `R` naik / `F` turun |
| Instrumen kedua (kiri) | Joystick kiri bawah | Panah |
| Kedalaman kiri | Slider di kanan joystick kiri | `O` / `L` |
| Foot pedal 0–3 | Slider vertikal tepi kiri | `0` `1` `2` `3` |
| Reflux | Tombol REFLUX | `Spasi` |
| Aksi kontekstual | Tombol kanan atas | `Z X C V` |
| Gerak halus | HALUS | `G` |
| Lanjut langkah | LANJUT | `Enter` |
| Ganti kamera | Tombol kamera; drag area kosong = orbit | `Tab` |

Multitouch penuh (Pointer Events): dua joystick + pedal + tombol bisa dipakai bersamaan.

## Struktur

```
index.html, css/style.css, manifest.webmanifest, vendor/three.module.js
js/
├─ main.js                 composition root + loop (setAnimationLoop)
├─ core/                   math (V2/V3 bernilai), anatomy, case_state, step_base,
│                          procedure_state_machine, safety_monitor, complication_manager, score_tracker
├─ sim/                    foot_pedal, fluidics (lumped-parameter), nucleus_model (height-field 32×32)
├─ steps/                  11 langkah (incision_step = basis paracentesis & CCI)
├─ eye/                    eye_model (hierarki anatomi), nucleus_renderer, mesh_factory, shaders (GLSL)
├─ instruments/            instrument (9 jenis, pivot di insisi), instrument_rig (2 tangan + bayangan tip)
├─ camera/                 surgical_camera (mikroskop, miring 35°, potongan, orbit)
├─ input/controls.js       joystick, slider, tombol (multitouch)
├─ feedback/               haptics (navigator.vibrate), phaco_audio (AudioWorklet synth)
├─ ui/                     hud, telemetry_panel, cross_section_view
└─ dev/smoke.js            uji otomatis
```

Pemetaan dari Godot 1:1: tiap `.gd` → modul `.js` dengan nama & logika yang sama; `.gdshader` →
`ShaderMaterial` GLSL di `js/eye/shaders.js` (uniform global `cutaway` & `time` dibagi semua shader).
`CaseState` tetap satu-satunya sumber kebenaran; visual hanya membaca state tiap frame.

## Uji & mode dev

- `index.html?smoke` — fuzz semua langkah (D&C dan Chop) + skenario deterministik
  (kapsulorheksis 360°, PCR, sculpt alur, post-occlusion surge) + skip sampai laporan.
  Hasil di judul tab (`SMOKE PASS/FAIL`) dan console.
- `index.html?step=7&view=oblique` — langsung ke langkah N (sandbox); `view` = `scope|oblique|side|orbit`.

## Perbedaan kecil vs versi Godot

- Blur fokus & masker lapang mikroskop memakai CSS (`filter: blur`, radial-gradient), bukan shader layar.
- Getaran tanpa kontrol amplitudo (Web API hanya durasi); intensitas dipetakan ke durasi.
- Laporan debriefing bisa diunduh sebagai JSON.
- Perbaikan bug dari versi asli: korteks perifer kini terlihat (shader lama memakai radius lokal
  yang belum diskalakan), rotasi nukleus tidak lagi memicu rebuild mesh.
