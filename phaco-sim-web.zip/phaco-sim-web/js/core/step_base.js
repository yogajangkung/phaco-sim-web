// StepBase — kelas dasar setiap langkah prosedur.
//
// Siklus hidup (dipanggil ProcedureStateMachine):
//   bind(sim) -> [applyIdeal() untuk fast-forward sandbox]
//   enter() -> update(dt, input) tiap frame -> canFinish()? -> exit()
//   computeQuality() dipanggil saat langkah selesai untuk laporan.
//
// Input per frame:
//   rs, ls : V2   joystick kanan/kiri (-1..1, y+ = ke bawah layar)
//   rd, ld : num  slider kedalaman (-1..1, + = naik/anterior)
//   pedal  : num  target pedal 0..1
//   reflux, fine : bool
//   held / pressed : {action_id: bool}
import { SafetyMonitor } from './safety_monitor.js';
import { clamp } from './math.js';

export class StepBase {
  constructor() {
    this.index = 0;
    this.title = '';
    this.short_title = '';
    this.target_time = 60;
    this.elapsed = 0;
    this.objectives = [];
    this.actions = [];
    this.actions_version = 0;
    this.uses_pedal = false;
    this.pedal_label = 'PEDAL';
    this.right_label = '';
    this.left_label = '';
    this.hint = '';
    this.phase = '';
    this.notes = [];
    this.show_pedal_settings = false;
  }

  bind(sim) {
    this.sim = sim;
    this.cs = sim.caseState;
    this.fluidics = sim.fluidics;
    this.pedal = sim.pedal;
    this.rig = sim.rig;
    this.comp = sim.complications;
    this.haptics = sim.haptics;
    this.safety = sim.safety;
  }

  resetRuntime() {
    this.elapsed = 0;
    this.objectives = [];
    this.notes = [];
    this.phase = '';
    this.hint = '';
    this.uses_pedal = false;
    this.pedal_label = 'PEDAL';
    this.show_pedal_settings = false;
    this.right_label = '';
    this.left_label = '';
    this.setActions([]);
  }

  // ---------- dioverride langkah turunan ----------
  enter() {}
  update(_dt, _input) {}
  exit() { this.rig.removeAll(); }
  applyIdeal() {}
  computeQuality() { return 100; }
  telemetryExtra() { return ''; }

  // ---------- helper ----------
  canFinish() { return this.objectives.every((o) => o.done); }

  setActions(list) {
    this.actions = list;
    this.actions_version++;
  }

  obj(key, text) { this.objectives.push({ key, text, done: false, detail: '' }); }

  setDone(key, v = true, detail = '') {
    const o = this.objectives.find((x) => x.key === key);
    if (!o) return;
    if (v && !o.done) this.haptics.tick();
    o.done = v;
    if (detail !== '') o.detail = detail;
  }

  isDone(key) { return this.objectives.find((x) => x.key === key)?.done ?? false; }

  setDetail(key, detail) {
    const o = this.objectives.find((x) => x.key === key);
    if (o) o.detail = detail;
  }

  note(text) { if (!this.notes.includes(text)) this.notes.push(text); }

  /** Gerakkan instrumen dengan joystick + slider, lalu terapkan batas anatomi. */
  moveTool(t, stick, depth, dt, fine, ctx = {}) {
    const desired = t.tip.add(SafetyMonitor.moveVector(stick, depth, dt, fine));
    ctx.dt = dt;
    return this.safety.constrain(t, desired, ctx);
  }

  held(input, id) { return !!input.held[id]; }
  pressed(input, id) { return !!input.pressed[id]; }

  /** Penalti kualitas dari kejadian komplikasi selama langkah ini. */
  eventPenalty() {
    return this.comp.eventsInStep(this.title).reduce((p, e) => p + e.penalty * 0.6, 0);
  }

  /** 100 di dalam [idealLo, idealHi], turun linear ke 0 di hardLo / hardHi. */
  static scoreBand(value, idealLo, idealHi, hardLo, hardHi) {
    if (value >= idealLo && value <= idealHi) return 100;
    if (value < idealLo) return clamp((value - hardLo) / Math.max(idealLo - hardLo, 0.0001), 0, 1) * 100;
    return clamp((hardHi - value) / Math.max(hardHi - idealHi, 0.0001), 0, 1) * 100;
  }
}

export const scoreBand = StepBase.scoreBand;
