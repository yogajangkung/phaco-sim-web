// CaseState — seluruh state pasien/mata yang bisa berubah selama prosedur.
// Satu-satunya sumber kebenaran: visual (EyeModel) hanya membaca state ini setiap frame,
// sehingga sandbox/step-jump cukup memanggil step.applyIdeal().
import * as A from './anatomy.js';
import { V2, V3, clamp, lerp, fposmod } from './math.js';
import { NucleusModel } from '../sim/nucleus_model.js';

export const RHEXIS_BINS = 64;
export const CORTEX_SECTORS = 24;

export class CaseState {
  constructor() {
    this.nucleus_grade = 2;      // 1 = lunak, 4 = keras/brunescent
    this.technique = 'dc';       // "dc" = Divide & Conquer, "chop" = Phaco Chop
    this.pupil_r = A.PUPIL_DILATED_R;
    this.planned_main_deg = 180;
    this.nucleus = new NucleusModel();
    this.reset();
  }

  reset() {
    this.anesthesia = false;
    this.speculum = false;
    this.lid_open = 0.35;
    this.scope_offset = new V2(2.2, -1.6);
    this.scope_focus = 6.0;
    /** {name, angle, tunnel, outer:V3, inner:V3, sealed, width} */
    this.incisions = [];
    this.ovd_ac = 0;
    this.ovd_bag = 0;
    this.aqueous = 1;
    this.rhexis_done = false;
    this.rhexis_r = new Float32Array(RHEXIS_BINS);
    this.rhexis_path = [];
    this.rhexis_flap = false;
    this.rhexis_tear_deg = -1;
    this.capsule_nicks = 0;
    this.hydro_dissection = 0;
    this.hydro_delineation = 0;
    this.hydro_sites = [];
    this.bag_pressure = 0;
    this.nucleus_free = false;
    this.nucleus.setup(this.nucleus_grade);
    this.epi_mass = 1;
    this.cortex = new Float32Array(CORTEX_SECTORS).fill(1);
    this.phaco_cde = 0;
    this.iol_present = false;
    this.iol_progress = 0;
    this.iol_lead_in_bag = false;
    this.iol_trail_in_bag = false;
    this.iol_center = new V2(0.9, 0.4);
    this.iol_rot = 0;
    this.iol_y = A.IOL_Y;
    this.pcr = false;
    this.pcr_pos = new V3();
    this.zonular_dialysis = false;
    this.zonular_stress = 0;
    this.endothelial_loss = 0;
    this.wound_burn = false;
    this.wound_temp = 0;
    this.iris_trauma = 0;
    this.iris_prolapse = false;
    this.wound_stress = 0;
    this.iop = 15;
    this.chamber_depth = 1;
  }

  // ---------- insisi ----------
  addIncision(name, angle, tunnel, inner, width) {
    const outer = A.pointOnLimbus(angle, A.corneaOuterY(A.LIMBUS_R) - 0.25);
    const inc = { name, angle, tunnel, outer, inner: inner.clone(), sealed: 0, width };
    const i = this.incisions.findIndex((x) => x.name === name);
    if (i >= 0) this.incisions[i] = inc;
    else this.incisions.push(inc);
    return inc;
  }

  getIncision(name) { return this.incisions.find((x) => x.name === name) ?? null; }
  hasIncision(name) { return this.getIncision(name) !== null; }

  /** Kebocoran luka total. Terowongan pendek & belum dihidrasi = bocor. */
  woundLeak() {
    let leak = 0;
    for (const inc of this.incisions) {
      const quality = clamp((inc.tunnel - 0.6) / 1.4, 0.15, 1);
      leak += (1 - inc.sealed) * (1.2 - quality) * (inc.width / 2.4);
    }
    return leak;
  }

  // ---------- rhexis ----------
  rhexisRadiusAt(thetaDeg) {
    if (!this.rhexis_done) return 0;
    const f = (fposmod(thetaDeg, 360) / 360) * RHEXIS_BINS;
    const i0 = Math.floor(f) % RHEXIS_BINS;
    const i1 = (i0 + 1) % RHEXIS_BINS;
    return lerp(this.rhexis_r[i0], this.rhexis_r[i1], f - Math.floor(f));
  }

  rhexisMeanRadius() {
    if (!this.rhexis_done) return 0;
    let s = 0;
    for (const v of this.rhexis_r) s += v;
    return s / RHEXIS_BINS;
  }

  setIdealRhexis(radius = 2.6) {
    this.rhexis_r.fill(radius);
    this.rhexis_done = true;
    this.rhexis_path = [];
  }

  /** Pergeseran diafragma iris-lensa ke anterior saat bilik dangkal (mm). */
  diaphragmShift() { return clamp(1 - this.chamber_depth, -0.25, 0.8) * 1.4; }

  syncDerived() { this.nucleus.y_shift = this.diaphragmShift(); }

  cortexRemaining() {
    let s = 0;
    for (const v of this.cortex) s += v;
    return s / CORTEX_SECTORS;
  }

  lensMaterialRemaining() {
    return this.nucleus.remainingFraction() * 0.75 + this.epi_mass * 0.1 + this.cortexRemaining() * 0.15;
  }
}
