// SafetyMonitor — batas anatomi & deteksi kontak jaringan untuk instrumen di dalam mata.
//
// Per frame untuk tiap instrumen: posisi yang diminta joystick -> posisi terkoreksi
// + laporan komplikasi. Urutan cek: radius bilik -> endotel -> iris -> kapsul anterior/rhexis
// -> di dalam kantong (kapsul posterior, ekuator/zonula) -> stres luka.
// "Diaphragm shift": saat bilik dangkal, diafragma iris-lensa maju ke anterior sehingga
// kapsul posterior "naik" mendekati tip (trampoline effect).
import * as A from './anatomy.js';
import { V3, clamp } from './math.js';

export class SafetyMonitor {
  constructor() { this.last = {}; }

  setup(cs, comp, hap) {
    this.cs = cs;
    this.comp = comp;
    this.hap = hap;
  }

  /**
   * ctx: allow_capsule_contact (CCC), aspirating (pedal ≥ 2), vacuum, dt
   */
  constrain(t, desired, ctx = {}) {
    const cs = this.cs, comp = this.comp, hap = this.hap;
    const p = desired.clone();
    const dt = ctx.dt ?? 0.016;
    const last = { capsule_contact: false, endo: false, iris: false, posterior_gap: 99, equator_gap: 99 };
    this.last = last;
    const shift = cs.diaphragmShift();
    const nearPort = !!t.port && p.distanceTo(t.port.inner) < 1.3;

    // --- radius maksimum di bilik ---
    let r = A.radial(p);
    const rLim = nearPort ? A.LIMBUS_R - 0.15 : 5.2;
    if (r > rLim) {
      const k = rLim / r;
      p.x *= k; p.z *= k;
      r = rLim;
    }

    // --- endotel kornea ---
    const yEndo = A.corneaInnerY(r) - 0.12;
    if (p.y > yEndo) {
      if (!nearPort) {
        last.endo = true;
        if (comp.report('endo_touch', `r=${r.toFixed(1)} mm`)) hap.touchTissue();
        cs.endothelial_loss += (cs.ovd_ac < 0.3 ? 3.0 : 1.2) * dt;
      }
      p.y = yEndo;
    }

    const meridian = A.meridianDeg(p);
    const rx = cs.rhexisRadiusAt(meridian);
    const yAnt = A.capsuleAnteriorY(r) + shift;

    if (!t.in_bag) {
      // --- iris ---
      if (r > cs.pupil_r - 0.05 && r < A.IRIS_OUTER_R + 0.2) {
        const irisFloor = A.IRIS_Y + shift + 0.14;
        if (p.y < irisFloor) {
          last.iris = true;
          if (comp.report('iris_touch', A.clockHour(meridian))) {
            cs.iris_trauma += 1;
            hap.touchTissue();
          }
          p.y = irisFloor;
        }
      }
      // --- kapsul anterior ---
      if (r < A.LENS_A && p.y < yAnt) {
        if (cs.rhexis_done && r < rx - 0.08) {
          t.in_bag = true;
        } else if (ctx.allow_capsule_contact) {
          last.capsule_contact = true;
          p.y = yAnt - 0.02;
        } else {
          if (cs.rhexis_done) {
            if (comp.report('rhexis_edge', A.clockHour(meridian))) {
              hap.touchTissue();
              if (cs.rhexis_tear_deg < 0 && ctx.aspirating) cs.rhexis_tear_deg = meridian;
            }
          } else if (comp.report('capsule_nick', A.clockHour(meridian))) {
            cs.capsule_nicks += 1;
            hap.touchTissue();
          }
          p.y = yAnt + 0.01;
        }
      }
    }

    if (t.in_bag) {
      // keluar dari kantong ke atas hanya lewat bukaan rhexis
      if (p.y > yAnt) {
        if (r < rx) t.in_bag = false;
        else p.y = yAnt - 0.04;
      }
      if (t.in_bag) {
        // --- kapsul posterior (naik saat surge / bilik dangkal) ---
        const bulge = clamp(1 - cs.chamber_depth, 0, 0.8) * 0.9;
        const yPost = A.capsulePosteriorY(r) + shift + bulge;
        last.posterior_gap = p.y - yPost;
        if (p.y < yPost + 0.06) {
          if (!cs.pcr) {
            cs.pcr = true;
            cs.pcr_pos = new V3(p.x, yPost, p.z);
            comp.report('pcr', A.clockHour(meridian));
            hap.alarm(3);
          }
          p.y = yPost + 0.06;
        }
        // --- ekuator kapsul / zonula ---
        const rCap = A.capsuleRadiusAtY(p.y - shift);
        last.equator_gap = rCap - r;
        if (r > rCap - 0.12 && rCap > 0.1) {
          const over = r - (rCap - 0.12);
          cs.zonular_stress += over * dt * 2.5;
          if (over > 0.2) comp.report('zonular_stress');
          const k2 = (rCap - 0.12) / Math.max(r, 0.001);
          p.x *= k2; p.z *= k2;
          if (cs.zonular_stress > 1 && !cs.zonular_dialysis) {
            cs.zonular_dialysis = true;
            comp.report('zonular', A.clockHour(meridian));
            hap.alarm(3);
          }
        }
      }
    }

    // --- stres luka (oarlocking) ---
    const wa = t.woundAngle();
    if (wa > 42) {
      cs.wound_stress += ((wa - 42) / 30) * dt;
      cs.endothelial_loss += 0.05 * dt;
      if (wa > 55) comp.report('wound_stress', `${wa.toFixed(0)}°`);
    }

    t.posterior_gap = last.posterior_gap;
    t.prev_tip = t.tip.clone();
    t.tip = p;
    return p;
  }

  /** Gerak standar tip: joystick (XZ) + slider kedalaman (Y), mm/detik. */
  static moveVector(stick, depth, dt, fine) {
    const speed = fine ? 1.4 : 3.2;
    const vspeed = fine ? 0.9 : 1.8;
    return new V3(stick.x * speed * dt, depth * vspeed * dt, stick.y * speed * dt);
  }
}
