// Anatomy — konstanta geometri mata & fungsi query murni (tanpa state).
//
// Sistem koordinat (satuan = milimeter, 1 unit three.js = 1 mm):
//   * Sumbu +Y = sumbu visual, mengarah ke mikroskop (kamera melihat ke -Y).
//   * Bidang XZ = bidang iris. Sudut meridian θ diukur di bidang XZ:
//       θ = 0°   -> +X (kanan layar / nasal untuk mata kanan)
//       θ = 180° -> -X (kiri layar / temporal)  ← lokasi insisi utama default
//       θ = 90°  -> +Z (bawah layar, karena "up" kamera = -Z)
//   * Nilai disederhanakan dari rata-rata anatomi dewasa (Gullstrand/Liou-Brennan).
import { V2, V3, fposmod, rad2deg, deg2rad } from './math.js';

export const CORNEA_CENTER_Y = -4.8;
export const CORNEA_R_OUT = 7.8;      // radius kelengkungan anterior (mm)
export const CORNEA_R_IN = 7.25;      // radius posterior -> tebal sentral ~0.55 mm
export const LIMBUS_R = 5.6;          // diameter kornea ~11.2 mm

export const IRIS_Y = -0.2;
export const IRIS_OUTER_R = 5.4;
export const PUPIL_DILATED_R = 3.6;   // pupil 7.2 mm setelah midriatik

export const LENS_CENTER_Y = -2.4;
export const LENS_A = 4.6;            // radius ekuator kapsul
export const LENS_B = 2.0;            // setengah tebal lensa
export const NUC_A = 3.3;
export const NUC_B = 1.5;
export const EPI_A = 3.95;
export const EPI_B = 1.75;

export const CILIARY_R = 6.0;
export const IOL_Y = -1.35;
export const IOL_OPTIC_R = 3.0;
export const IOL_HAPTIC_SPAN = 6.5;

export function corneaOuterY(r) {
  r = Math.min(r, CORNEA_R_OUT - 0.001);
  return CORNEA_CENTER_Y + Math.sqrt(CORNEA_R_OUT * CORNEA_R_OUT - r * r);
}

export function corneaInnerY(r) {
  r = Math.min(r, CORNEA_R_IN - 0.001);
  return CORNEA_CENTER_Y + Math.sqrt(CORNEA_R_IN * CORNEA_R_IN - r * r);
}

/** Setengah tebal ellipsoid (a,b) pada jarak radial r. */
export function ellipsoidHalf(r, a, b) {
  const t = 1 - (r / a) * (r / a);
  return t > 0 ? b * Math.sqrt(t) : 0;
}

export const capsuleAnteriorY = (r) => LENS_CENTER_Y + ellipsoidHalf(r, LENS_A, LENS_B);
export const capsulePosteriorY = (r) => LENS_CENTER_Y - ellipsoidHalf(r, LENS_A, LENS_B);

/** Radius maksimum kantong kapsul pada ketinggian y (untuk cek ekuator). */
export function capsuleRadiusAtY(y) {
  const t = (y - LENS_CENTER_Y) / LENS_B;
  const k = 1 - t * t;
  return k > 0 ? LENS_A * Math.sqrt(k) : 0;
}

export const radial = (p) => Math.hypot(p.x, p.z);

/** Sudut meridian dalam derajat 0..360. */
export const meridianDeg = (p) => fposmod(rad2deg(Math.atan2(p.z, p.x)), 360);

export function pointOnLimbus(thetaDeg, y, r = LIMBUS_R) {
  const t = deg2rad(thetaDeg);
  return new V3(Math.cos(t) * r, y, Math.sin(t) * r);
}

/** Selisih sudut terkecil (derajat, 0..180). */
export function angleDiff(a, b) {
  return Math.abs(fposmod(a - b + 180, 360) - 180);
}

/** Format jam (clock hour): 12 di atas layar (-Z). */
export function clockHour(thetaDeg) {
  const h = fposmod(thetaDeg / 30 + 3, 12);
  let hi = Math.round(h);
  if (hi === 0) hi = 12;
  return `jam ${hi}`;
}

export const v2xz = (p) => new V2(p.x, p.z);
