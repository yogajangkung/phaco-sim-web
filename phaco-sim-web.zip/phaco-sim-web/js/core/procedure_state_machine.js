// ProcedureStateMachine — urutan & validasi 11 langkah fakoemulsifikasi.
//
// Mode:
//   "guided"  : langkah berurutan; LANJUT hanya aktif bila semua objektif terpenuhi.
//   "sandbox" : lompat ke langkah mana pun; langkah sebelumnya di-fast-forward dengan
//               applyIdeal() (hasil ideal, tidak dinilai) agar state anatomi konsisten.
export class ProcedureStateMachine {
  constructor() {
    this.steps = [];
    this.index = -1;
    this.mode = 'guided';
    this.current = null;
    this.running = false;
    this.onStepChanged = () => {};
    this.onFinished = () => {};
  }

  setup(sim, stepClasses) {
    this.sim = sim;
    this.steps = stepClasses.map((Cls, i) => {
      const st = new Cls();
      st.bind(sim);
      st.index = i;
      return st;
    });
  }

  stepTitles() { return this.steps.map((s) => s.title); }

  start(mode, fromIndex = 0) {
    this.mode = mode;
    if (this.current) { this.current.exit(); this.current = null; }
    this.sim.resetCase();
    fromIndex = Math.max(0, Math.min(fromIndex, this.steps.length - 1));
    for (let i = 0; i < fromIndex; i++) {
      this.steps[i].resetRuntime();
      this.steps[i].applyIdeal();
      this.sim.score.recordStep(i, this.steps[i], [], true);
    }
    this.running = true;
    this._enter(fromIndex);
  }

  _enter(i) {
    if (this.current) this.current.exit();
    this.index = i;
    this.current = this.steps[i];
    this.current.resetRuntime();
    this.sim.complications.current_step = this.current.title;
    this.current.enter();
    this.onStepChanged(this.current);
  }

  update(dt, input) {
    if (!this.running || !this.current) return;
    this.current.elapsed += dt;
    this.current.update(dt, input);
  }

  canAdvance() { return this.running && !!this.current && this.current.canFinish(); }

  tryAdvance() {
    if (!this.canAdvance()) return false;
    this.sim.score.recordStep(this.index, this.current,
      this.sim.complications.eventsInStep(this.current.title), false);
    if (this.index + 1 < this.steps.length) this._enter(this.index + 1);
    else this.finish();
    return true;
  }

  /** Lewati langkah (hanya sandbox): hasil ideal diterapkan, tidak dinilai. */
  skipCurrent() {
    if (!this.running || !this.current) return;
    this.current.exit();
    this.current.applyIdeal();
    this.sim.score.recordStep(this.index, this.current, [], true);
    if (this.index + 1 < this.steps.length) {
      this.current = null;
      this._enter(this.index + 1);
    } else {
      this.finish();
    }
  }

  stop() {
    this.running = false;
    if (this.current) { this.current.exit(); this.current = null; }
  }

  finish() {
    if (this.current) this.current.exit();
    this.current = null;
    this.running = false;
    this.onFinished(this.sim.score.buildReport(this.sim.caseState, this.sim.complications));
  }
}
