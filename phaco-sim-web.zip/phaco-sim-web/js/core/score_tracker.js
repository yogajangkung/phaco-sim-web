// ScoreTracker — merekam waktu & kualitas tiap langkah, lalu menyusun laporan debriefing.
import { clamp } from './math.js';

export class ScoreTracker {
  constructor() { this.records = []; }

  reset() { this.records = []; }

  recordStep(index, step, events, skipped) {
    this.records = this.records.filter((r) => r.index !== index);
    this.records.push({
      index, title: step.title, time: step.elapsed, target: step.target_time,
      quality: skipped ? 0 : step.computeQuality(),
      notes: [...step.notes], skipped, events: events.length,
    });
    this.records.sort((a, b) => a.index - b.index);
  }

  /** Efisiensi waktu 0..100 (100 bila <= target, turun linear sampai 3× target). */
  static efficiency(time, target) {
    if (time <= target) return 100;
    return clamp(100 - ((time - target) / (2 * target)) * 100, 0, 100);
  }

  buildReport(cs, comp) {
    const played = this.records.filter((r) => !r.skipped);
    let q = 0, eff = 0, totalTime = 0;
    for (const r of played) {
      q += r.quality;
      eff += ScoreTracker.efficiency(r.time, r.target);
      totalTime += r.time;
    }
    const n = Math.max(played.length, 1);
    q /= n;
    eff /= n;
    const penalty = comp.totalPenalty();
    const overall = clamp(q * 0.7 + eff * 0.3 - penalty, 0, 100);

    const tips = [];
    const seen = new Set();
    for (const e of comp.events) {
      if (!seen.has(e.type)) { seen.add(e.type); tips.push(`${e.title} — ${e.advice}`); }
    }
    for (const r of played) for (const note of r.notes) tips.push(`${r.title}: ${note}`);
    if (cs.phaco_cde > 12) {
      tips.push(`CDE tinggi (${cs.phaco_cde.toFixed(1)}). Gunakan teknik chop / power lebih rendah untuk mengurangi energi ultrasound.`);
    }
    if (cs.endothelial_loss > 8) {
      tips.push(`Estimasi kehilangan sel endotel ${cs.endothelial_loss.toFixed(1)}%. Kerja lebih dalam (setinggi bidang iris) dan jaga OVD.`);
    }

    let grade = 'E';
    if (overall >= 90) grade = 'A';
    else if (overall >= 80) grade = 'B';
    else if (overall >= 65) grade = 'C';
    else if (overall >= 50) grade = 'D';

    return {
      overall, grade, quality: q, efficiency: eff, penalty, total_time: totalTime,
      records: this.records, tips, cde: cs.phaco_cde, endo_loss: cs.endothelial_loss,
      pcr: cs.pcr, complications: comp.events,
      grade_nucleus: cs.nucleus_grade, technique: cs.technique,
    };
  }
}
