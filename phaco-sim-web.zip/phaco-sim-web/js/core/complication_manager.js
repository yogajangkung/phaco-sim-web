// ComplicationManager — registri kejadian komplikasi & peringatan.
// Tiap kejadian: tipe, keparahan (1 minor, 2 sedang, 3 berat), cooldown, penalti skor.
// Listener `onRaised` dipakai HUD (banner), Haptics (getar) dan Audio (alarm).

/** tipe -> [judul, keparahan default, penalti, cooldown detik, saran] */
export const CATALOG = {
  pcr: ['Ruptur Kapsul Posterior (PCR)', 3, 30, 999,
    'Jaga tip di zona aman (tengah, setinggi bidang iris). Turunkan vakum/flow saat fragmen terakhir dan hindari pedal 3 dekat kapsul posterior.'],
  zonular: ['Dialisis Zonula', 3, 20, 999,
    'Pastikan hidrodiseksi tuntas sebelum rotasi; jangan menekan nukleus ke bawah atau ke perifer.'],
  zonular_stress: ['Stres Zonula', 1, 2, 2.5,
    'Rotasi/tekanan berlebih pada nukleus. Gunakan gerakan ringan dan pastikan nukleus bebas.'],
  endo_touch: ['Sentuhan Endotel Kornea', 2, 4, 1.5,
    'Jaga instrumen jauh dari permukaan dalam kornea; isi OVD cukup untuk proteksi endotel.'],
  iris_touch: ['Trauma Iris', 2, 4, 1.5,
    'Instrumen terlalu dekat iris. Pertahankan tip di tengah pupil.'],
  iris_prolapse: ['Prolaps Iris', 2, 8, 999,
    'Terowongan insisi terlalu pendek/terlalu posterior. Buat terowongan ±2 mm dan hindari IOP tinggi.'],
  capsule_nick: ['Tusukan Kapsul Anterior', 2, 6, 2,
    'Pisau/instrumen menembus kapsul anterior sebelum waktunya. Jaga bidang pisau sejajar iris.'],
  rhexis_runout: ['Run-out Kapsulorheksis', 3, 15, 999,
    'Robekan lari ke perifer. Tambah OVD untuk meratakan kapsul, re-grasp dekat tepi dan tarik ke arah tengah (manuver Little).'],
  rhexis_edge: ['Robekan Tepi Rhexis', 2, 8, 4,
    'Phaco tip/instrumen mengenai tepi rhexis. Kerjakan di dalam bukaan rhexis.'],
  surge: ['Post-Occlusion Surge', 2, 5, 2,
    'Vakum tinggi saat oklusi pecah. Turunkan vakum limit, naikkan botol, atau kurangi pedal sebelum fragmen habis.'],
  wound_burn: ['Wound Burn (Luka Insisi Terbakar)', 3, 12, 999,
    'Ultrasound tanpa aliran cukup. Hindari oklusi lama di pedal 3; gunakan power pulsed/lebih rendah.'],
  capsular_block: ['Capsular Block (Hidrodiseksi)', 3, 25, 999,
    'Injeksi BSS terlalu banyak tanpa dekompresi. Injeksi pelan & tekan nukleus di tengah untuk mengalirkan cairan.'],
  capsule_caught: ['Kapsul Tersedot', 2, 3, 2.5,
    'Kapsul masuk port aspirasi! Segera REFLUX (pedal 0 + tombol Reflux).'],
  chatter: ['Chatter Fragmen', 1, 1.5, 1.5,
    'Fragmen terpental karena power tinggi & vakum rendah. Tahan dengan vakum dulu (pedal 2) sebelum pedal 3.'],
  wound_stress: ['Distorsi Luka (Oarlocking)', 1, 1.5, 3,
    'Instrumen menekan sisi luka. Pivot di dalam terowongan, jangan menyudut terlalu jauh.'],
  iol_sulcus: ['Haptik di Sulkus', 2, 8, 999,
    'Arahkan bevel injector ke dalam kantong kapsul (turunkan tip) dan pastikan kantong terisi OVD.'],
  iop_high: ['IOP Terlalu Tinggi', 1, 2, 4,
    'OVD/BSS berlebih. Kurangi injeksi atau burp luka.'],
  chamber_collapse: ['Bilik Mata Depan Kolaps', 2, 6, 3,
    'Aliran keluar melebihi irigasi. Naikkan botol/kurangi flow, jangan angkat instrumen keluar saat pedal >= 2.'],
  descemet: ['Detasemen Descemet', 2, 6, 999,
    'Pisau masuk ke bilik terlalu curam / instrumen tumpul diselipkan antara stroma dan Descemet.'],
};

export class ComplicationManager {
  constructor() {
    this.events = [];
    this._lastTime = new Map();
    this.clock = 0;
    this.current_step = '';
    this.listeners = [];
  }

  onRaised(fn) { this.listeners.push(fn); }

  reset() {
    this.events = [];
    this._lastTime.clear();
    this.clock = 0;
  }

  tick(dt) { this.clock += dt; }

  /** Laporkan kejadian. true bila tercatat (tidak terkena cooldown). */
  report(type, detail = '', severityOverride = -1) {
    const info = CATALOG[type];
    if (!info) { console.warn('Unknown complication type:', type); return false; }
    const cooldown = info[3];
    if (this._lastTime.has(type) && this.clock - this._lastTime.get(type) < cooldown) return false;
    this._lastTime.set(type, this.clock);
    const ev = {
      type, title: info[0],
      severity: severityOverride > 0 ? severityOverride : info[1],
      penalty: info[2], advice: info[4], detail,
      step: this.current_step, time: this.clock,
    };
    this.events.push(ev);
    for (const fn of this.listeners) fn(ev);
    return true;
  }

  count(type = '') {
    return type === '' ? this.events.length : this.events.filter((e) => e.type === type).length;
  }

  eventsInStep(title) { return this.events.filter((e) => e.step === title); }

  totalPenalty() { return this.events.reduce((p, e) => p + e.penalty, 0); }
}
