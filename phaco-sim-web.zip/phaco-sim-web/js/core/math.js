// Matematika dasar — vektor bernilai (immutable-style) agar semantik sama dengan
// Vector2/Vector3 Godot (tipe nilai). Setiap operasi mengembalikan objek baru.
// Field x/y/z boleh diubah langsung pada salinan lokal (mis. p.y = ...).

export const TAU = Math.PI * 2;
export const DEG = Math.PI / 180;

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const fposmod = (a, b) => { const r = a % b; return r < 0 ? r + b : r; };
export const deg2rad = (d) => d * DEG;
export const rad2deg = (r) => r / DEG;
export const moveToward = (from, to, delta) =>
  Math.abs(to - from) <= delta ? to : from + Math.sign(to - from) * delta;
export const randRange = (a, b) => a + Math.random() * (b - a);
/** Faktor smoothing eksponensial yang tidak bergantung frame rate. */
export const expK = (rate, dt) => 1 - Math.exp(-rate * dt);

export class V2 {
  constructor(x = 0, y = 0) { this.x = x; this.y = y; }
  clone() { return new V2(this.x, this.y); }
  add(v) { return new V2(this.x + v.x, this.y + v.y); }
  sub(v) { return new V2(this.x - v.x, this.y - v.y); }
  mul(s) { return new V2(this.x * s, this.y * s); }
  length() { return Math.hypot(this.x, this.y); }
  normalized() { const l = this.length(); return l > 0 ? this.mul(1 / l) : new V2(); }
  dot(v) { return this.x * v.x + this.y * v.y; }
  /** Sama dengan Vector2.cross Godot: x*b.y − y*b.x */
  cross(v) { return this.x * v.y - this.y * v.x; }
  distanceTo(v) { return Math.hypot(this.x - v.x, this.y - v.y); }
  lerp(v, t) { return new V2(lerp(this.x, v.x, t), lerp(this.y, v.y, t)); }
  limitLength(m) { const l = this.length(); return l > m && l > 0 ? this.mul(m / l) : this.clone(); }
}

export class V3 {
  constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
  clone() { return new V3(this.x, this.y, this.z); }
  add(v) { return new V3(this.x + v.x, this.y + v.y, this.z + v.z); }
  sub(v) { return new V3(this.x - v.x, this.y - v.y, this.z - v.z); }
  mul(s) { return new V3(this.x * s, this.y * s, this.z * s); }
  neg() { return new V3(-this.x, -this.y, -this.z); }
  length() { return Math.hypot(this.x, this.y, this.z); }
  normalized() { const l = this.length(); return l > 0 ? this.mul(1 / l) : new V3(); }
  dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z; }
  cross(v) {
    return new V3(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
  }
  distanceTo(v) { return Math.hypot(this.x - v.x, this.y - v.y, this.z - v.z); }
  lerp(v, t) { return new V3(lerp(this.x, v.x, t), lerp(this.y, v.y, t), lerp(this.z, v.z, t)); }
  angleTo(v) {
    const d = this.length() * v.length();
    return d > 0 ? Math.acos(clamp(this.dot(v) / d, -1, 1)) : 0;
  }
}

export const V3_UP = Object.freeze(new V3(0, 1, 0));

/** Rotasi vektor mengelilingi sumbu Y (sama dengan Basis(Vector3.UP, a) Godot). */
export function rotY(v, a) {
  const c = Math.cos(a), s = Math.sin(a);
  return new V3(v.x * c + v.z * s, v.y, -v.x * s + v.z * c);
}

/** Format jam mm:ss */
export const mmss = (t) => {
  const s = Math.floor(t);
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};
