// EyeModel — hierarki anatomi 3D prosedural & sinkronisasi visual dari CaseState.
//
//   EyeModel
//   ├─ Lids (kelopak + drape)  ├─ Speculum     ├─ Sclera      ├─ Cornea
//   ├─ ACFluid (OVD)           ├─ Diaphragm (ikut bergeser saat surge)
//   │   ├─ Iris                └─ Lens: AnteriorCapsule, Cortex, Epinucleus,
//   │                                   PosteriorCapsule, Zonules
//   ├─ Vitreous (saat PCR)     ├─ NucleusRenderer  ├─ IOL (optik + 2 haptik C-loop)
//   ├─ RhexisLine              ├─ Fundus (red reflex)  └─ Particles (fragmen emulsifikasi)
import * as THREE from 'three';
import * as A from '../core/anatomy.js';
import { V3, clamp, lerp, deg2rad, randRange, expK } from '../core/math.js';
import { revolve, ellipsoidProfile, tube, planeXZ } from './mesh_factory.js';
import { NucleusRenderer } from './nucleus_renderer.js';
import * as S from './shaders.js';

const MAX_PARTICLES = 60;

export class EyeModel extends THREE.Group {
  constructor(cs) {
    super();
    this.cs = cs;
    this.hydro_wave = 0;
    this.red_reflex = 1;
    this._lastPathSize = -1;
    this.particles = { position: new V3(), emitting: false };
    this._build();
  }

  _build() {
    const cs = this.cs;
    // --- kelopak & drape ---
    this.matLids = S.eyelidMaterial();
    this.lids = new THREE.Mesh(planeXZ(90, 90), this.matLids);
    this.lids.position.y = 0.95;
    this.add(this.lids);

    // --- spekulum (dua bilah kawat) ---
    this.speculum = new THREE.Group();
    const steel = new THREE.MeshPhongMaterial({ color: 0xc0c7d1, specular: 0xffffff, shininess: 90 });
    for (const sgn of [-1, 1]) {
      const pts = [];
      for (let i = 0; i <= 20; i++) {
        const t = -1 + (2 * i) / 20;
        pts.push([t * 9, 1.3 + 0.4 * (1 - t * t), sgn * (12.2 - 2.2 * t * t)]);
      }
      this.speculum.add(new THREE.Mesh(tube(pts, 0.35, 8, 40), steel));
      const arm = [[9 * (sgn > 0 ? 1 : -1), 1.4, sgn * 10], [16, 2.2, sgn * 14], [30, 3, sgn * 6]];
      this.speculum.add(new THREE.Mesh(tube(arm, 0.4, 8, 24), steel));
    }
    this.add(this.speculum);

    // --- sklera ---
    this.sclera = new THREE.Mesh(new THREE.SphereGeometry(12, 64, 32), S.scleraMaterial());
    this.sclera.position.y = -10.1;
    this.add(this.sclera);

    // --- kornea ---
    const prof = [];
    for (let i = 0; i <= 24; i++) { const r = (A.LIMBUS_R * i) / 24; prof.push([r, A.corneaOuterY(r)]); }
    this.matCornea = S.corneaMaterial();
    this.cornea = new THREE.Mesh(revolve(prof, 72), this.matCornea);
    this.cornea.renderOrder = 10;
    this.add(this.cornea);

    // --- OVD bilik depan ---
    const profIn = [];
    for (let i = 0; i <= 20; i++) {
      const r = ((A.LIMBUS_R - 0.3) * i) / 20;
      profIn.push([r, A.corneaInnerY(r) - 0.05]);
    }
    this.matFluid = S.fluidMaterial();
    this.acFluid = new THREE.Mesh(revolve(profIn, 48), this.matFluid);
    this.acFluid.renderOrder = 9;
    this.add(this.acFluid);

    // --- diafragma iris-lensa ---
    this.diaphragm = new THREE.Group();
    this.add(this.diaphragm);
    const profIris = [];
    for (let i = 0; i <= 8; i++) {
      const r = lerp(1.0, A.IRIS_OUTER_R + 0.1, i / 8);
      profIris.push([r, A.IRIS_Y + 0.12 * (1 - i / 8)]);
    }
    this.matIris = S.irisMaterial();
    this.iris = new THREE.Mesh(revolve(profIris, 96), this.matIris);
    this.diaphragm.add(this.iris);

    this.lens = new THREE.Group();
    this.lens.position.y = A.LENS_CENTER_Y;
    this.diaphragm.add(this.lens);

    this.matAnt = S.capsuleMaterial(0.07);
    this.antCapsule = new THREE.Mesh(revolve(ellipsoidProfile(A.LENS_A, A.LENS_B, 1), 72), this.matAnt);
    this.antCapsule.renderOrder = 6;
    this.lens.add(this.antCapsule);
    this.matPost = S.capsuleMaterial(0.05);
    this.postCapsule = new THREE.Mesh(revolve(ellipsoidProfile(A.LENS_A, A.LENS_B, -1), 72, true), this.matPost);
    this.postCapsule.renderOrder = 1;
    this.lens.add(this.postCapsule);

    const sph = new THREE.SphereGeometry(1, 48, 24);
    this.matCortex = S.lensLayerMaterial([0.95, 0.95, 0.9], 0.5, { useSectors: true, periph: true });
    this.cortex = new THREE.Mesh(sph, this.matCortex);
    this.cortex.scale.set(A.LENS_A - 0.08, A.LENS_B - 0.08, A.LENS_A - 0.08);
    this.cortex.renderOrder = 2;
    this.lens.add(this.cortex);
    this.matEpi = S.lensLayerMaterial([0.95, 0.85, 0.55], 0.28);
    this.epinucleus = new THREE.Mesh(sph, this.matEpi);
    this.epinucleus.scale.set(A.EPI_A, A.EPI_B, A.EPI_A);
    this.epinucleus.renderOrder = 4;
    this.lens.add(this.epinucleus);

    // --- zonula ---
    const zp = [];
    for (let i = 0; i < 90; i++) {
      const a = (Math.PI * 2 * i) / 90;
      const yo = i % 3 === 0 ? 0.6 : i % 3 === 1 ? -0.6 : 0;
      zp.push(Math.cos(a) * A.LENS_A, yo, Math.sin(a) * A.LENS_A, Math.cos(a) * A.CILIARY_R, 0, Math.sin(a) * A.CILIARY_R);
    }
    const zg = new THREE.BufferGeometry();
    zg.setAttribute('position', new THREE.Float32BufferAttribute(zp, 3));
    this.zonules = new THREE.LineSegments(zg, new THREE.LineBasicMaterial({ color: 0xe6e6d9, transparent: true, opacity: 0.5 }));
    this.lens.add(this.zonules);

    // --- vitreous (muncul saat PCR) ---
    this.vitreous = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 16),
      new THREE.MeshPhongMaterial({ color: 0xccf2d9, transparent: true, opacity: 0.22, depthWrite: false, shininess: 80 }));
    this.vitreous.visible = false;
    this.vitreous.renderOrder = 5;
    this.add(this.vitreous);

    // --- nukleus ---
    this.nucleus = new NucleusRenderer();
    this.nucleus.setup(cs.nucleus);
    this.nucleus.setGrade(cs.nucleus_grade);
    this.add(this.nucleus);

    // --- IOL ---
    this.iol = new THREE.Group();
    const acryl = new THREE.MeshPhongMaterial({
      color: 0xebf7ff, transparent: true, opacity: 0.3, specular: 0xffffff, shininess: 160, depthWrite: false,
    });
    this.iolOptic = new THREE.Mesh(new THREE.SphereGeometry(1, 40, 20), acryl);
    this.iolOptic.scale.set(A.IOL_OPTIC_R, 0.32, A.IOL_OPTIC_R);
    this.iolOptic.renderOrder = 5;
    this.iol.add(this.iolOptic);
    const hmat = new THREE.MeshPhongMaterial({ color: 0xd9f2ff, transparent: true, opacity: 0.7, shininess: 100 });
    this.iolHapticLead = new THREE.Mesh(tube(this._hapticPoints(0), 0.12, 6, 32), hmat);
    this.iolHapticTrail = new THREE.Mesh(tube(this._hapticPoints(180), 0.12, 6, 32), hmat);
    this.iol.add(this.iolHapticLead, this.iolHapticTrail);
    this.iol.visible = false;
    this.add(this.iol);

    // --- jejak rhexis ---
    this.rhexisLine = new THREE.Line(new THREE.BufferGeometry(),
      new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9 }));
    this.rhexisLine.renderOrder = 7;
    this.add(this.rhexisLine);

    // --- fundus / red reflex ---
    this.fundusMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.85, 0.25, 0.08) });
    this.fundus = new THREE.Mesh(new THREE.CylinderGeometry(9, 9, 0.1, 48), this.fundusMat);
    this.fundus.position.y = -15;
    this.add(this.fundus);

    // --- partikel fragmen emulsifikasi ---
    this._pData = Array.from({ length: MAX_PARTICLES }, () => ({ life: 0, p: new THREE.Vector3(), v: new THREE.Vector3() }));
    this._pGeo = new THREE.BufferGeometry();
    this._pPos = new Float32Array(MAX_PARTICLES * 3);
    this._pGeo.setAttribute('position', new THREE.BufferAttribute(this._pPos, 3));
    this._pPoints = new THREE.Points(this._pGeo, new THREE.PointsMaterial({
      color: 0xf2d999, size: 0.14, sizeAttenuation: true, transparent: true, opacity: 0.85, depthWrite: false,
    }));
    this._pPoints.frustumCulled = false;
    this._pPoints.renderOrder = 8;
    this._pAccum = 0;
    this.add(this._pPoints);

    // --- penanda target (lutut haptik untuk dialing) ---
    const tg = new THREE.TorusGeometry(0.425, 0.075, 8, 32);
    tg.rotateX(Math.PI / 2);
    this.targetMarker = new THREE.Mesh(tg, new THREE.MeshBasicMaterial({
      color: 0xffd933, transparent: true, opacity: 0.85, depthTest: false,
    }));
    this.targetMarker.renderOrder = 20;
    this.targetMarker.visible = false;
    this.add(this.targetMarker);
  }

  _hapticPoints(startDeg) {
    const pts = [];
    for (let i = 0; i < 16; i++) {
      const t = i / 15;
      const a = deg2rad(startDeg + t * 115);
      const r = A.IOL_OPTIC_R - 0.1 + (A.IOL_HAPTIC_SPAN - A.IOL_OPTIC_R) * Math.sin(t * Math.PI * 0.5);
      pts.push([Math.cos(a) * r, 0, Math.sin(a) * r]);
    }
    return pts;
  }

  /** Posisi "lutut" haptik trailing dunia (target hook saat dialing). */
  iolTrailingKnee() {
    const cs = this.cs;
    const a = deg2rad(190 - cs.iol_rot);
    const c = cs.iol_center;
    const r = A.IOL_OPTIC_R + 0.4;
    const y = cs.iol_y + cs.diaphragmShift() + (cs.iol_trail_in_bag ? 0 : 0.9);
    return new V3(c.x + Math.cos(a) * r, y, c.y + Math.sin(a) * r);
  }

  showTarget(pos, on) {
    this.targetMarker.visible = on;
    this.targetMarker.position.set(pos.x, pos.y, pos.z);
  }

  resetVisuals() {
    this.nucleus.setup(this.cs.nucleus);
    this.nucleus.setGrade(this.cs.nucleus_grade);
    this._lastPathSize = -1;
    this.hydro_wave = 0;
    this.particles.emitting = false;
    for (const p of this._pData) p.life = 0;
  }

  setCutaway(on) {
    S.globals.cutaway.value = on ? 1 : 0;
    this._cutaway = on;
  }

  /** Sinkronisasi visual dari state (dipanggil tiap frame). */
  updateFromCase(dt, injectorTip, injectorDir) {
    const cs = this.cs;
    const shift = cs.diaphragmShift();
    S.globals.time.value += dt;

    // kelopak & spekulum
    cs.lid_open = lerp(cs.lid_open, cs.speculum ? 1 : 0.35, expK(3, dt));
    this.matLids.uniforms.open.value = cs.lid_open;
    this.lids.visible = !this._cutaway;
    this.speculum.visible = cs.speculum && !this._cutaway;
    this.speculum.scale.set(1, 1, lerp(0.6, 1, cs.lid_open));

    // kornea: insisi, haze edema, striae
    const u = this.matCornea.uniforms;
    const n = Math.min(cs.incisions.length, 4);
    for (let i = 0; i < 4; i++) {
      u.inc_angle.value[i] = i < n ? deg2rad(cs.incisions[i].angle) : 0;
      u.inc_width.value[i] = i < n ? cs.incisions[i].width : 0;
    }
    u.inc_count.value = n;
    u.haze.value = clamp(cs.endothelial_loss / 40, 0, 0.6) + (cs.wound_burn ? 0.25 : 0);
    u.striae.value = clamp(cs.wound_stress, 0, 1);
    this.matFluid.uniforms.amount.value = cs.ovd_ac;

    this.diaphragm.position.y = shift;

    // iris & pupil (miosis ringan saat trauma iris berulang)
    this.matIris.uniforms.pupil_r.value = cs.pupil_r - Math.min(cs.iris_trauma * 0.08, 0.8);
    this.matIris.uniforms.trauma.value = clamp(cs.iris_trauma / 6, 0, 1);

    // kapsul anterior & rhexis
    this.matAnt.uniforms.rhexis_r.value = cs.rhexis_r;
    this.matAnt.uniforms.rhexis_on.value = cs.rhexis_done ? 1 : 0;
    // kapsul posterior: PCR + gelombang hidro
    const up = this.matPost.uniforms;
    if (cs.pcr) {
      up.hole_pos.value.set(cs.pcr_pos.x, cs.pcr_pos.y, cs.pcr_pos.z);
      up.hole_r.value = 1.1;
      this.vitreous.visible = true;
      this.vitreous.position.set(cs.pcr_pos.x, cs.pcr_pos.y + 0.35, cs.pcr_pos.z);
      this.vitreous.scale.lerp(new THREE.Vector3(1.4, 0.8, 1.4), expK(1, dt));
    } else {
      up.hole_r.value = 0;
      this.vitreous.visible = false;
      this.vitreous.scale.set(0.2, 0.2, 0.2);
    }
    if (this.hydro_wave > 0) {
      this.hydro_wave += dt * 0.7;
      if (this.hydro_wave > 1) this.hydro_wave = 0;
    }
    up.wave.value = this.hydro_wave;

    // korteks & epinukleus
    this.matCortex.uniforms.sectors.value = cs.cortex;
    this.matEpi.uniforms.amount.value = cs.epi_mass;
    this.matEpi.uniforms.golden_ring.value = cs.hydro_delineation;

    this.nucleus.updateView(dt);

    // IOL
    this.iol.visible = cs.iol_present;
    if (cs.iol_present) {
      if (cs.iol_progress < 1) {
        const p = cs.iol_progress;
        const dir = injectorDir.normalized();
        const pos = injectorTip.add(dir.mul(p * 3.2)).add(new V3(0, -0.2 * p, 0));
        this.iol.position.set(pos.x, pos.y, pos.z);
        this.iol.rotation.set(0, Math.atan2(-dir.z, dir.x), 0);
        const unfold = clamp((p - 0.2) / 0.8, 0, 1);
        this.iol.scale.set(lerp(0.3, 1, unfold), 1, lerp(0.3, 1, unfold));
        this.iolHapticLead.visible = p > 0.3;
        this.iolHapticTrail.visible = p > 0.85;
        this.iolHapticLead.position.y = 0;
        this.iolHapticTrail.position.y = 0;
      } else {
        this.iol.position.set(cs.iol_center.x, cs.iol_y + shift, cs.iol_center.y);
        this.iol.rotation.set(0, deg2rad(cs.iol_rot), 0);
        this.iol.scale.set(1, 1, 1);
        this.iolHapticLead.visible = true;
        this.iolHapticTrail.visible = true;
        this.iolHapticTrail.position.y = cs.iol_trail_in_bag ? 0 : 0.9;
        this.iolHapticLead.position.y = cs.iol_lead_in_bag ? 0 : 0.7;
      }
    }

    // jejak rhexis
    const pathKey = cs.rhexis_done ? -2 : cs.rhexis_path.length;
    if (pathKey !== this._lastPathSize) {
      this._lastPathSize = pathKey;
      const pts = [];
      if (cs.rhexis_path.length >= 2 && !cs.rhexis_done) {
        for (const p2 of cs.rhexis_path) {
          pts.push(p2.x, A.capsuleAnteriorY(p2.length()) + 0.03, p2.y);
        }
      }
      this.rhexisLine.geometry.dispose();
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
      this.rhexisLine.geometry = g;
    }
    this.rhexisLine.position.y = shift;

    // red reflex: berkurang pada nukleus padat, fokus buruk, atau mikroskop off-center
    const dens = [1.0, 0.85, 0.6, 0.35][clamp(cs.nucleus_grade, 1, 4) - 1];
    let reflex = lerp(1, dens, cs.nucleus.remainingFraction());
    reflex *= clamp(1 - Math.abs(cs.scope_focus) / 8, 0.3, 1);
    reflex *= clamp(1 - cs.scope_offset.length() / 5, 0.3, 1);
    this.red_reflex = reflex;
    const k = 0.35 + 0.75 * reflex;
    this.fundusMat.color.setRGB(0.9 * k, 0.28 * k, 0.08 * k);

    this._updateParticles(dt);
  }

  _updateParticles(dt) {
    const src = this.particles;
    if (src.emitting) {
      this._pAccum += dt * 80;
      while (this._pAccum >= 1) {
        this._pAccum -= 1;
        const p = this._pData.find((q) => q.life <= 0);
        if (!p) break;
        p.life = 0.5;
        p.p.set(src.position.x, src.position.y, src.position.z);
        const th = randRange(0, Math.PI * 2), sp = deg2rad(randRange(0, 70));
        const speed = randRange(0.5, 1.6);
        p.v.set(Math.sin(sp) * Math.cos(th) * speed, Math.cos(sp) * speed, Math.sin(sp) * Math.sin(th) * speed);
      }
    } else {
      this._pAccum = 0;
    }
    for (let i = 0; i < MAX_PARTICLES; i++) {
      const p = this._pData[i];
      if (p.life > 0) {
        p.life -= dt;
        p.p.addScaledVector(p.v, dt);
      }
      const hide = p.life <= 0;
      this._pPos[i * 3] = hide ? 0 : p.p.x;
      this._pPos[i * 3 + 1] = hide ? -999 : p.p.y;
      this._pPos[i * 3 + 2] = hide ? 0 : p.p.z;
    }
    this._pGeo.attributes.position.needsUpdate = true;
  }
}
