// NucleusRenderer — membangun mesh nukleus dari NucleusModel (height-field per segmen).
// Tiap segmen (kuadran/fragmen) = satu Mesh sehingga fragmen yang ditarik vakum cukup
// digeser posisinya tanpa rebuild. Rebuild geometri di-throttle (≥ 0.1 s).
import * as THREE from 'three';
import { N } from '../sim/nucleus_model.js';
import { nucleusMaterial } from './shaders.js';

const GRADE_COLORS = [
  [0.96, 0.92, 0.72, 0.55],
  [0.9, 0.78, 0.45, 0.78],
  [0.76, 0.56, 0.26, 0.92],
  [0.5, 0.31, 0.13, 0.98],
];

export class NucleusRenderer extends THREE.Group {
  constructor() {
    super();
    this.material = nucleusMaterial();
    this.heldMaterial = nucleusMaterial();
    this.heldMaterial.uniforms.highlight.value = 1;
    this.held_segment = -1;
    this._meshes = new Map();
    this._lastVersion = -1;
    this._cooldown = 0;
    this.renderOrder = 3;
  }

  setup(model) { this.model = model; this.forceRebuild(); }

  setGrade(grade) {
    const c = GRADE_COLORS[Math.max(1, Math.min(4, grade)) - 1];
    for (const m of [this.material, this.heldMaterial]) {
      m.uniforms.color.value.setRGB(c[0], c[1], c[2]);
      m.uniforms.alpha.value = c[3];
    }
  }

  forceRebuild() { this._lastVersion = -1; this._cooldown = 0; }

  updateView(dt) {
    const m = this.model;
    if (!m) return;
    const c = m.centerWorld();
    this.position.set(c.x, c.y, c.z);
    this.rotation.y = m.rotRad();
    this._cooldown -= dt;
    if (m.version !== this._lastVersion && this._cooldown <= 0) {
      this._rebuild();
      this._lastVersion = m.version;
      this._cooldown = 0.1;
    }
    for (const [s, mesh] of this._meshes) {
      const o = m.offsetOf(s);
      mesh.position.set(o.x, o.y, o.z);
      mesh.material = s === this.held_segment ? this.heldMaterial : this.material;
    }
  }

  _rebuild() {
    const alive = new Set(this.model.aliveSegments());
    for (const [s, mesh] of this._meshes) {
      if (!alive.has(s)) {
        this.remove(mesh);
        mesh.geometry.dispose();
        this._meshes.delete(s);
      }
    }
    for (const s of alive) {
      const geo = this._buildSegment(s);
      let mesh = this._meshes.get(s);
      if (mesh) {
        mesh.geometry.dispose();
        mesh.geometry = geo;
      } else {
        mesh = new THREE.Mesh(geo, this.material);
        mesh.renderOrder = 3;
        this.add(mesh);
        this._meshes.set(s, mesh);
      }
    }
  }

  _buildSegment(s) {
    const m = this.model;
    const cell = m.cell;
    const a = -cell * N * 0.5;
    const R = N + 1;
    const tops = new Float32Array(R * R);
    const bots = new Float32Array(R * R);
    // tinggi sudut = rata-rata sel tetangga milik segmen yang sama
    for (let cj = 0; cj <= N; cj++) {
      for (let ci = 0; ci <= N; ci++) {
        let st = 0, sb = 0, cnt = 0;
        for (let dj = -1; dj <= 0; dj++) {
          for (let di = -1; di <= 0; di++) {
            const i = ci + di, j = cj + dj;
            if (i < 0 || j < 0 || i >= N || j >= N) continue;
            const k = m.idx(i, j);
            if (m.seg[k] !== s) continue;
            st += m.top[k]; sb += m.bot[k]; cnt++;
          }
        }
        tops[cj * R + ci] = cnt ? st / cnt : 0;
        bots[cj * R + ci] = cnt ? sb / cnt : 0;
      }
    }
    const pos = [], nor = [];
    const quad = (p0, p1, p2, p3, n) => {
      for (const p of [p0, p1, p2, p0, p2, p3]) { pos.push(p[0], p[1], p[2]); nor.push(n[0], n[1], n[2]); }
    };
    const same = (i, j) => i >= 0 && j >= 0 && i < N && j < N && m.seg[m.idx(i, j)] === s;
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        if (m.seg[m.idx(i, j)] !== s) continue;
        const x0 = a + i * cell, x1 = x0 + cell, z0 = a + j * cell, z1 = z0 + cell;
        const t00 = tops[j * R + i], t10 = tops[j * R + i + 1], t01 = tops[(j + 1) * R + i], t11 = tops[(j + 1) * R + i + 1];
        const b00 = bots[j * R + i], b10 = bots[j * R + i + 1], b01 = bots[(j + 1) * R + i], b11 = bots[(j + 1) * R + i + 1];
        let nx = -((t10 + t11) - (t00 + t01)) * 0.5 / cell, ny = 1, nz = -((t01 + t11) - (t00 + t10)) * 0.5 / cell;
        const l = Math.hypot(nx, ny, nz);
        quad([x0, t00, z0], [x0, t01, z1], [x1, t11, z1], [x1, t10, z0], [nx / l, ny / l, nz / l]);
        quad([x0, b00, z0], [x1, b10, z0], [x1, b11, z1], [x0, b01, z1], [0, -1, 0]);
        if (!same(i - 1, j)) quad([x0, b00, z0], [x0, b01, z1], [x0, t01, z1], [x0, t00, z0], [-1, 0, 0]);
        if (!same(i + 1, j)) quad([x1, b10, z0], [x1, t10, z0], [x1, t11, z1], [x1, b11, z1], [1, 0, 0]);
        if (!same(i, j - 1)) quad([x0, b00, z0], [x0, t00, z0], [x1, t10, z0], [x1, b10, z0], [0, 0, -1]);
        if (!same(i, j + 1)) quad([x0, b01, z1], [x1, b11, z1], [x1, t11, z1], [x0, t01, z1], [0, 0, 1]);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    return g;
  }
}
