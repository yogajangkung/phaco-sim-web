// Shader GLSL (three.js ShaderMaterial, WebGL2) untuk jaringan mata.
// Semua shader berbagi uniform global `cutaway` (kamera Potongan/Orbit membuang z > 0)
// dan `time`. Pencahayaan sederhana (ambient + lampu koaksial mikroskop + lampu kerja)
// dihitung manual di fragment shader agar ringan di GPU mobile.
import * as THREE from 'three';

export const globals = {
  cutaway: { value: 0 },
  time: { value: 0 },
};

const VERT = /* glsl */ `
varying vec3 vWorld;
varying vec3 vLocal;
varying vec3 vNormalW;
void main() {
  vec4 w = modelMatrix * vec4(position, 1.0);
  vWorld = w.xyz;
  vLocal = position;
  vNormalW = normalize(transpose(inverse(mat3(modelMatrix))) * normal);
  gl_Position = projectionMatrix * viewMatrix * w;
}`;

const COMMON = /* glsl */ `
#define TAU 6.28318530718
#define PI 3.14159265359
uniform float cutaway;
uniform float time;
varying vec3 vWorld;
varying vec3 vLocal;
varying vec3 vNormalW;

// N menghadap kamera (cull_disabled): balik bila sisi belakang.
vec3 faceNormal(out bool front) {
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 N = normalize(vNormalW);
  front = dot(N, V) >= 0.0;
  return front ? N : -N;
}

vec3 shade(vec3 albedo, vec3 N, float rough, float spec) {
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 Lk = normalize(vec3(0.0, 1.0, 0.035));          // lampu koaksial mikroskop
  vec3 Lf = normalize(vec3(6.0, 22.0, 8.0) - vWorld);   // lampu kerja miring
  float dk = max(dot(N, Lk), 0.0);
  float df = max(dot(N, Lf), 0.0);
  float shin = clamp(2.0 / max(rough * rough * rough * rough, 1e-4) - 2.0, 4.0, 2048.0);
  float sk = pow(max(dot(N, normalize(Lk + V)), 0.0), shin);
  float sf = pow(max(dot(N, normalize(Lf + V)), 0.0), shin);
  vec3 amb = vec3(0.24, 0.24, 0.27);
  vec3 col = albedo * (amb + dk * 0.48 + df * 0.32);
  col += vec3(spec) * (sk * 0.7 + sf * 0.9) * (1.0 - rough * 0.6);
  // tonemap lembut (mirip filmic) agar highlight tidak jenuh
  col = col / (1.0 + max(col - 0.8, 0.0));
  return col;
}
`;

function mat(frag, uniforms, opts = {}) {
  return new THREE.ShaderMaterial({
    vertexShader: VERT,
    fragmentShader: COMMON + frag,
    uniforms: { cutaway: globals.cutaway, time: globals.time, ...uniforms },
    side: THREE.DoubleSide,
    transparent: !!opts.transparent,
    depthWrite: opts.depthWrite ?? !opts.transparent,
  });
}

// Kornea: fresnel, specular tajam, cincin limbus, tanda insisi & haze.
export function corneaMaterial() {
  return mat(/* glsl */ `
uniform float haze;
uniform float striae;
uniform float limbus_r;
uniform float inc_angle[4];
uniform float inc_width[4];
uniform int inc_count;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  bool front; vec3 N = faceNormal(front);
  vec3 V = normalize(cameraPosition - vWorld);
  float r = length(vWorld.xz);
  float fres = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 3.0);
  float a = 0.035 + fres * 0.45 + haze * 0.4;
  float limb = smoothstep(limbus_r - 0.7, limbus_r, r);
  vec3 col = mix(vec3(0.86, 0.93, 1.0), vec3(0.72, 0.78, 0.84), limb);
  a += limb * 0.28;
  float ang = atan(vWorld.z, vWorld.x);
  for (int i = 0; i < 4; i++) {
    if (i >= inc_count) break;
    float d = abs(mod(ang - inc_angle[i] + PI, TAU) - PI) * r;
    float band = smoothstep(limbus_r - 2.4, limbus_r - 1.8, r) * (1.0 - smoothstep(limbus_r - 0.2, limbus_r, r));
    float mark = (1.0 - smoothstep(inc_width[i] * 0.35, inc_width[i] * 0.5, d)) * band;
    col = mix(col, vec3(0.97, 0.98, 1.0), mark * 0.55);
    a = max(a, mark * 0.3);
  }
  float st = striae * (0.5 + 0.5 * sin(vWorld.x * 9.0 + vWorld.z * 3.0)) * (1.0 - smoothstep(0.0, 4.0, r));
  a += st * 0.12;
  vec3 c = shade(col * 0.6, N, 0.06, 1.0);
  gl_FragColor = vec4(c, clamp(a, 0.0, 0.85));
}`, {
    haze: { value: 0 }, striae: { value: 0 }, limbus_r: { value: 5.6 },
    inc_angle: { value: [0, 0, 0, 0] }, inc_width: { value: [0, 0, 0, 0] }, inc_count: { value: 0 },
  }, { transparent: true });
}

// Sklera + konjungtiva dengan pembuluh prosedural; bagian di dalam limbus dibuang.
export function scleraMaterial() {
  return mat(/* glsl */ `
uniform float limbus_r;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  float r = length(vWorld.xz);
  if (r < limbus_r - 0.05 && vWorld.y > -2.0) discard;
  bool front; vec3 N = faceNormal(front);
  float ang = atan(vWorld.z, vWorld.x);
  float v = 0.0;
  for (int i = 0; i < 4; i++) {
    float fi = float(i);
    float w = sin(ang * (7.0 + fi * 4.0) + sin(r * (0.9 + fi * 0.3) + fi * 2.1) * 2.4 + fi * 1.7);
    v += smoothstep(0.988, 1.0, w) * smoothstep(limbus_r + 0.2, limbus_r + 1.6, r) * (0.6 + 0.4 * fi / 3.0);
  }
  vec3 base = vec3(0.94, 0.89, 0.86);
  vec3 col = mix(base, vec3(0.72, 0.12, 0.12), clamp(v, 0.0, 1.0) * 0.75);
  col = mix(vec3(0.8, 0.76, 0.74), col, smoothstep(limbus_r, limbus_r + 0.7, r));
  if (!front) col *= 0.45;
  gl_FragColor = vec4(shade(col, N, 0.3, 0.35), 1.0);
}`, { limbus_r: { value: 5.6 } });
}

// Iris: serat radial, collarette, tepi pupil gelap; pupil = discard r < pupil_r.
export function irisMaterial() {
  return mat(/* glsl */ `
uniform float pupil_r;
uniform float trauma;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  float r = length(vLocal.xz);
  if (r < pupil_r) discard;
  bool front; vec3 N = faceNormal(front);
  vec3 ca = vec3(0.30, 0.18, 0.10), cb = vec3(0.56, 0.38, 0.20);
  float ang = atan(vLocal.z, vLocal.x);
  float fib = 0.5 + 0.5 * sin(ang * 90.0 + sin(ang * 7.0) * 3.0 + r * 2.0);
  float fib2 = 0.5 + 0.5 * sin(ang * 41.0 - r * 3.0);
  vec3 col = mix(ca, cb, fib * 0.55 + fib2 * 0.3);
  float coll = 1.0 - smoothstep(0.0, 0.25, abs(r - (pupil_r + 0.9)));
  col = mix(col, cb * 1.25, coll * 0.45);
  float margin = 1.0 - smoothstep(pupil_r, pupil_r + 0.2, r);
  col = mix(col, vec3(0.06, 0.03, 0.02), margin);
  col = mix(col, vec3(0.55, 0.06, 0.05), clamp(trauma, 0.0, 1.0) * 0.35 * fib2);
  if (!front) col = vec3(0.12, 0.06, 0.04);
  gl_FragColor = vec4(shade(col, N, 0.75, 0.1), 1.0);
}`, { pupil_r: { value: 3.6 }, trauma: { value: 0 } });
}

// Kapsul lensa: membran tipis berkilau, bukaan rhexis (64 bin), lubang PCR, gelombang hidro.
export function capsuleMaterial(alphaBase = 0.07) {
  return mat(/* glsl */ `
uniform float rhexis_r[64];
uniform float rhexis_on;
uniform float alpha_base;
uniform vec3 hole_pos;
uniform float hole_r;
uniform float wave;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  float r = length(vLocal.xz);
  float ang = atan(vLocal.z, vLocal.x);
  float a01 = mod(ang, TAU) / TAU * 64.0;
  int i0 = int(floor(a01)) % 64;
  int i1 = (i0 + 1) % 64;
  float rr = mix(rhexis_r[i0], rhexis_r[i1], fract(a01));
  if (rhexis_on > 0.5 && r < rr) discard;
  if (hole_r > 0.0 && distance(vWorld, hole_pos) < hole_r) discard;
  bool front; vec3 N = faceNormal(front);
  vec3 V = normalize(cameraPosition - vWorld);
  float fres = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 2.0);
  float edge = 0.0;
  if (rhexis_on > 0.5) edge = 1.0 - smoothstep(0.0, 0.18, r - rr);
  float a = alpha_base + fres * 0.22 + edge * 0.55;
  vec3 c = vec3(0.92, 0.95, 1.0);
  if (wave > 0.0) {
    float wr = wave * 4.6;
    float ring = 1.0 - smoothstep(0.0, 0.4, abs(r - wr));
    a += ring * 0.35;
    c = mix(c, vec3(0.7, 0.9, 1.0), ring);
  }
  gl_FragColor = vec4(shade(c, N, 0.1, 0.8), clamp(a, 0.0, 0.9));
}`, {
    rhexis_r: { value: new Float32Array(64) }, rhexis_on: { value: 0 }, alpha_base: { value: alphaBase },
    hole_pos: { value: new THREE.Vector3(0, -100, 0) }, hole_r: { value: 0 }, wave: { value: 0 },
  }, { transparent: true });
}

// Lapisan lensa (korteks / epinukleus): translusen, per-sektor & cincin emas hidrodelineasi.
export function lensLayerMaterial(color, alpha, { useSectors = false, periph = false } = {}) {
  return mat(/* glsl */ `
uniform vec3 color;
uniform float alpha;
uniform float amount;
uniform float sectors[24];
uniform float use_sectors;
uniform float periph;
uniform float golden_ring;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  float r = length(vWorld.xz);   // lensa berpusat di sumbu visual (x = z = 0)
  float ang = atan(vLocal.z, vLocal.x);
  float a = alpha * amount;
  if (use_sectors > 0.5) {
    float f = mod(ang, TAU) / TAU * 24.0;
    int i0 = int(floor(f)) % 24;
    int i1 = (i0 + 1) % 24;
    a *= mix(sectors[i0], sectors[i1], fract(f));
    a *= 0.7 + 0.3 * sin(ang * 48.0);
  }
  if (periph > 0.5) a *= smoothstep(1.6, 3.4, r);
  bool front; vec3 N = faceNormal(front);
  vec3 V = normalize(cameraPosition - vWorld);
  vec3 c = color;
  float rim = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 2.0);
  if (golden_ring > 0.0) {
    c = mix(c, vec3(1.0, 0.78, 0.25), rim * golden_ring);
    a += rim * golden_ring * 0.45;
  }
  if (a < 0.003) discard;
  gl_FragColor = vec4(shade(c, N, 0.4, 0.3), clamp(a, 0.0, 0.95));
}`, {
    color: { value: new THREE.Color(...color) }, alpha: { value: alpha }, amount: { value: 1 },
    sectors: { value: new Float32Array(24).fill(1) }, use_sectors: { value: useSectors ? 1 : 0 },
    periph: { value: periph ? 1 : 0 }, golden_ring: { value: 0 },
  }, { transparent: true });
}

// Nukleus katarak: warna & opasitas mengikuti grade kekerasan.
export function nucleusMaterial() {
  return mat(/* glsl */ `
uniform vec3 color;
uniform float alpha;
uniform float highlight;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  float r = length(vLocal.xz);
  bool front; vec3 N = faceNormal(front);
  vec3 c = mix(color * 0.72, color, smoothstep(0.0, 3.0, r));
  c *= 0.93 + 0.07 * sin(r * 14.0 + vLocal.y * 6.0);
  c = mix(c, vec3(0.6, 0.95, 1.0), highlight * 0.35);
  if (!front) c *= 0.7;
  gl_FragColor = vec4(shade(c, N, 0.55, 0.25), alpha);
}`, { color: { value: new THREE.Color(0.85, 0.72, 0.4) }, alpha: { value: 0.85 }, highlight: { value: 0 } },
  { transparent: true, depthWrite: true });
}

// Viskoelastik (OVD) di bilik depan: kilau kebiruan bergerak lembut.
export function fluidMaterial() {
  return mat(/* glsl */ `
uniform float amount;
void main() {
  if (cutaway > 0.5 && vWorld.z > 0.0) discard;
  float shimmer = 0.5 + 0.5 * sin(vWorld.x * 2.3 + time * 0.7) * sin(vWorld.z * 1.9 - time * 0.5);
  float a = clamp(amount, 0.0, 1.3) * (0.05 + 0.05 * shimmer);
  if (a < 0.002) discard;
  gl_FragColor = vec4(0.55, 0.8, 1.0, a);
}`, { amount: { value: 0 } }, { transparent: true });
}

// Kelopak + drape steril: bidang datar dengan bukaan elips (fisura palpebra).
export function eyelidMaterial() {
  return mat(/* glsl */ `
uniform float open;
void main() {
  float ax = 14.5;
  float az = 3.0 + 9.5 * open;
  float e = (vLocal.x * vLocal.x) / (ax * ax) + (vLocal.z * vLocal.z) / (az * az);
  if (e < 1.0) discard;
  vec3 c = vec3(0.86, 0.62, 0.52);
  float margin = 1.0 - smoothstep(1.0, 1.25, e);
  c = mix(c, vec3(0.72, 0.32, 0.3), margin);
  float lash = step(0.6, sin(vLocal.x * 9.0)) * (1.0 - smoothstep(1.02, 1.12, e)) * step(1.0, e);
  c = mix(c, vec3(0.08, 0.06, 0.05), lash * 0.6);
  float rr = length(vLocal.xz);
  float d = smoothstep(19.0, 20.0, rr);
  vec3 fab = vec3(0.12, 0.38, 0.42) * (0.9 + 0.1 * sin(vLocal.x * 3.0) * sin(vLocal.z * 3.0));
  c = mix(c, fab, d);
  bool front; vec3 N = faceNormal(front);
  gl_FragColor = vec4(shade(c, N, 0.8, 0.05), 1.0);
}`, { open: { value: 0.35 } });
}
