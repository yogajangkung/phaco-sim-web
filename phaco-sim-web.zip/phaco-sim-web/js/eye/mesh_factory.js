// MeshFactory — pembuat geometri prosedural (permukaan revolusi, tabung, dll).
import * as THREE from 'three';
import { TAU } from '../core/math.js';

/** Permukaan revolusi dari profil [[r, y], ...] diputar mengelilingi sumbu Y. */
export function revolve(profile, segments = 64, flip = false) {
  const n = profile.length;
  const pos = [], nor = [], uv = [], idx = [];
  const n2 = profile.map((_, i) => {
    const a = profile[Math.max(i - 1, 0)], b = profile[Math.min(i + 1, n - 1)];
    let tx = b[0] - a[0], ty = b[1] - a[1];
    let nx = -ty, ny = tx;
    const l = Math.hypot(nx, ny) || 1;
    nx /= l; ny /= l;
    return flip ? [-nx, -ny] : [nx, ny];
  });
  for (let i = 0; i < n; i++) {
    for (let s = 0; s <= segments; s++) {
      const ang = (TAU * s) / segments;
      const c = Math.cos(ang), sn = Math.sin(ang);
      const [r, y] = profile[i];
      pos.push(r * c, y, r * sn);
      const [nx, ny] = n2[i];
      const v = new THREE.Vector3(nx * c, ny, nx * sn).normalize();
      nor.push(v.x, v.y, v.z);
      uv.push(s / segments, i / (n - 1));
    }
  }
  const row = segments + 1;
  for (let i = 0; i < n - 1; i++) {
    for (let s = 0; s < segments; s++) {
      const a = i * row + s, b = (i + 1) * row + s, c = (i + 1) * row + s + 1, d = i * row + s + 1;
      idx.push(a, b, c, a, c, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  return g;
}

/** Profil ellipsoid setengah atas (sign=+1) atau bawah (sign=-1), dari pusat ke ekuator. */
export function ellipsoidProfile(a, b, sign, steps = 24) {
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * Math.PI * 0.5;
    pts.push([a * Math.sin(t), sign * b * Math.cos(t)]);
  }
  return pts;
}

/** Tabung halus melalui titik-titik (haptik IOL, spekulum). */
export function tube(points, radius, radial = 8, segments = 0) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new THREE.Vector3(p[0], p[1], p[2])));
  return new THREE.TubeGeometry(curve, segments || Math.max(8, points.length * 3), radius, radial, false);
}

/** Bidang datar XZ ukuran w×d. */
export function planeXZ(w, d, seg = 8) {
  const g = new THREE.PlaneGeometry(w, d, seg, seg);
  g.rotateX(-Math.PI / 2);
  return g;
}
