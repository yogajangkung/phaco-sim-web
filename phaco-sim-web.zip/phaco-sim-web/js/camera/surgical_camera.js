// SurgicalCamera — sudut pandang mikroskop operasi & inspeksi.
//   "scope"   : mikroskop koaksial (dari atas) — tampilan utama
//   "oblique" : mikroskop dimiringkan 35° — persepsi kedalaman bilik depan
//   "side"    : potongan melintang (cutaway) seperti slit-lamp
//   "orbit"   : orbit bebas (drag area kosong), dengan cutaway
import * as THREE from 'three';
import { clamp, expK, randRange, deg2rad } from '../core/math.js';

export const MODES = ['scope', 'oblique', 'side', 'orbit'];
export const MODE_NAMES = { scope: 'Mikroskop', oblique: 'Miring 35°', side: 'Potongan (Slit)', orbit: 'Orbit Bebas' };

export class SurgicalCamera {
  constructor(aspect) {
    this.camera = new THREE.PerspectiveCamera(24, aspect, 0.5, 200);
    this.mode = 'scope';
    this.zoom = 1.0;
    this.cs = null;
    this.orbit_yaw = 30;
    this.orbit_pitch = 35;
    this.orbit_dist = 36;
    this._shake = 0;
    this._pos = new THREE.Vector3(0, 34, 0);
    this._target = new THREE.Vector3();
  }

  cycleMode() {
    this.mode = MODES[(MODES.indexOf(this.mode) + 1) % MODES.length];
    return this.mode;
  }

  modeName() { return MODE_NAMES[this.mode] ?? this.mode; }
  usesCutaway() { return this.mode === 'side' || this.mode === 'orbit'; }

  orbitDrag(dx, dy) {
    if (this.mode !== 'orbit') return;
    this.orbit_yaw -= dx * 0.25;
    this.orbit_pitch = clamp(this.orbit_pitch + dy * 0.25, -10, 89);
  }

  shake(amount) { this._shake = Math.max(this._shake, amount); }

  update(dt) {
    const off = this.cs ? this.cs.scope_offset : { x: 0, y: 0 };
    const cam = this.camera;
    let tgtPos, tgt;
    const up = new THREE.Vector3(0, 0, -1);
    switch (this.mode) {
      case 'scope':
        tgt = new THREE.Vector3(-off.x, 0, -off.y);
        tgtPos = tgt.clone().add(new THREE.Vector3(0, 34, 0.01));
        cam.fov = 24 / this.zoom;
        break;
      case 'oblique': {
        tgt = new THREE.Vector3(-off.x, -0.5, -off.y);
        const a = deg2rad(35);
        tgtPos = tgt.clone().add(new THREE.Vector3(0, Math.cos(a) * 34, Math.sin(a) * 34));
        cam.fov = 24 / this.zoom;
        break;
      }
      case 'side':
        tgt = new THREE.Vector3(0, -1, 0);
        tgtPos = new THREE.Vector3(0, -0.5, 34);
        up.set(0, 1, 0);
        cam.fov = 30 / this.zoom;
        break;
      default: {
        tgt = new THREE.Vector3(0, -1, 0);
        const yaw = deg2rad(this.orbit_yaw), pit = deg2rad(this.orbit_pitch);
        tgtPos = tgt.clone().add(new THREE.Vector3(
          Math.sin(yaw) * Math.cos(pit), Math.sin(pit), Math.cos(yaw) * Math.cos(pit)).multiplyScalar(this.orbit_dist / this.zoom));
        up.set(0, 1, 0);
        cam.fov = 30;
      }
    }
    const k = expK(8, dt);
    this._pos.lerp(tgtPos, k);
    this._target.lerp(tgt, k);
    const jitter = new THREE.Vector3();
    if (this._shake > 0) {
      jitter.set(randRange(-1, 1), 0, randRange(-1, 1)).multiplyScalar(this._shake * 0.25);
      this._shake = Math.max(0, this._shake - dt * 2);
    }
    cam.position.copy(this._pos).add(jitter);
    const fwd = this._target.clone().sub(this._pos).normalize();
    if (Math.abs(fwd.dot(up)) > 0.98) {
      if (up.y === 1) up.set(0, 0, -1); else up.set(0, 1, 0);
    }
    cam.up.copy(up);
    cam.lookAt(this._target.clone().add(jitter));
    cam.updateProjectionMatrix();
  }
}
