// PhacoAudio — sintesis audio prosedural (tanpa file aset), Web Audio API.
//
// Lapisan suara:
//   * Ultrasound handpiece : nada ~380–900 Hz + harmonik, pitch & volume ∝ power
//   * Pompa peristaltik     : noise ber-filter dengan modulasi "rol" ∝ flow
//   * Irigasi               : desis halus saat pedal ≥ 1
//   * Nada vakum            : pitch naik seiring vakum saat oklusi (seperti mesin nyata)
//   * Alarm                 : beep dua nada saat komplikasi
// Synth berjalan di AudioWorklet (thread audio). Bila tidak tersedia (mis. halaman dibuka
// via http:// non-localhost), fallback ke ScriptProcessorNode dengan kode synth yang sama.

class PhacoSynth {
  constructor(sr) {
    this.sr = sr;
    this.p = { power: 0, flow: 0, vacuum: 0, vac_limit: 400, occluded: false, irrigating: false, gain: 0.7 };
    this.k = 22050 / sr;   // koefisien asli dirancang untuk 22.05 kHz
    this.ph = 0; this.ph2 = 0; this.vacPh = 0; this.roll = 0; this.alPh = 0;
    this.alTime = 0; this.alSev = 1;
    this.lp = 0; this.lp2 = 0;
    this.smP = 0; this.smF = 0; this.smV = 0;
  }

  set(msg) {
    if (msg.alarm) { this.alSev = msg.alarm; this.alTime = 0.35 + 0.3 * msg.alarm; return; }
    Object.assign(this.p, msg);
  }

  render(out) {
    const p = this.p, inv = 1 / this.sr, k = this.k, T = Math.PI * 2;
    for (let i = 0; i < out.length; i++) {
      this.smP += (p.power - this.smP) * 0.0015 * k;
      this.smF += (p.flow - this.smF) * 0.001 * k;
      this.smV += (p.vacuum - this.smV) * 0.002 * k;
      let s = 0;
      if (this.smP > 0.5) {
        const f = 380 + this.smP * 5.2;
        this.ph = (this.ph + f * inv) % 1;
        this.ph2 = (this.ph2 + f * 2.01 * inv) % 1;
        let tone = Math.sin(this.ph * T) * 0.55 + Math.sin(this.ph2 * T) * 0.25;
        tone += (this.ph < 0.5 ? 1 : -1) * 0.08;
        s += tone * Math.min(1, Math.max(0, this.smP / 100)) * 0.32;
      }
      const n = Math.random() * 2 - 1;
      this.lp += (n - this.lp) * 0.08 * k;
      this.lp2 += (n - this.lp2) * Math.min(1, 0.35 * k);
      if (this.smF > 0.5) {
        this.roll = (this.roll + (this.smF / 6) * inv) % 1;
        const roll = 0.55 + 0.45 * Math.sin(this.roll * T);
        s += this.lp * roll * Math.min(1, Math.max(0, this.smF / 40)) * 0.55 * 1.6;
      }
      if (p.irrigating) s += this.lp2 * 0.035;
      if (p.occluded && this.smV > 30) {
        const vf = 260 + 640 * Math.min(1.2, Math.max(0, this.smV / Math.max(p.vac_limit, 1)));
        this.vacPh = (this.vacPh + vf * inv) % 1;
        s += Math.sin(this.vacPh * T) * 0.09;
      }
      if (this.alTime > 0) {
        this.alTime -= inv;
        let af = (this.alTime % 0.24) > 0.12 ? 880 : 660;
        if (this.alSev >= 3) af *= 1.25;
        this.alPh = (this.alPh + af * inv) % 1;
        s += (this.alPh < 0.5 ? 1 : -1) * 0.12;
      }
      s *= p.gain;
      out[i] = s > 1 ? 1 : s < -1 ? -1 : s;
    }
  }
}

const WORKLET_SRC = `${PhacoSynth.toString()}
class PhacoProcessor extends AudioWorkletProcessor {
  constructor() { super(); this.syn = new PhacoSynth(sampleRate); this.port.onmessage = (e) => this.syn.set(e.data); }
  process(inputs, outputs) {
    const out = outputs[0];
    this.syn.render(out[0]);
    for (let c = 1; c < out.length; c++) out[c].set(out[0]);
    return true;
  }
}
registerProcessor('phaco-synth', PhacoProcessor);`;

export class PhacoAudio {
  constructor() {
    this.ctx = null;
    this.gain = 0.7;
    this._send = () => {};
    this._last = '';
    this.power = 0; this.flow = 0; this.vacuum = 0; this.vac_limit = 400;
    this.occluded = false; this.irrigating = false;
  }

  /** Harus dipanggil dari gesture pengguna (klik/tap) agar audio diizinkan browser. */
  async start() {
    if (this.ctx) { if (this.ctx.state !== 'running') await this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC({ latencyHint: 'interactive' });
    const master = this.ctx.createGain();
    master.gain.value = 0.6;
    master.connect(this.ctx.destination);
    try {
      if (!this.ctx.audioWorklet) throw new Error('no worklet');
      const url = URL.createObjectURL(new Blob([WORKLET_SRC], { type: 'application/javascript' }));
      await this.ctx.audioWorklet.addModule(url);
      const node = new AudioWorkletNode(this.ctx, 'phaco-synth', { outputChannelCount: [1] });
      node.connect(master);
      this._send = (m) => node.port.postMessage(m);
    } catch {
      const syn = new PhacoSynth(this.ctx.sampleRate);
      const sp = this.ctx.createScriptProcessor(1024, 0, 1);
      sp.onaudioprocess = (e) => syn.render(e.outputBuffer.getChannelData(0));
      sp.connect(master);
      this._send = (m) => syn.set(m);
    }
    if (this.ctx.state !== 'running') await this.ctx.resume();
  }

  alarm(sev) { this._send({ alarm: sev }); }

  /** Kirim parameter ke synth (hanya bila berubah, untuk menghemat message). */
  flush() {
    const m = {
      power: Math.round(this.power), flow: Math.round(this.flow), vacuum: Math.round(this.vacuum),
      vac_limit: this.vac_limit, occluded: this.occluded, irrigating: this.irrigating, gain: this.gain,
    };
    const key = JSON.stringify(m);
    if (key !== this._last) { this._last = key; this._send(m); }
  }
}
