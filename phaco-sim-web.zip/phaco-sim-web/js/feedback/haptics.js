// Haptics — pola getar untuk umpan balik taktil (Vibration API: navigator.vibrate).
// Didukung Chrome/Firefox Android. iOS Safari tidak mendukung (diam tanpa error).
// Amplitudo tidak tersedia di web; intensitas dipetakan ke durasi.
export class Haptics {
  constructor() {
    this.enabled = true;
    this.phacoBuzz = true;
    this._buzz = 0;
    this._cooldown = 0;
    this.supported = typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';
  }

  pulse(ms, amplitude = 0.5) {
    if (!this.enabled || !this.supported) return;
    try { navigator.vibrate(Math.max(5, Math.round(ms * (0.6 + 0.6 * amplitude)))); } catch { /* abaikan */ }
  }

  tick() { this.pulse(12, 0.25); }

  touchTissue() {
    if (this._cooldown > 0) return;
    this._cooldown = 0.12;
    this.pulse(35, 0.55);
  }

  crack() { this.pulse(90, 1.0); }
  tear() { this.pulse(18, 0.4); }
  detent() { this.pulse(15, 0.35); }

  alarm(sev) {
    if (sev === 1) this.pulse(60, 0.5);
    else if (sev === 2) this.pulse(180, 0.8);
    else if (this.enabled && this.supported) {
      try { navigator.vibrate([450, 80, 200]); } catch { /* abaikan */ }
    }
  }

  update(dt) { this._cooldown = Math.max(0, this._cooldown - dt); }

  /** Getar halus berulang selama ultrasound aktif (frekuensi naik dengan power). */
  phaco(powerPct, dt) {
    if (!this.phacoBuzz || powerPct <= 0) { this._buzz = 0; return; }
    this._buzz -= dt;
    if (this._buzz <= 0) {
      this._buzz = 0.22 + (0.09 - 0.22) * Math.min(1, Math.max(0, powerPct / 100));
      this.pulse(10, 0.15 + powerPct / 250);
    }
  }
}
