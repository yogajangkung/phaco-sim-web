// Kontrol sentuh multitouch: joystick analog, slider vertikal (kedalaman / pedal), tombol aksi.
// Pointer Events + setPointerCapture: tiap jari "terkunci" ke widget yang disentuh sampai
// diangkat, sehingga 3–4 jari bisa dipakai bersamaan (2 joystick + pedal + tombol).
// Mouse di desktop juga berfungsi (satu pointer).

function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

class Widget {
  constructor(parent, cls) {
    this.el = document.createElement('div');
    this.el.className = `widget ${cls}`;
    parent.appendChild(this.el);
    this.w = 100; this.h = 100;
    this.active = false;
    this._pid = null;
    this.el.addEventListener('pointerdown', (e) => {
      if (this._pid !== null) return;
      e.preventDefault();
      e.stopPropagation();
      this._pid = e.pointerId;
      try { this.el.setPointerCapture(e.pointerId); } catch { /* abaikan */ }
      this.touchBegin(this._local(e));
    });
    this.el.addEventListener('pointermove', (e) => {
      if (e.pointerId !== this._pid) return;
      e.preventDefault();
      this.touchMove(this._local(e));
    });
    const end = (e) => {
      if (e.pointerId !== this._pid) return;
      this._pid = null;
      this.touchEnd();
    };
    this.el.addEventListener('pointerup', end);
    this.el.addEventListener('pointercancel', end);
    this.el.addEventListener('lostpointercapture', end);
  }

  _local(e) {
    const r = this.el.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * this.w, y: ((e.clientY - r.top) / r.height) * this.h };
  }

  layout(x, y, w, h) {
    this.w = w; this.h = h;
    Object.assign(this.el.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
    this.redraw();
  }

  set visible(v) { this.el.style.display = v ? '' : 'none'; if (!v && this.active) this.touchEnd(); }
  get visible() { return this.el.style.display !== 'none'; }

  touchBegin() {}
  touchMove() {}
  touchEnd() {}
  redraw() {}
}

class CanvasWidget extends Widget {
  constructor(parent, cls) {
    super(parent, cls);
    this.canvas = document.createElement('canvas');
    this.el.appendChild(this.canvas);
    this.ctx = this.canvas.getContext('2d');
    this.labelEl = document.createElement('div');
    this.labelEl.className = 'widget-label';
    this.el.appendChild(this.labelEl);
    this._label = '';
  }

  set label(t) { if (t !== this._label) { this._label = t; this.labelEl.textContent = t; } }
  get label() { return this._label; }

  layout(x, y, w, h) {
    this.canvas.width = w;
    this.canvas.height = h;
    super.layout(x, y, w, h);
  }
}

/** Joystick analog. value: {x,y} -1..1 (y+ = ke bawah layar). */
export class VirtualJoystick extends CanvasWidget {
  constructor(parent, accent) {
    super(parent, 'joystick');
    this.accent = accent;
    this.value = { x: 0, y: 0 };
    this.deadZone = 0.08;
    this._knob = { x: 0, y: 0 };
  }

  radius() { return Math.min(this.w, this.h) * 0.5; }

  touchBegin(p) { this.active = true; this.touchMove(p); }

  touchMove(p) {
    let dx = p.x - this.w / 2, dy = p.y - this.h / 2;
    const r = this.radius() * 0.78;
    const l = Math.hypot(dx, dy);
    if (l > r) { dx *= r / l; dy *= r / l; }
    this._knob = { x: dx, y: dy };
    const vx = dx / r, vy = dy / r;
    const m = Math.hypot(vx, vy);
    if (m < this.deadZone) {
      this.value = { x: 0, y: 0 };
    } else {
      // kurva respons kuadratik untuk kontrol halus di dekat pusat
      const k = (m - this.deadZone) / (1 - this.deadZone);
      const s = (k * k * 0.7 + k * 0.3) / m;
      this.value = { x: vx * s, y: vy * s };
    }
    this.redraw();
  }

  touchEnd() {
    this.active = false;
    this._knob = { x: 0, y: 0 };
    this.value = { x: 0, y: 0 };
    this.redraw();
  }

  redraw() {
    const c = this.ctx, w = this.w, h = this.h, r = this.radius(), cx = w / 2, cy = h / 2, a = this.accent;
    c.clearRect(0, 0, w, h);
    c.fillStyle = 'rgba(13,26,33,0.45)';
    c.beginPath(); c.arc(cx, cy, r - 1, 0, Math.PI * 2); c.fill();
    c.lineWidth = 3; c.strokeStyle = hexA(a, 0.55);
    c.beginPath(); c.arc(cx, cy, r - 3, 0, Math.PI * 2); c.stroke();
    c.lineWidth = 2; c.strokeStyle = hexA(a, 0.18);
    c.beginPath(); c.arc(cx, cy, r * 0.78, 0, Math.PI * 2); c.stroke();
    c.lineWidth = 3; c.strokeStyle = hexA(a, 0.5);
    for (const ang of [0, Math.PI / 2, Math.PI, Math.PI * 1.5]) {
      c.beginPath();
      c.moveTo(cx + Math.cos(ang) * r * 0.86, cy + Math.sin(ang) * r * 0.86);
      c.lineTo(cx + Math.cos(ang) * r * 0.96, cy + Math.sin(ang) * r * 0.96);
      c.stroke();
    }
    const kx = cx + this._knob.x, ky = cy + this._knob.y;
    c.fillStyle = hexA(a, this.active ? 0.75 : 0.45);
    c.beginPath(); c.arc(kx, ky, r * 0.34, 0, Math.PI * 2); c.fill();
    c.fillStyle = 'rgba(255,255,255,0.25)';
    c.beginPath(); c.arc(kx, ky, r * 0.22, 0, Math.PI * 2); c.fill();
  }
}

/**
 * Slider vertikal.
 *   mode "spring": -1..1, kembali ke 0 saat dilepas (kedalaman instrumen)
 *   mode "pedal" : 0..1 (makin ke bawah makin dalam), marka zona 0/1/2/3, bisa dikunci
 */
export class VirtualSlider extends CanvasWidget {
  constructor(parent, mode, accent) {
    super(parent, `slider ${mode}`);
    this.mode = mode;
    this.accent = accent;
    this.value = 0;
    this.latched = false;
    this.display = 0;
    this.zones = [0.10, 0.35, 0.65];
    this.zoneColors = ['#808080', '#4db3ff', '#4dff80', '#ff8c33'];
  }

  touchBegin(p) { this.active = true; this.touchMove(p); }

  touchMove(p) {
    const t = Math.min(1, Math.max(0, p.y / Math.max(this.h, 1)));
    if (this.mode === 'spring') {
      this.value = Math.min(1, Math.max(-1, 1 - 2 * t));
      if (Math.abs(this.value) < 0.07) this.value = 0;
    } else {
      this.value = t;
    }
    this.redraw();
  }

  touchEnd() {
    this.active = false;
    if (!this.latched || this.mode === 'spring') this.value = 0;
    this.redraw();
  }

  setDisplay(v) {
    if (Math.abs(v - this.display) > 0.002) { this.display = v; this.redraw(); }
  }

  redraw() {
    const c = this.ctx, w = this.w, h = this.h, a = this.accent;
    c.clearRect(0, 0, w, h);
    c.fillStyle = 'rgba(13,26,33,0.5)';
    c.fillRect(0, 0, w, h);
    c.strokeStyle = hexA(a, 0.5); c.lineWidth = 2;
    c.strokeRect(1, 1, w - 2, h - 2);
    c.font = 'bold 22px system-ui, sans-serif';
    if (this.mode === 'spring') {
      const mid = h / 2;
      c.strokeStyle = 'rgba(255,255,255,0.3)';
      c.beginPath(); c.moveTo(6, mid); c.lineTo(w - 6, mid); c.stroke();
      const y = mid - this.value * mid;
      c.fillStyle = hexA(a, this.active ? 0.8 : 0.45);
      c.fillRect(4, y - 18, w - 8, 36);
      c.fillStyle = 'rgba(255,255,255,0.7)';
      c.textAlign = 'center';
      c.fillText('+', w / 2, 28);
      c.fillText('−', w / 2, h - 10);
    } else {
      const b = [0, ...this.zones, 1];
      c.textAlign = 'left';
      for (let z = 0; z < 4; z++) {
        const y0 = b[z] * h, y1 = b[z + 1] * h, col = this.zoneColors[z];
        c.fillStyle = hexA(col, 0.16);
        c.fillRect(2, y0, w - 4, y1 - y0);
        c.strokeStyle = hexA(col, 0.6);
        c.beginPath(); c.moveTo(0, y1); c.lineTo(w, y1); c.stroke();
        c.fillStyle = hexA(col, 0.95);
        c.font = 'bold 26px system-ui, sans-serif';
        c.fillText(String(z), 10, y0 + 32);
      }
      const yv = this.display * h;
      c.fillStyle = hexA(a, 0.25);
      c.fillRect(2, 0, w - 4, yv);
      c.fillStyle = `rgba(255,255,255,${this.active ? 0.85 : 0.55})`;
      c.fillRect(0, yv - 10, w, 20);
      const yt = this.value * h;
      c.strokeStyle = hexA(a, 0.9);
      c.beginPath(); c.moveTo(0, yt); c.lineTo(w, yt); c.stroke();
    }
  }
}

/** Tombol aksi multitouch (bisa ditahan bersamaan dengan joystick). */
export class TouchButton extends Widget {
  constructor(parent, { id = '', label = '', accent = '#ffcc4d', toggle = false, hotkey = '' } = {}) {
    super(parent, 'touch-btn');
    this.id = id;
    this.accent = accent;
    this.toggle = toggle;
    this.held = false;
    this.enabled = true;
    this._pressedFrame = false;
    this.textEl = document.createElement('span');
    this.textEl.className = 'touch-btn-text';
    this.keyEl = document.createElement('span');
    this.keyEl.className = 'touch-btn-key';
    this.el.append(this.textEl, this.keyEl);
    this.el.style.setProperty('--accent', accent);
    this.label = label;
    this.hotkey = hotkey;
  }

  set label(t) { this._label = t; this.textEl.innerHTML = t.split('\n').map(escapeHtml).join('<br>'); }
  get label() { return this._label; }
  set hotkey(k) { this.keyEl.textContent = k; }

  touchBegin() {
    if (!this.enabled) return;
    this.active = true;
    this._pressedFrame = true;
    this.held = this.toggle ? !this.held : true;
    this.redraw();
  }

  touchEnd() {
    this.active = false;
    if (!this.toggle) this.held = false;
    this.redraw();
  }

  consumePress() { const p = this._pressedFrame; this._pressedFrame = false; return p; }

  setHeld(v) { this.held = v; this.redraw(); }

  redraw() { this.el.classList.toggle('held', this.held); }
}

export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
