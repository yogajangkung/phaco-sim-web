// InstrumentRig — dua tangan (kanan = instrumen utama, kiri = sekunder) + "bayangan tip"
// (proyeksi ke permukaan di bawahnya) sebagai isyarat kedalaman.
import * as THREE from 'three';
import { Instrument } from './instrument.js';
import * as A from '../core/anatomy.js';
import { V3, clamp, lerp } from '../core/math.js';

export const COLOR_RIGHT = '#33e6ff';
export const COLOR_LEFT = '#ff59d9';

export class InstrumentRig extends THREE.Group {
  constructor() {
    super();
    this.right = new Instrument('right', COLOR_RIGHT);
    this.left = new Instrument('left', COLOR_LEFT);
    this.add(this.right, this.left);
    this._shadowR = this._makeShadow(COLOR_RIGHT);
    this._shadowL = this._makeShadow(COLOR_LEFT);
    this.cs = null;
  }

  _makeShadow(c) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.01, 20),
      new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.5, depthWrite: false }));
    m.renderOrder = 7;
    m.visible = false;
    this.add(m);
    return m;
  }

  getTool(which) { return which === 'right' ? this.right : this.left; }

  /** Pasang instrumen melalui port (insisi). Tip diletakkan sedikit di dalam bilik. */
  insert(which, type, port, depthIn = 1.8) {
    const t = this.getTool(which);
    t.setTool(type, port);
    if (port) {
      const inner = port.inner;
      const dir = new V3(-inner.x, 0, -inner.z).normalized();
      t.tip = inner.add(dir.mul(depthIn));
      t.tip.y = 1.0;
      t.inside = true;
    }
    t.prev_tip = t.tip.clone();
    t.in_bag = false;
    t.updateVisual();
    return t;
  }

  /** Instrumen tanpa port (pisau insisi) mulai di luar limbus pada meridian tertentu. */
  placeOutside(which, type, thetaDeg) {
    const t = this.getTool(which);
    t.setTool(type, null);
    t.approach_deg = thetaDeg;
    t.tip = A.pointOnLimbus(thetaDeg, 0.55, A.LIMBUS_R + 1.4);
    t.prev_tip = t.tip.clone();
    t.inside = false;
    t.updateVisual();
    return t;
  }

  remove(which) { this.getTool(which).setTool(''); }
  removeAll() { this.remove('right'); this.remove('left'); }

  updateShadows() {
    this._updateShadow(this.right, this._shadowR);
    this._updateShadow(this.left, this._shadowL);
  }

  _updateShadow(t, s) {
    if (t.tool_type === '' || !t.inside) { s.visible = false; return; }
    const cs = this.cs;
    const r = A.radial(t.tip);
    let floorY = A.IRIS_Y;
    if (cs && r < cs.pupil_r) {
      floorY = A.capsuleAnteriorY(r);
      if (cs.rhexis_done && r < cs.rhexisRadiusAt(A.meridianDeg(t.tip))) {
        let top = cs.nucleus.surfaceUnder(t.tip);
        if (Number.isNaN(top)) {
          top = A.capsulePosteriorY(r) + 0.05;
          if (cs.iol_present && cs.iol_progress >= 1) top = cs.iol_y + 0.08;
        }
        floorY = top;
      }
      if (t.tip.y < floorY) floorY = A.capsulePosteriorY(r) + 0.02;
    }
    s.visible = true;
    s.position.set(t.tip.x, floorY + 0.02, t.tip.z);
    const gap = clamp((t.tip.y - floorY) / 2, 0, 1);
    s.scale.setScalar(lerp(0.6, 2.2, gap));
    s.material.opacity = lerp(0.75, 0.15, gap);
  }
}
