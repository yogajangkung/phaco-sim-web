// Instrument — satu instrumen bedah (visual prosedural three.js + state posisi tip).
//
// Geometri dibangun di frame lokal: tip di origin, batang mengarah ke +Z (keluar mata).
// Setiap frame node diorientasikan agar batang melewati titik pivot di insisi (fulcrum),
// sehingga gerakan tip terlihat seperti instrumen nyata yang berporos di luka.
import * as THREE from 'three';
import { V3, deg2rad, rad2deg } from '../core/math.js';

export const TOOL_NAMES = {
  blade15: 'Pisau 15° (side-port)',
  keratome: 'Keratome 2.4 mm',
  cannula: 'Kanula 27G',
  cystotome: 'Sistotom',
  phaco: 'Phaco handpiece',
  chopper: 'Chopper / Manipulator',
  ia: 'Handpiece I/A',
  injector: 'Injector IOL',
  hook: 'Sinskey hook',
};

const MAT = {
  steel: new THREE.MeshPhongMaterial({ color: 0xc7ccd6, specular: 0xffffff, shininess: 110 }),
  sleeve: new THREE.MeshPhongMaterial({ color: 0xb8dbf2, transparent: true, opacity: 0.55, shininess: 60, depthWrite: false }),
  dark: new THREE.MeshBasicMaterial({ color: 0x141419 }),
  handle: new THREE.MeshPhongMaterial({ color: 0x406b99, specular: 0x8899aa, shininess: 50 }),
};

// Pada kamera Potongan/Orbit (cutaway), gagang instrumen di z > 7 mm (di luar bola mata,
// arah kamera samping) dipotong agar tidak menutupi pandangan.
const CUT_PLANE = [new THREE.Plane(new THREE.Vector3(0, 0, -1), 7)];
export function setInstrumentCutaway(on) {
  for (const m of Object.values(MAT)) {
    m.clippingPlanes = on ? CUT_PLANE : [];
    m.needsUpdate = true;
  }
}

export class Instrument extends THREE.Group {
  constructor(side, markerColor) {
    super();
    this.tool_type = '';
    this.tip = new V3();
    this.prev_tip = new V3();
    this.port = null;
    this.approach_deg = 180;
    this.in_bag = false;
    this.posterior_gap = 99;
    this.inside = false;
    this.side = side;
    this.marker_color = markerColor;
    this._geom = null;
    this.visible = false;
    this.renderOrder = 8;
  }

  setTool(t, port = null) {
    this.tool_type = t;
    this.port = port;
    this.in_bag = false;
    if (this._geom) {
      this.remove(this._geom);
      this._geom.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    }
    this._geom = new THREE.Group();
    this.add(this._geom);
    this.visible = t !== '';
    if (t === '') return;
    this._build(t);
    const marker = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 8),
      new THREE.MeshBasicMaterial({ color: this.marker_color }));
    this._geom.add(marker);
  }

  displayName() { return TOOL_NAMES[this.tool_type] ?? this.tool_type; }

  _mesh(geo, mat, pos = [0, 0, 0], rotX = 0) {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(pos[0], pos[1], pos[2]);
    m.rotation.x = rotX;
    m.renderOrder = 8;
    this._geom.add(m);
    return m;
  }

  /** Silinder sepanjang +Z dari z0 ke z1 (r0 di z0, r1 di z1). */
  _rod(z0, z1, r0, r1, mat, y = 0) {
    this._mesh(new THREE.CylinderGeometry(r1, r0, z1 - z0, 12, 1), mat, [0, y, (z0 + z1) * 0.5], Math.PI / 2);
  }

  /** Bilah segitiga: ujung di z=0, pangkal di z=length. */
  _blade(width, length) {
    const s = new THREE.Shape();
    s.moveTo(0, 0);
    s.lineTo(width / 2, length);
    s.lineTo(-width / 2, length);
    s.closePath();
    const g = new THREE.ExtrudeGeometry(s, { depth: 0.06, bevelEnabled: false });
    g.rotateX(Math.PI / 2);     // y(bentuk) -> z, z(ekstrusi) -> -y
    g.translate(0, 0.03, 0);
    this._mesh(g, MAT.steel);
  }

  _disc(r) { return new THREE.CylinderGeometry(r, r, 0.02, 16); }

  _build(t) {
    switch (t) {
      case 'blade15':
        this._blade(0.9, 1.4);
        this._rod(1.3, 9, 0.22, 0.32, MAT.steel);
        this._rod(9, 40, 1.6, 1.8, MAT.handle);
        break;
      case 'keratome':
        this._blade(2.4, 2.6);
        this._rod(2.5, 10, 0.3, 0.4, MAT.steel);
        this._rod(10, 40, 1.6, 1.8, MAT.handle);
        break;
      case 'cannula':
        this._rod(0, 9, 0.2, 0.2, MAT.steel);
        this._rod(9, 24, 1.2, 2.0, MAT.sleeve);
        break;
      case 'cystotome':
        this._mesh(new THREE.CylinderGeometry(0.09, 0.05, 0.45, 8), MAT.steel, [0, 0.22, 0]);
        this._rod(0, 10, 0.16, 0.16, MAT.steel, 0.42);
        this._rod(10, 26, 1.2, 2.0, MAT.sleeve, 0.42);
        break;
      case 'phaco':
        this._rod(0, 1.3, 0.45, 0.45, MAT.steel);
        this._rod(1.1, 10, 0.72, 0.8, MAT.sleeve);
        this._rod(10, 16, 0.9, 3.0, MAT.steel);
        this._rod(16, 45, 3.0, 3.0, MAT.handle);
        this._mesh(this._disc(0.32), MAT.dark, [0, 0, -0.01], Math.PI / 2);
        break;
      case 'chopper':
      case 'hook': {
        const hl = t === 'chopper' ? 0.9 : 0.5;
        this._mesh(new THREE.CylinderGeometry(0.12, 0.1, hl, 8), MAT.steel, [0, hl * 0.5, 0]);
        this._rod(0, 11, 0.2, 0.24, MAT.steel, hl);
        this._rod(11, 40, 1.5, 1.7, MAT.handle, hl);
        break;
      }
      case 'ia':
        this._rod(0, 1.3, 0.35, 0.35, MAT.steel);
        this._rod(1.1, 10, 0.62, 0.7, MAT.sleeve);
        this._rod(10, 16, 0.8, 3.0, MAT.steel);
        this._rod(16, 45, 3.0, 3.0, MAT.handle);
        this._mesh(this._disc(0.12), MAT.dark, [0, 0.34, 0.5]);
        break;
      case 'injector':
        this._rod(0, 1.2, 0.75, 0.8, MAT.sleeve);
        this._rod(1.2, 9, 0.8, 1.8, MAT.sleeve);
        this._rod(9, 45, 3.2, 3.2, MAT.handle);
        break;
      default:
        this._rod(0, 12, 0.2, 0.2, MAT.steel);
    }
  }

  // ---------- orientasi ----------
  pivotPoint() {
    if (!this.port) return new V3();
    return this.port.inner.add(this.port.outer).mul(0.5);
  }

  outwardDir() {
    let dir;
    if (!this.port) {
      const a = deg2rad(this.approach_deg);
      dir = new V3(Math.cos(a), 0.3, Math.sin(a));
    } else {
      dir = this.pivotPoint().sub(this.tip);
      if (dir.length() < 0.6) dir = this.port.outer.sub(this.port.inner);
      dir.y = Math.max(dir.y, 0.05) + 0.15;
    }
    return dir.normalized();
  }

  /** Sudut (derajat) antara batang & sumbu terowongan insisi — deteksi oarlocking. */
  woundAngle() {
    if (!this.port) return 0;
    const axis = this.port.outer.sub(this.port.inner);
    axis.y = 0;
    const shaft = this.outwardDir();
    shaft.y = 0;
    if (axis.length() < 0.01 || shaft.length() < 0.01) return 0;
    return rad2deg(axis.angleTo(shaft));
  }

  updateVisual() {
    if (this.tool_type === '') return;
    const t = this.tip;
    this.position.set(t.x, t.y, t.z);
    const out = this.outwardDir();
    if (Math.abs(out.y) > 0.97) this.up.set(0, 0, -1);
    else this.up.set(0, 1, 0);
    // Object3D.lookAt mengarahkan +Z lokal ke target -> batang (+Z) mengarah keluar
    this.lookAt(t.x + out.x, t.y + out.y, t.z + out.z);
  }
}
