// Uji asap (smoke test): buka index.html?smoke — menjalankan tiap langkah dalam mode
// sandbox dengan input acak (fuzz), lalu mode terpandu dengan "Lewati" sampai laporan.
// Hasil ditulis ke console dan ke <pre id="smoke-result">.
import { V2 } from '../core/math.js';

export function runSmoke(sim, framesPerStep = 240) {
  const out = [];
  const errors = [];
  const log = (s) => { out.push(s); console.log('SMOKE:', s); };
  window.addEventListener('error', (e) => errors.push(String(e.message)));
  sim.renderer.setAnimationLoop(null);   // jalankan sinkron

  const rnd = (a, b) => a + Math.random() * (b - a);
  const randInput = () => {
    const held = {}, pressed = {};
    for (const a of sim.fsm.current?.actions ?? []) {
      held[a.id] = Math.random() < 0.3;
      pressed[a.id] = Math.random() < 0.05;
    }
    return {
      rs: new V2(rnd(-1, 1), rnd(-1, 1)).limitLength(1), ls: new V2(rnd(-1, 1), rnd(-1, 1)).limitLength(1),
      rd: rnd(-1, 1), ld: rnd(-1, 1), pedal: Math.random(), reflux: Math.random() < 0.05,
      fine: Math.random() < 0.5, held, pressed,
    };
  };
  const frame = (dt) => {
    sim.eye.updateFromCase(dt, sim.injector_tip, sim.injector_dir);
    sim.rig.updateShadows();
    sim.cam.update(dt);
    sim.hud.refresh(dt);
    sim.renderer.render(sim.scene, sim.cam.camera);
  };

  const t0 = performance.now();
  try {
    for (const tech of ['dc', 'chop']) {
      sim.caseState.technique = tech;
      for (let i = 0; i < sim.fsm.steps.length; i++) {
        sim.hud._setMenu(false);
        sim.startProcedure('sandbox', i);
        for (let f = 0; f < framesPerStep; f++) {
          sim.step(1 / 60, randInput());
          if (f % 8 === 0) frame(1 / 60);
        }
        log(`[${tech}] langkah ${i + 1} OK — ${sim.fsm.current?.title ?? '(selesai)'} · komplikasi ${sim.complications.events.length}`);
      }
    }
    scenarios(sim, log, errors);
    sim.caseState.technique = 'dc';
    sim.startProcedure('sandbox', 0);
    let guard = 0;
    while (sim.fsm.running && guard++ < 20) { sim.fsm.skipCurrent(); frame(1 / 60); }
    log(`skip-through selesai, laporan tampil = ${sim.hud.reportVisible}`);
  } catch (e) {
    errors.push(String(e?.stack || e));
  }
  log(`waktu ${(performance.now() - t0).toFixed(0)} ms, error = ${errors.length}`);
  for (const e of errors) log(`ERROR ${e}`);
  const pre = document.createElement('pre');
  pre.id = 'smoke-result';
  pre.textContent = out.join('\n');
  document.body.appendChild(pre);
  document.title = errors.length ? 'SMOKE FAIL' : 'SMOKE PASS';
}

// ---------------------------------------------------------------- skenario deterministik
const idle = () => ({ rs: new V2(), ls: new V2(), rd: 0, ld: 0, pedal: 0, reflux: false, fine: true, held: {}, pressed: {} });
const steer = (tip, tx, tz, gain = 2) => new V2((tx - tip.x) * gain, (tz - tip.z) * gain).limitLength(1);

function run(sim, seconds, fn) {
  const n = Math.round(seconds * 60);
  for (let i = 0; i < n; i++) { const inp = idle(); if (fn(inp, i / 60) === false) break; sim.step(1 / 60, inp); }
}

function scenarios(sim, log, errors) {
  const cs = sim.caseState;
  const check = (name, ok, detail) => { log(`${ok ? 'PASS' : 'FAIL'} ${name} — ${detail}`); if (!ok) errors.push(`skenario gagal: ${name}`); };

  // A. CCC: turun ke kapsul di tengah, grasp, tarik ke r≈2.6 lalu sapu melingkar 360°
  sim.startProcedure('sandbox', 4);
  const t = sim.rig.right;
  run(sim, 4, (inp) => { inp.rs = steer(t.tip, 0, 0); inp.rd = -1; inp.held.grasp = true; return !sim.fsm.current.isDone('init'); });
  let ang = 0;
  run(sim, 40, (inp) => {
    inp.held.grasp = true;
    inp.held.ovd = cs.ovd_ac < 1.0;
    const r = Math.hypot(t.tip.x, t.tip.z);
    if (r < 2.4 && ang === 0) { inp.rs = steer(t.tip, 2.9, 0, 3); }
    else { ang += 0.75 / 60; inp.rs = steer(t.tip, Math.cos(ang) * 2.75, Math.sin(ang) * 2.75, 3); }
    inp.rd = -0.3;
    return !cs.rhexis_done;
  });
  check('Kapsulorheksis 360°', cs.rhexis_done && sim.fsm.canAdvance(),
    `selesai=${cs.rhexis_done}, Ø=${(cs.rhexisMeanRadius() * 2).toFixed(2)} mm, run-out=${cs.rhexis_tear_deg >= 0}`);

  // B. PCR: phaco tip didorong ke bawah di tengah dengan pedal 3
  sim.startProcedure('sandbox', 6);
  const ph = sim.rig.right;
  run(sim, 40, (inp) => { inp.rs = steer(ph.tip, 0.5, 0); inp.rd = -1; inp.pedal = 0.95; return !cs.pcr; });
  check('PCR terdeteksi', cs.pcr && sim.complications.count('pcr') === 1,
    `pcr=${cs.pcr}, sisa nukleus=${Math.round(cs.nucleus.remainingFraction() * 100)}%, CDE=${cs.phaco_cde.toFixed(2)}`);

  // C. Sculpt D&C: sapuan bolak-balik sepanjang meridian 0°–180° pada pedal 3 → alur pertama
  sim.caseState.technique = 'dc';
  sim.startProcedure('sandbox', 6);
  // kedalaman dikendalikan: tiap sapuan sedikit lebih dalam, berhenti ±75% tebal nukleus
  let dir = 1, targetY = -0.9;
  run(sim, 150, (inp) => {
    if (ph.tip.x > 2.3 && dir > 0) { dir = -1; targetY = Math.max(-3.05, targetY - 0.35); }
    if (ph.tip.x < -2.3 && dir < 0) { dir = 1; targetY = Math.max(-3.05, targetY - 0.35); }
    inp.rs = new V2(dir, (0 - ph.tip.z) * 3).limitLength(1);
    inp.rd = Math.max(-1, Math.min(1, (targetY + cs.diaphragmShift() - ph.tip.y) * 2));
    inp.pedal = ph.in_bag ? 0.95 : 0.2;
    return !sim.fsm.current.isDone('trench1');
  });
  const st = sim.fsm.current;
  check('Sculpt alur pertama', st.isDone('trench1'),
    `fase=${st.phase}, sisa nukleus=${Math.round(cs.nucleus.remainingFraction() * 100)}%, PCR=${cs.pcr}`);

  // D. Surge: oklusi fragmen dgn vakum tinggi lalu lepas → surge_event / komplikasi surge
  sim.startProcedure('sandbox', 6);
  sim.fsm.current.applyIdeal();   // nukleus kosong; buat 4 kuadran baru untuk dipegang
  cs.nucleus.setup(cs.nucleus_grade);
  cs.nucleus.addCrackLine(0); cs.nucleus.addCrackLine(90);
  sim.fsm.current._setPhase('quadrants');
  sim.fluidics.vac_limit = 600; sim.fluidics.bottle_cm = 50;
  // turun ke fragmen (pedal 1), lalu pedal 2 sampai vakum oklusi menumpuk
  run(sim, 12, (inp) => {
    inp.rs = steer(ph.tip, 1.2, 1.2);
    inp.rd = -0.8;
    inp.pedal = sim.fluidics.occluded || ph.tip.y < -0.6 ? 0.6 : 0.2;
    return sim.fluidics.vacuum < 400;
  });
  const vacHeld = sim.fluidics.vacuum;
  let surgeMax = 0;
  // fragmen hilang dari port (mis. teremulsi habis) -> oklusi pecah
  cs.nucleus.clearAll();
  run(sim, 1, (inp) => { inp.pedal = 0.6; surgeMax = Math.max(surgeMax, sim.fluidics.surge_event); });
  check('Oklusi → surge saat oklusi pecah', vacHeld > 300 && sim.complications.count('surge') === 1,
    `vakum oklusi=${Math.round(vacHeld)} mmHg, surge pada ${Math.round(surgeMax)} mmHg, kejadian surge=${sim.complications.count('surge')}, kamera shake`);
}
