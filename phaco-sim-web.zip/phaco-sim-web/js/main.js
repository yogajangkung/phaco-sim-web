// Main — composition root. Membuat & menghubungkan semua subsistem:
//
//   CaseState ──► EyeModel (visual)          FootPedal ──► Fluidics ──► PhacoAudio
//       ▲                                         ▲
//       │      ProcedureStateMachine ──► Step[1..11] (logika & validasi per langkah)
//       │              │                     │
//   SafetyMonitor ◄────┘          InstrumentRig (2 tangan)  ◄── Hud (input sentuh/keyboard)
//       │
//   ComplicationManager ──► Hud banner, Haptics, Audio alarm, ScoreTracker
//
// Loop per frame: input -> pedal -> step.update() -> monitor global -> sinkron visual -> HUD.
import * as THREE from 'three';
import { CaseState } from './core/case_state.js';
import { FootPedal } from './sim/foot_pedal.js';
import { Fluidics } from './sim/fluidics.js';
import { ComplicationManager } from './core/complication_manager.js';
import { ScoreTracker } from './core/score_tracker.js';
import { SafetyMonitor } from './core/safety_monitor.js';
import { ProcedureStateMachine } from './core/procedure_state_machine.js';
import { Haptics } from './feedback/haptics.js';
import { PhacoAudio } from './feedback/phaco_audio.js';
import { EyeModel } from './eye/eye_model.js';
import { InstrumentRig } from './instruments/instrument_rig.js';
import { SurgicalCamera } from './camera/surgical_camera.js';
import { Hud } from './ui/hud.js';
import { STEPS } from './steps/index.js';
import { V3 } from './core/math.js';

THREE.ColorManagement.enabled = false;

class PhacoSim {
  constructor() {
    this.canvas = document.getElementById('view');
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setClearColor(new THREE.Color(0.01, 0.015, 0.02));
    this.renderer.localClippingEnabled = true;
    this.scene = new THREE.Scene();
    this._setupWorld();

    this.caseState = new CaseState();
    this.pedal = new FootPedal();
    this.fluidics = new Fluidics();
    this.complications = new ComplicationManager();
    this.score = new ScoreTracker();
    this.haptics = new Haptics();
    this.audio = new PhacoAudio();
    this.safety = new SafetyMonitor();
    this.safety.setup(this.caseState, this.complications, this.haptics);

    this.eye = new EyeModel(this.caseState);
    this.scene.add(this.eye);
    this.rig = new InstrumentRig();
    this.rig.cs = this.caseState;
    this.scene.add(this.rig);
    this.cam = new SurgicalCamera(window.innerWidth / window.innerHeight);
    this.cam.cs = this.caseState;

    this.injector_tip = new V3();
    this.injector_dir = new V3(-1, 0, 0);

    this.fsm = new ProcedureStateMachine();
    this.fsm.setup(this, STEPS);

    this.hud = new Hud(this, document.getElementById('hud'), this.canvas);
    this.complications.onRaised((ev) => this._onComplication(ev));
    this.fsm.onStepChanged = (st) => this.hud.onStepChanged(st);
    this.fsm.onFinished = (r) => { this.rig.removeAll(); this.hud.showReport(r); };
    this.hud.showMenu();

    this._last = performance.now();
    this.renderer.setAnimationLoop((t) => this._frame(t));
  }

  _setupWorld() {
    // lampu koaksial mikroskop (dari atas) + lampu kerja miring untuk specular
    // (intensitas ×π karena three r155+ memakai satuan fisik)
    this.scene.add(new THREE.AmbientLight(new THREE.Color(0.55, 0.55, 0.6), 0.4 * Math.PI));
    const key = new THREE.DirectionalLight(0xffffff, 0.55 * Math.PI);
    key.position.set(0, 30, 1);
    this.scene.add(key);
    const fill = new THREE.PointLight(0xffffff, 0.6 * Math.PI, 60, 0);
    fill.position.set(6, 22, 8);
    this.scene.add(fill);
  }

  onResize(w, h) {
    this.renderer.setSize(w, h, false);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.cam.camera.aspect = w / h;
    this.cam.camera.updateProjectionMatrix();
  }

  async requestFullscreen() {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
      await screen.orientation?.lock?.('landscape');
    } catch { /* tidak didukung (mis. iOS) */ }
  }

  resetCase() {
    this.caseState.reset();
    this.fluidics.reset();
    this.complications.reset();
    this.score.reset();
    this.pedal.setTarget(0);
    this.pedal.travel = 0;
    this.rig.removeAll();
    this.eye.resetVisuals();
  }

  startProcedure(mode, fromIndex) { this.fsm.start(mode, fromIndex); }

  /** Satu langkah simulasi (dipisah dari render agar bisa diuji headless). */
  step(dt, input) {
    const cs = this.caseState;
    this.pedal.setTarget(input.pedal);
    this.pedal.reflux = input.reflux;
    this.pedal.update(dt);
    const st = this.fsm.current;
    if (st && st.uses_pedal && this.pedal.detentCrossed) this.haptics.detent();
    this.complications.tick(dt);
    this.fsm.update(dt, input);
    this._globalMonitors();
    cs.syncDerived();
    this._updateAudio(this.fsm.current);
  }

  _frame(now) {
    // timestamp rAF bisa lebih awal dari performance.now() saat start -> jaga dt ≥ 0
    const dt = Math.max(0, Math.min((now - this._last) / 1000, 0.05));
    this._last = Math.max(now, this._last);
    const hud = this.hud;
    if (this.fsm.running && !hud.menuVisible && !hud.reportVisible) {
      this.step(dt, hud.collectInput());
    } else {
      Object.assign(this.audio, { power: 0, flow: 0, occluded: false, irrigating: false });
    }
    this.audio.flush();
    this.haptics.update(dt);
    this.eye.updateFromCase(dt, this.injector_tip, this.injector_dir);
    this.rig.updateShadows();
    this.cam.update(dt);
    hud.refresh(dt);
    this.renderer.render(this.scene, this.cam.camera);
  }

  _updateAudio(step) {
    const f = this.fluidics, a = this.audio;
    const active = !!step && step.uses_pedal && step.pedal_label === 'PEDAL';
    a.power = active ? f.power : 0;
    a.flow = active ? Math.max(f.flow, 0) : 0;
    a.vacuum = f.vacuum;
    a.vac_limit = f.vac_limit;
    a.occluded = active && f.occluded;
    a.irrigating = active && this.pedal.irrigating();
  }

  /** Aturan lintas-langkah (komplikasi yang bisa terjadi kapan saja). */
  _globalMonitors() {
    const cs = this.caseState;
    const main = cs.getIncision('main');
    if (main && !cs.iris_prolapse && main.tunnel < 1.2 && cs.iop > 32) {
      cs.iris_prolapse = true;
      this.complications.report('iris_prolapse', `terowongan ${main.tunnel.toFixed(1)} mm`);
    }
    if (cs.zonular_stress > 1 && !cs.zonular_dialysis) {
      cs.zonular_dialysis = true;
      this.complications.report('zonular');
    }
  }

  _onComplication(ev) {
    this.hud.alert(ev);
    this.haptics.alarm(ev.severity);
    this.audio.alarm(ev.severity);
    if (ev.severity >= 3) this.cam.shake(0.8);
  }
}

try {
  window.phacoSim = new PhacoSim();
  const qs = new URLSearchParams(location.search);
  if (qs.has('smoke')) import('./dev/smoke.js').then((m) => m.runSmoke(window.phacoSim));
  if (qs.has('step')) {   // dev: langsung ke langkah N (sandbox), mis. ?step=7&view=oblique
    window.phacoSim.hud._setMenu(false);
    window.phacoSim.startProcedure('sandbox', Number(qs.get('step')) - 1);
    if (qs.get('view')) {
      while (window.phacoSim.cam.mode !== qs.get('view')) window.phacoSim.hud._onView();
    }
  }
} catch (err) {
  console.error(err);
  const e = document.getElementById('fatal');
  e.style.display = 'flex';
  e.querySelector('pre').textContent = String(err?.stack || err);
}
