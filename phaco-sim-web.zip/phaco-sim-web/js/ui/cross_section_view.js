// CrossSectionView — inset 2D potongan melintang mata di sepanjang meridian instrumen.
// Membantu persepsi kedalaman pada layar HP (jarak tip ke endotel & kapsul posterior).
import * as A from '../core/anatomy.js';
import { clamp, lerp } from '../core/math.js';

export class CrossSectionView {
  constructor(parent, cs, rig) {
    this.el = document.createElement('canvas');
    this.el.className = 'cross';
    parent.appendChild(this.el);
    this.ctx = this.el.getContext('2d');
    this.cs = cs;
    this.rig = rig;
    this._dir = { x: 1, y: 0 };
    this.w = 460; this.h = 195;
  }

  layout(x, y, w, h) {
    this.w = w; this.h = h;
    this.el.width = w; this.el.height = h;
    Object.assign(this.el.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
  }

  // s: -6.5..6.5 mm ; y: -5..3.6 mm
  _map(s, y) { return [((s + 6.5) / 13) * this.w, ((3.6 - y) / 8.6) * this.h]; }

  _curve(f, s0, s1, col, width = 2) {
    const c = this.ctx;
    c.strokeStyle = col; c.lineWidth = width;
    c.beginPath();
    for (let i = 0; i <= 40; i++) {
      const s = lerp(s0, s1, i / 40);
      const [x, y] = this._map(s, f(Math.abs(s)));
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.stroke();
  }

  _line(s0, y0, s1, y1, col, width) {
    const c = this.ctx;
    const [ax, ay] = this._map(s0, y0), [bx, by] = this._map(s1, y1);
    c.strokeStyle = col; c.lineWidth = width;
    c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke();
  }

  redraw() {
    const c = this.ctx, cs = this.cs, w = this.w, h = this.h;
    c.clearRect(0, 0, w, h);
    c.fillStyle = 'rgba(5,13,18,0.72)';
    c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(102,204,255,0.4)'; c.lineWidth = 1.5;
    c.strokeRect(1, 1, w - 2, h - 2);
    const shift = cs.diaphragmShift();
    this._curve(A.corneaOuterY, -A.LIMBUS_R, A.LIMBUS_R, 'rgba(179,217,255,0.9)', 2);
    this._curve(A.corneaInnerY, -A.LIMBUS_R, A.LIMBUS_R, 'rgba(128,179,255,0.7)', 1.5);
    const pr = cs.pupil_r, iy = A.IRIS_Y + shift;
    this._line(-A.IRIS_OUTER_R, iy, -pr, iy, '#b37340', 4);
    this._line(pr, iy, A.IRIS_OUTER_R, iy, '#b37340', 4);
    const bulge = clamp(1 - cs.chamber_depth, 0, 0.8) * 0.9;
    this._curve((r) => A.capsuleAnteriorY(r) + shift, -A.LENS_A, A.LENS_A, 'rgba(230,242,255,0.8)', 1.5);
    this._curve((r) => A.capsulePosteriorY(r) + shift + bulge, -A.LENS_A, A.LENS_A,
      cs.pcr ? 'rgba(255,102,102,0.9)' : 'rgba(230,242,255,0.8)', 2);
    const rem = cs.nucleus.remainingFraction();
    if (rem > 0.01) {
      const a = A.NUC_A * Math.sqrt(rem), b = A.NUC_B * Math.sqrt(rem);
      c.fillStyle = 'rgba(217,166,77,0.45)';
      c.beginPath();
      for (let i = 0; i <= 32; i++) {
        const t = (Math.PI * 2 * i) / 32;
        const [x, y] = this._map(Math.cos(t) * a, A.LENS_CENTER_Y + shift + Math.sin(t) * b);
        if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
      }
      c.fill();
    }
    if (cs.iol_present && cs.iol_progress >= 1) {
      const yy = cs.iol_y + shift;
      this._line(-3, yy, 3, yy, 'rgba(153,255,255,0.9)', 4);
      this._line(-6, yy, -3, yy, 'rgba(153,255,255,0.5)', 1.5);
      this._line(3, yy, 6, yy, 'rgba(153,255,255,0.5)', 1.5);
    }
    const lines = [];
    const rig = this.rig;
    const main = rig.right.tool_type !== '' ? rig.right : rig.left;
    if (main.tool_type !== '') {
      const l = Math.hypot(main.tip.x, main.tip.z);
      if (l > 0.3) {
        const nx = lerp(this._dir.x, main.tip.x / l, 0.2), ny = lerp(this._dir.y, main.tip.z / l, 0.2);
        const nl = Math.hypot(nx, ny) || 1;
        this._dir = { x: nx / nl, y: ny / nl };
      }
    }
    for (const t of [rig.right, rig.left]) {
      if (t.tool_type === '') continue;
      const s = t.tip.x * this._dir.x + t.tip.z * this._dir.y;
      const [px, py] = this._map(s, t.tip.y);
      if (t.port) {
        const piv = t.pivotPoint();
        const [qx, qy] = this._map(piv.x * this._dir.x + piv.z * this._dir.y, piv.y);
        c.strokeStyle = t.marker_color; c.globalAlpha = 0.6; c.lineWidth = 2;
        c.beginPath(); c.moveTo(px, py); c.lineTo(qx, qy); c.stroke();
        c.globalAlpha = 1;
      }
      c.fillStyle = t.marker_color;
      c.beginPath(); c.arc(px, py, 5, 0, Math.PI * 2); c.fill();
      const r = Math.hypot(t.tip.x, t.tip.z);
      const gapEndo = A.corneaInnerY(r) - t.tip.y;
      const gapPost = t.tip.y - (A.capsulePosteriorY(Math.min(r, A.LENS_A - 0.01)) + shift + bulge);
      lines.push(`${t.side === 'right' ? 'K' : 'L'}: endotel ${gapEndo.toFixed(1)} · kaps.post ${gapPost.toFixed(1)} mm`);
    }
    c.font = '15px system-ui, sans-serif';
    c.textAlign = 'left';
    c.fillStyle = 'rgba(255,255,255,0.9)';
    lines.forEach((l, i) => c.fillText(l, 8, 18 + i * 18));
    c.font = '14px system-ui, sans-serif';
    c.textAlign = 'right';
    c.fillStyle = 'rgba(255,255,255,0.5)';
    c.fillText('Potongan melintang', w - 8, h - 8);
  }
}
