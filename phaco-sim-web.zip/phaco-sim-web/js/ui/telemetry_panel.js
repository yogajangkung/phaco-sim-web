// TelemetryPanel — telemetri real-time (pedal, phaco %, vakum, flow, IOP, stabilitas bilik,
// keamanan kapsul, suhu luka) berupa bar & teks, digambar di canvas 2D.
export class TelemetryPanel {
  constructor(parent) {
    this.el = document.createElement('canvas');
    this.el.className = 'telemetry';
    parent.appendChild(this.el);
    this.ctx = this.el.getContext('2d');
    this.bars = [];
    this.extra = '';
    this.w = 280; this.h = 470;
  }

  layout(x, y, w, h) {
    this.w = w; this.h = h;
    this.el.width = w; this.el.height = h;
    Object.assign(this.el.style, { left: `${x}px`, top: `${y}px`, width: `${w}px`, height: `${h}px` });
    this.redraw();
  }

  set(bars, extra) { this.bars = bars; this.extra = extra; this.redraw(); }

  redraw() {
    const c = this.ctx, w = this.w;
    c.clearRect(0, 0, w, this.h);
    c.fillStyle = 'rgba(5,13,18,0.62)';
    c.fillRect(0, 0, w, this.h);
    let y = 8;
    const bw = w - 16;
    for (const [label, value, frac, col] of this.bars) {
      c.font = '16px system-ui, sans-serif';
      c.textAlign = 'left';
      c.fillStyle = 'rgba(255,255,255,0.75)';
      c.fillText(label, 8, y + 16);
      c.font = 'bold 16px system-ui, sans-serif';
      c.textAlign = 'right';
      c.fillStyle = 'rgba(255,255,255,0.95)';
      c.fillText(value, w - 8, y + 16);
      c.fillStyle = 'rgba(255,255,255,0.1)';
      c.fillRect(8, y + 21, bw, 6);
      c.fillStyle = col;
      c.fillRect(8, y + 21, bw * Math.min(1, Math.max(0, frac)), 6);
      y += 34;
    }
    c.font = '15px system-ui, sans-serif';
    c.textAlign = 'left';
    c.fillStyle = 'rgba(190,240,255,0.95)';
    for (const raw of this.extra.split('\n')) {
      if (!raw) continue;
      // bungkus baris panjang
      let line = '';
      for (const word of raw.split(' ')) {
        const test = line ? `${line} ${word}` : word;
        if (c.measureText(test).width > bw && line) {
          c.fillText(line, 8, y + 16);
          y += 19;
          line = word;
        } else {
          line = test;
        }
      }
      c.fillText(line, 8, y + 16);
      y += 19;
    }
  }
}
