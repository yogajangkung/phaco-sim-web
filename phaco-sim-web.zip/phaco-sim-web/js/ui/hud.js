// Hud — seluruh antarmuka 2D: kontrol game (joystick ganda, slider kedalaman, pedal,
// tombol aksi), telemetri, objektif, inset potongan melintang, banner komplikasi,
// menu utama, pemilih langkah (sandbox) dan laporan debriefing.
//
// Tata letak landscape memakai koordinat logis 1920×1080 (tinggi tetap 1080, lebar
// mengikuti rasio layar) lalu di-skala CSS ke ukuran layar sebenarnya.
//   kiri bawah  : joystick KIRI + slider kedalaman kiri
//   kanan bawah : joystick KANAN + slider kedalaman kanan
//   tepi kiri   : PEDAL vertikal (0/1/2/3) + REFLUX + KUNCI pedal
//   kanan atas  : telemetri + tombol aksi kontekstual
//   tengah bawah: potongan melintang
// Keyboard: WASD + R/F (kanan), panah + O/L (kiri), 0–3 pedal, Spasi reflux,
//   Z/X/C/V aksi, Enter lanjut, Tab kamera, G gerak halus.
import { VirtualJoystick, VirtualSlider, TouchButton, escapeHtml } from '../input/controls.js';
import { CrossSectionView } from './cross_section_view.js';
import { TelemetryPanel } from './telemetry_panel.js';
import { FootPedal } from '../sim/foot_pedal.js';
import { V2, clamp, mmss } from '../core/math.js';
import { COLOR_LEFT, COLOR_RIGHT } from '../instruments/instrument_rig.js';
import { setInstrumentCutaway } from '../instruments/instrument.js';

const HOTKEYS = ['KeyZ', 'KeyX', 'KeyC', 'KeyV'];
const HOTKEY_NAMES = ['Z', 'X', 'C', 'V'];
const BASE_H = 1080;
const BASE_W = 1920;

function el(tag, cls, parent, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  if (parent) parent.appendChild(e);
  return e;
}

function setText(e, t) { if (e._t !== t) { e._t = t; e.textContent = t; } }
function setHtml(e, t) { if (e._h !== t) { e._h = t; e.innerHTML = t; } }
function show(e, v) { const d = v ? '' : 'none'; if (e.style.display !== d) e.style.display = d; }

export class Hud {
  constructor(sim, root, canvas) {
    this.sim = sim;
    this.root = root;
    this.canvas = canvas;
    this.scale = 1;
    this.W = BASE_W;
    this.H = BASE_H;
    this._alertTime = 0;
    this._actionsVersion = -1;
    this._current = null;
    this._kbPedal = 0;
    this._keys = new Set();
    this._prev = new Map();
    this._teleTimer = 0;
    this.menuVisible = false;
    this.reportVisible = false;
    this._build();
    this._bindKeyboard();
    this._bindOrbitDrag();
    window.addEventListener('resize', () => this.layout());
    window.addEventListener('orientationchange', () => setTimeout(() => this.layout(), 200));
    this.layout();
  }

  // ---------------------------------------------------------------- konstruksi
  _build() {
    const r = this.root;
    this.vignette = document.getElementById('vignette');

    this.title = el('div', 'hud-title', r);
    this.hint = el('div', 'hud-hint', r);
    this.timer = el('div', 'hud-timer', r);
    this.nextBtn = this._btn('LANJUT ›', () => this._onNext(), 'btn-next');
    this.menuBtn = this._btn('Menu', () => this._onMenu());
    this.viewBtn = this._btn('Kamera', () => this._onView());
    this.zoomBtn = this._btn('Zoom 1.0x', () => this._onZoom());
    this.skipBtn = this._btn('Lewati', () => this._onSkip());

    this.settings = el('div', 'hud-settings', r);
    this.settingLabels = {};
    for (const key of ['bottle', 'vac', 'flow', 'power']) {
      const g = el('div', 'setting', this.settings);
      const minus = el('button', 'btn small', g, '−');
      const lbl = el('span', 'setting-label', g);
      const plus = el('button', 'btn small', g, '+');
      minus.addEventListener('click', () => this._onSetting(key, -1));
      plus.addEventListener('click', () => this._onSetting(key, 1));
      this.settingLabels[key] = lbl;
    }

    this.objectives = el('div', 'hud-objectives', r);
    this.telemetry = new TelemetryPanel(r);
    this.cross = new CrossSectionView(r, this.sim.caseState, this.sim.rig);

    this.alertEl = el('div', 'hud-alert', r);
    show(this.alertEl, false);

    // --- kontrol ---
    this.joyL = new VirtualJoystick(r, COLOR_LEFT);
    this.joyR = new VirtualJoystick(r, COLOR_RIGHT);
    this.depthL = new VirtualSlider(r, 'spring', COLOR_LEFT);
    this.depthL.label = 'KEDALAMAN';
    this.depthR = new VirtualSlider(r, 'spring', COLOR_RIGHT);
    this.depthR.label = 'KEDALAMAN';
    this.pedalSlider = new VirtualSlider(r, 'pedal', '#ffbf4d');
    this.pedalSlider.label = 'PEDAL';
    this.pedalSlider.latched = true;
    this.refluxBtn = new TouchButton(r, { id: 'reflux', label: 'REFLUX', accent: '#66ccff', hotkey: 'Spasi' });
    this.latchBtn = new TouchButton(r, { id: 'latch', label: 'KUNCI\nPEDAL', accent: '#ffbf4d', toggle: true });
    this.latchBtn.setHeld(true);
    this.fineBtn = new TouchButton(r, { id: 'fine', label: 'HALUS', accent: '#80ff99', toggle: true, hotkey: 'G' });
    this.fineBtn.setHeld(true);
    this.actionBtns = HOTKEY_NAMES.map((k) => {
      const b = new TouchButton(r, { hotkey: k });
      b.visible = false;
      return b;
    });
    this.gameEls = [this.joyL, this.joyR, this.depthL, this.depthR, this.pedalSlider, this.refluxBtn,
      this.latchBtn, this.fineBtn];

    this._buildMenu();
    this._buildReport();
    this._buildRotateHint();
  }

  _btn(text, cb, cls = '') {
    const b = el('button', `btn hud-btn ${cls}`, this.root, text);
    b.tabIndex = -1;
    b.addEventListener('click', (e) => { cb(); e.currentTarget.blur(); });
    return b;
  }

  _buildMenu() {
    const p = el('div', 'panel menu', this.root);
    this.menuPanel = p;
    const v = el('div', 'panel-scroll', p);
    el('h1', '', v, 'PHACO SIM 3D');
    el('p', 'sub', v, 'Simulator Fakoemulsifikasi Katarak — full step 11 langkah. <b>Edukasi saja, bukan alat medis.</b>');

    el('h3', '', v, 'Kekerasan nukleus (grade)');
    const gh = el('div', 'row', v);
    this.gradeBtns = ['1 Lunak', '2 Sedang', '3 Keras', '4 Brunescent'].map((name, i) => {
      const b = el('button', 'btn toggle', gh, name);
      b.addEventListener('click', () => { this.sim.caseState.nucleus_grade = i + 1; this._refreshMenuToggles(); });
      return b;
    });
    el('h3', '', v, 'Teknik nukleus');
    const th = el('div', 'row', v);
    this.techBtns = [['dc', 'Divide & Conquer'], ['chop', 'Phaco Chop']].map(([id, name]) => {
      const b = el('button', 'btn toggle', th, name);
      b.addEventListener('click', () => { this.sim.caseState.technique = id; this._refreshMenuToggles(); });
      return [id, b];
    });
    const oh = el('div', 'row opts', v);
    this.hapticChk = this._check(oh, 'Getar (haptic)', true, (on) => { this.sim.haptics.enabled = on; });
    this.audioChk = this._check(oh, 'Audio mesin', true, (on) => { this.sim.audio.gain = on ? 0.7 : 0; });
    const fs = el('button', 'btn', oh, 'Layar penuh');
    fs.addEventListener('click', () => this.sim.requestFullscreen());

    const start = el('button', 'btn primary big', v, 'MULAI MODE TERPANDU (11 langkah)');
    start.addEventListener('click', () => this._onStartGuided());
    el('p', 'sub', v, 'Sandbox / latihan per langkah (langkah sebelumnya di-fast-forward dengan hasil ideal):');
    this.stepsGrid = el('div', 'steps-grid', v);
    el('p', 'help', v,
      'Kontrol: joystick kanan/kiri = instrumen, slider = kedalaman, pedal di tepi kiri.<br>'
      + 'Keyboard: <kbd>W A S D</kbd> + <kbd>R</kbd>/<kbd>F</kbd> (kanan), panah + <kbd>O</kbd>/<kbd>L</kbd> (kiri), '
      + '<kbd>0</kbd>–<kbd>3</kbd> pedal, <kbd>Spasi</kbd> reflux, <kbd>Z X C V</kbd> aksi, <kbd>Enter</kbd> lanjut, '
      + '<kbd>Tab</kbd> kamera, <kbd>G</kbd> gerak halus. Drag area kosong = orbit (mode Orbit).');
  }

  _check(parent, label, on, cb) {
    const l = el('label', 'check', parent);
    const i = el('input', '', l);
    i.type = 'checkbox';
    i.checked = on;
    i.addEventListener('change', () => cb(i.checked));
    el('span', '', l, label);
    return i;
  }

  _buildReport() {
    const p = el('div', 'panel report', this.root);
    this.reportPanel = p;
    this.reportText = el('div', 'panel-scroll report-text', p);
    const h = el('div', 'row report-actions', p);
    el('button', 'btn primary', h, 'Ulangi Kasus').addEventListener('click', () => this._onStartGuided());
    el('button', 'btn', h, 'Menu Utama').addEventListener('click', () => this._onMenu());
    el('button', 'btn', h, 'Unduh laporan (JSON)').addEventListener('click', () => this._downloadReport());
    show(p, false);
  }

  _buildRotateHint() {
    this.rotateHint = el('div', 'rotate-hint', document.body,
      '<div class="rot-icon">⟳</div><div>Putar HP ke posisi <b>landscape</b><br>untuk bermain.</div>');
  }

  // ---------------------------------------------------------------- layout
  layout() {
    const vw = window.innerWidth, vh = window.innerHeight;
    const s = Math.min(vw / BASE_W, vh / BASE_H);
    this.scale = s;
    const W = vw / s, H = vh / s;
    this.W = W; this.H = H;
    Object.assign(this.root.style, { width: `${W}px`, height: `${H}px`, transform: `scale(${s})` });
    this.rotateHint.classList.toggle('on', vh > vw * 1.05 && 'ontouchstart' in window);

    const place = (e, x, y, w, h) => {
      Object.assign(e.style, { left: `${x}px`, top: `${y}px` });
      if (w !== undefined) e.style.width = `${w}px`;
      if (h !== undefined) e.style.height = `${h}px`;
    };
    place(this.title, 150, 8, W - 1060);
    place(this.hint, 150, 50, W - 1060);
    place(this.timer, W - 885, 20, 90);
    place(this.nextBtn, W - 230, 10, 214, 64);
    place(this.menuBtn, W - 350, 10, 110, 52);
    place(this.viewBtn, W - 520, 10, 160, 52);
    place(this.zoomBtn, W - 670, 10, 140, 52);
    place(this.skipBtn, W - 780, 10, 100, 52);
    place(this.settings, W * 0.5 - 430, 118);
    place(this.objectives, 150, 200, 340);
    this.telemetry.layout(W - 490, 180, 280, 470);
    this.cross.layout(W * 0.5 - 230, H - 205, 460, 195);
    place(this.alertEl, W * 0.5 - 380, 175, 760);

    this.pedalSlider.layout(18, 110, 112, H - 612);
    this.refluxBtn.layout(18, H - 492, 112, 64);
    this.latchBtn.layout(18, H - 418, 112, 56);
    const js = 300;
    this.joyL.layout(30, H - js - 24, js, js);
    this.depthL.layout(30 + js + 18, H - 380, 76, 340);
    this.joyR.layout(W - js - 30, H - js - 24, js, js);
    this.depthR.layout(W - js - 30 - 94, H - 380, 76, 340);
    this.fineBtn.layout(W - js - 30 - 94 - 96, H - 100, 84, 60);
    this.actionBtns.forEach((b, i) => b.layout(W - 196, 180 + i * 112, 180, 100));

    const pw = Math.min(1100, W - 80);
    place(this.menuPanel, W * 0.5 - pw / 2, 40, pw, H - 80);
    place(this.reportPanel, W * 0.5 - pw / 2, 40, pw, H - 80);

    // masker lapang pandang mikroskop (radius 0.49 × tinggi layar)
    const R = 0.49 * vh;
    this.vignette.style.background =
      `radial-gradient(circle at 50% 50%, rgba(0,0,0,0) ${R - 0.025 * vh}px, #000 ${R}px)`;
    this.sim.onResize(vw, vh);
  }

  // ---------------------------------------------------------------- input
  _bindKeyboard() {
    const block = new Set(['Space', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Enter']);
    window.addEventListener('keydown', (e) => {
      if (e.target instanceof HTMLInputElement) return;
      if (block.has(e.code) && !this.menuVisible && !this.reportVisible) e.preventDefault();
      this._keys.add(e.code);
    });
    window.addEventListener('keyup', (e) => this._keys.delete(e.code));
    window.addEventListener('blur', () => this._keys.clear());
  }

  _bindOrbitDrag() {
    let pid = null, lx = 0, ly = 0;
    this.canvas.addEventListener('pointerdown', (e) => {
      if (pid !== null) return;
      pid = e.pointerId; lx = e.clientX; ly = e.clientY;
      try { this.canvas.setPointerCapture(pid); } catch { /* abaikan */ }
    });
    this.canvas.addEventListener('pointermove', (e) => {
      if (e.pointerId !== pid) return;
      this.sim.cam.orbitDrag((e.clientX - lx) / this.scale, (e.clientY - ly) / this.scale);
      lx = e.clientX; ly = e.clientY;
    });
    const end = (e) => { if (e.pointerId === pid) pid = null; };
    this.canvas.addEventListener('pointerup', end);
    this.canvas.addEventListener('pointercancel', end);
  }

  _key(code) { return this._keys.has(code); }
  _axis(neg, pos) { return (this._key(pos) ? 1 : 0) - (this._key(neg) ? 1 : 0); }
  _edge(code) {
    const now = this._key(code);
    const was = this._prev.get(code) ?? false;
    this._prev.set(code, now);
    return now && !was;
  }

  collectInput() {
    const rs = new V2(this.joyR.value.x + this._axis('KeyA', 'KeyD'), this.joyR.value.y + this._axis('KeyW', 'KeyS'));
    const ls = new V2(this.joyL.value.x + this._axis('ArrowLeft', 'ArrowRight'), this.joyL.value.y + this._axis('ArrowUp', 'ArrowDown'));
    const rd = this.depthR.value + this._axis('KeyF', 'KeyR');
    const ld = this.depthL.value + this._axis('KeyL', 'KeyO');
    if (this._edge('Digit0') || this._edge('Numpad0')) this._kbPedal = 0;
    if (this._edge('Digit1') || this._edge('Numpad1')) this._kbPedal = 0.22;
    if (this._edge('Digit2') || this._edge('Numpad2')) this._kbPedal = 0.52;
    if (this._edge('Digit3') || this._edge('Numpad3')) this._kbPedal = 0.9;
    if (this._edge('KeyG')) this.fineBtn.setHeld(!this.fineBtn.held);
    this.pedalSlider.latched = this.latchBtn.held;
    if (this.pedalSlider.active || this.pedalSlider.value > 0) this._kbPedal = 0;
    const held = {}, pressed = {};
    this.actionBtns.forEach((b, i) => {
      if (!b.visible) return;
      held[b.id] = b.held || this._key(HOTKEYS[i]);
      pressed[b.id] = b.consumePress() || this._edge(HOTKEYS[i]);
    });
    if (this._edge('Enter') || this._edge('NumpadEnter')) this._onNext();
    if (this._edge('Tab')) this._onView();
    return {
      rs: rs.limitLength(1), ls: ls.limitLength(1),
      rd: clamp(rd, -1, 1), ld: clamp(ld, -1, 1),
      pedal: Math.max(this.pedalSlider.value, this._kbPedal),
      reflux: this.refluxBtn.held || this._key('Space'),
      fine: this.fineBtn.held,
      held, pressed,
    };
  }

  // ---------------------------------------------------------------- update
  onStepChanged(step) {
    this._current = step;
    this._actionsVersion = -1;
    this.pedalSlider.value = 0;
    this.pedalSlider.redraw();
    this._kbPedal = 0;
    setText(this.title, step.title);
    this._setReport(false);
    this._setMenu(false);
  }

  _refreshActions(step) {
    this.actionBtns.forEach((b, i) => {
      const a = step.actions[i];
      if (a) {
        b.id = a.id;
        b.label = a.label;
        b.visible = true;
      } else {
        b.visible = false;
      }
      b.setHeld(false);
    });
    this._actionsVersion = step.actions_version;
  }

  refresh(dt) {
    const sim = this.sim, fsm = sim.fsm, cam = sim.cam;
    const inGame = fsm.running && !this.menuVisible && !this.reportVisible;
    for (const w of this.gameEls) w.visible = inGame;
    for (const e of [this.title, this.hint, this.timer, this.nextBtn, this.viewBtn, this.zoomBtn, this.skipBtn,
      this.objectives, this.telemetry.el, this.cross.el]) show(e, inGame);
    show(this.settings, false);
    show(this.menuBtn, !this.menuVisible);
    show(this.vignette, cam.mode === 'scope' || cam.mode === 'oblique');
    const blur = clamp(Math.abs(sim.caseState.scope_focus) / 6, 0, 1);
    const f = blur > 0.01 ? `blur(${(blur * 9 * this.scale * 2).toFixed(2)}px)` : 'none';
    if (this.canvas.style.filter !== f) this.canvas.style.filter = f;

    if (this._alertTime > 0) {
      this._alertTime -= dt;
      show(this.alertEl, true);
      this.alertEl.style.opacity = clamp(this._alertTime, 0, 1);
    } else {
      show(this.alertEl, false);
    }

    if (!inGame || !this._current) {
      for (const b of this.actionBtns) b.visible = false;
      return;
    }
    const step = this._current;
    if (step.actions_version !== this._actionsVersion) this._refreshActions(step);
    const hasLeft = step.left_label !== '';
    this.joyL.visible = hasLeft;
    this.depthL.visible = hasLeft;
    this.joyL.label = step.left_label;
    this.joyR.label = step.right_label;
    const pedalOn = step.uses_pedal;
    this.pedalSlider.visible = pedalOn;
    this.refluxBtn.visible = pedalOn && step.pedal_label === 'PEDAL';
    this.latchBtn.visible = pedalOn;
    this.pedalSlider.label = step.pedal_label;
    this.pedalSlider.setDisplay(sim.pedal.travel);
    show(this.skipBtn, fsm.mode !== 'guided');
    show(this.settings, step.show_pedal_settings);
    if (step.show_pedal_settings) {
      const fl = sim.fluidics;
      setText(this.settingLabels.bottle, `Botol ${Math.round(fl.bottle_cm)} cm`);
      setText(this.settingLabels.vac, `Vak ${Math.round(fl.vac_limit)}`);
      setText(this.settingLabels.flow, `Flow ${Math.round(fl.flow_setting)}`);
      setText(this.settingLabels.power, `Power ${Math.round(fl.power_max)}%`);
    }

    const can = fsm.canAdvance();
    this.nextBtn.disabled = !can;
    this.nextBtn.classList.toggle('ready', can);
    setText(this.nextBtn, fsm.index === fsm.steps.length - 1 ? 'SELESAI ›' : 'LANJUT ›');
    setText(this.hint, step.hint);
    setText(this.timer, mmss(step.elapsed));
    setText(this.viewBtn, cam.modeName());
    setText(this.zoomBtn, `Zoom ${cam.zoom.toFixed(1)}x`);

    let html = `<b>Langkah ${step.index + 1}/${fsm.steps.length}</b>`;
    for (const o of step.objectives) {
      html += `<div class="obj ${o.done ? 'done' : ''}"><span class="mark">${o.done ? '✔' : '○'}</span>`
        + `<span>${escapeHtml(o.text)}${o.detail ? ` <i>(${escapeHtml(o.detail)})</i>` : ''}</span></div>`;
    }
    setHtml(this.objectives, html);

    this._teleTimer -= dt;
    if (this._teleTimer <= 0) {
      this._teleTimer = 0.066;
      this._updateTelemetry(step);
      this.cross.redraw();
    }
  }

  _updateTelemetry(step) {
    const f = this.sim.fluidics, c = this.sim.caseState, p = this.sim.pedal, rig = this.sim.rig;
    const bars = [];
    if (step.uses_pedal && step.pedal_label === 'PEDAL') {
      bars.push(['Pedal', FootPedal.positionName(p.position), p.travel, ['#999', '#4db3ff', '#4dff80', '#ff8c33'][p.position]]);
      bars.push(['Phaco', `${Math.round(f.power)} %`, f.power / 100, '#ff8c33']);
      bars.push(['Vakum', `${Math.round(f.vacuum)} / ${Math.round(f.vac_limit)} mmHg`, f.vacuum / Math.max(f.vac_limit, 1), f.occluded ? '#ff5959' : '#66ccff']);
      bars.push(['Flow', `${Math.round(Math.max(f.flow, 0))} cc/mnt`, f.flow / 50, '#66ccff']);
      bars.push(['Suhu luka', `${Math.round(c.wound_temp * 100)} %`, c.wound_temp, '#ff4d33']);
    } else if (step.uses_pedal) {
      bars.push(['Plunger', `${Math.round(p.travel * 100)} %`, p.travel, '#ffbf4d']);
    }
    bars.push(['IOP', `${Math.round(c.iop)} mmHg`, c.iop / 60, '#80e6ff']);
    bars.push(['Stabilitas bilik', `${Math.round(f.chamberStability() * 100)} %`, f.chamberStability(), '#66ff99']);
    let gap = 99;
    for (const t of [rig.right, rig.left]) if (t.tool_type !== '' && t.in_bag) gap = Math.min(gap, t.posterior_gap);
    const safe = clamp(gap / 1.5, 0, 1);
    const safeCol = safe > 0.5 ? '#66ff80' : safe > 0.2 ? '#ffcc33' : '#ff4040';
    bars.push(['Keamanan kapsul', c.pcr ? 'PCR!' : gap < 90 ? `${gap.toFixed(1)} mm` : 'aman', c.pcr ? 0 : safe, safeCol]);
    bars.push(['Sel endotel hilang', `${c.endothelial_loss.toFixed(1)} %`, c.endothelial_loss / 20, '#ff9950']);
    let tool = '';
    if (rig.right.tool_type) tool = `Kanan: ${rig.right.displayName()}`;
    if (rig.left.tool_type) tool += `\nKiri: ${rig.left.displayName()}`;
    this.telemetry.set(bars, `${tool}\n${step.telemetryExtra()}`);
  }

  alert(ev) {
    const sev = clamp(ev.severity, 1, 3);
    this.alertEl.className = `hud-alert sev${sev}`;
    this.alertEl.innerHTML = `<b>⚠ ${escapeHtml(ev.title)}${ev.detail ? ` (${escapeHtml(ev.detail)})` : ''}</b>`
      + `<div>${escapeHtml(ev.advice)}</div>`;
    this._alertTime = 2.5 + sev;
  }

  // ---------------------------------------------------------------- menu & laporan
  _setMenu(v) { this.menuVisible = v; show(this.menuPanel, v); }
  _setReport(v) { this.reportVisible = v; show(this.reportPanel, v); }

  showMenu() {
    this.stepsGrid.innerHTML = '';
    this.sim.fsm.stepTitles().forEach((t, i) => {
      const b = el('button', 'btn step', this.stepsGrid, escapeHtml(t));
      b.addEventListener('click', () => this._onStartSandbox(i));
    });
    this._refreshMenuToggles();
    this._setMenu(true);
    this._setReport(false);
  }

  _refreshMenuToggles() {
    const cs = this.sim.caseState;
    this.gradeBtns.forEach((b, i) => b.classList.toggle('on', i + 1 === cs.nucleus_grade));
    for (const [id, b] of this.techBtns) b.classList.toggle('on', id === cs.technique);
  }

  showReport(r) {
    this._lastReport = r;
    this._setMenu(false);
    this._setReport(true);
    const pct = (v) => Math.round(v);
    let t = '<h2>DEBRIEFING — Laporan Kinerja</h2>';
    t += `<div class="score"><span class="grade g${r.grade}">${r.grade}</span><span><b>Skor total: ${pct(r.overall)} / 100</b><br>`
      + `Kualitas rata-rata ${pct(r.quality)} · Efisiensi waktu ${pct(r.efficiency)} · Penalti komplikasi −${pct(r.penalty)}</span></div>`;
    t += `<p>Total waktu ${mmss(r.total_time)} · CDE ${r.cde.toFixed(2)} · Estimasi kehilangan sel endotel ${r.endo_loss.toFixed(1)}% · `
      + `Nukleus grade ${r.grade_nucleus} · ${r.technique === 'chop' ? 'Phaco Chop' : 'Divide & Conquer'}</p>`;
    if (r.pcr) {
      t += '<p class="bad"><b>Terjadi ruptur kapsul posterior (PCR).</b> Di kasus nyata: hentikan phaco, vitrektomi anterior, pertimbangkan IOL sulkus.</p>';
    }
    t += '<h3>Per langkah</h3><ul>';
    for (const rec of r.records) {
      t += rec.skipped
        ? `<li>${escapeHtml(rec.title)}: <span class="muted">(fast-forward / tidak dinilai)</span></li>`
        : `<li>${escapeHtml(rec.title)}: kualitas <b>${pct(rec.quality)}</b> · waktu ${pct(rec.time)} s (target ${pct(rec.target)} s) · ${rec.events} kejadian</li>`;
    }
    t += `</ul><h3>Komplikasi & kejadian (${r.complications.length})</h3><ul>`;
    for (const e of r.complications) {
      t += `<li>[${escapeHtml(e.step.split('.')[0])}] ${escapeHtml(e.title)} ${e.detail ? `(${escapeHtml(e.detail)})` : ''}</li>`;
    }
    t += '</ul><h3>Saran perbaikan</h3><ul>';
    if (r.tips.length === 0) t += '<li>Kerja yang sangat baik! Coba grade nukleus lebih keras atau teknik lain.</li>';
    for (const tip of r.tips) t += `<li>${escapeHtml(tip)}</li>`;
    t += '</ul>';
    this.reportText.innerHTML = t;
    this.reportText.scrollTop = 0;
  }

  _downloadReport() {
    if (!this._lastReport) return;
    const blob = new Blob([JSON.stringify({ app: 'Phaco Sim 3D', date: new Date().toISOString(), ...this._lastReport }, null, 2)],
      { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `phaco-sim-laporan-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  _onStartGuided() {
    this.sim.audio.start();
    this._setMenu(false);
    this._setReport(false);
    this.sim.startProcedure('guided', 0);
  }

  _onStartSandbox(i) {
    this.sim.audio.start();
    this._setMenu(false);
    this.sim.startProcedure('sandbox', i);
  }

  _onNext() { if (this.sim.fsm.running) this.sim.fsm.tryAdvance(); }

  _onSkip() { if (this.sim.fsm.running && this.sim.fsm.mode !== 'guided') this.sim.fsm.skipCurrent(); }

  _onView() {
    this.sim.cam.cycleMode();
    const cut = this.sim.cam.usesCutaway();
    this.sim.eye.setCutaway(cut);
    setInstrumentCutaway(cut);
  }

  _onZoom() {
    const z = this.sim.cam.zoom;
    this.sim.cam.zoom = z >= 2 ? 1 : z + 0.5;
  }

  _onMenu() {
    this.sim.fsm.stop();
    this.sim.rig.removeAll();
    this.showMenu();
  }

  _onSetting(key, dir) {
    const f = this.sim.fluidics;
    if (key === 'bottle') f.bottle_cm = clamp(f.bottle_cm + dir * 5, 30, 120);
    if (key === 'vac') f.vac_limit = clamp(f.vac_limit + dir * 25, 25, 650);
    if (key === 'flow') f.flow_setting = clamp(f.flow_setting + dir * 2, 10, 50);
    if (key === 'power') f.power_max = clamp(f.power_max + dir * 5, 0, 100);
    f.preset_name = 'Custom';
  }
}
