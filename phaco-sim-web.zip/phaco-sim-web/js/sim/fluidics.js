// Fluidics — model fluidik bilik mata depan + pompa peristaltik + ultrasound.
//
// Model lumped-parameter:
//   P_irr   = tinggi botol (cm) × 0.7356            [mmHg]
//   Q_in    = K_IN × (P_irr − IOP)                  (pedal ≥ 1)
//   Q_asp   = flow_setting × level_pedal            (pompa peristaltik; 0 saat oklusi)
//   Vakum   : oklusi → naik ke vac_limit dgn laju ∝ flow; bebas → ≈ 0.9 × flow
//   Surge   : saat oklusi pecah dgn vakum > 60 → Q_surge = vakum × K_SURGE × (60/botol)
//   dIOP/dt = (Q_in − Q_asp − Q_leak − Q_surge) / COMPLIANCE
//   Termal  : T' = (power/100)(1 − pendinginan)·0.55 − pendinginan; T > 1 → wound burn
import { clamp, lerp, moveToward, expK } from '../core/math.js';

const K_IN = 1.4;
const K_LEAK = 0.10;
const K_SURGE = 0.22;
const COMPLIANCE = 0.9;
const BASE_IOP = 15.0;

export const PRESETS = {
  'Sculpt': { vac: 80, flow: 24, power: 60 },
  'Quadrant': { vac: 350, flow: 30, power: 40 },
  'Chop': { vac: 420, flow: 34, power: 40 },
  'Epi': { vac: 250, flow: 28, power: 20 },
  'I/A': { vac: 500, flow: 30, power: 0 },
  'OVD Removal': { vac: 600, flow: 40, power: 0 },
};

export class Fluidics {
  constructor() { this.reset(); this.active = false; }

  reset() {
    this.bottle_cm = 80;
    this.applyPreset('Quadrant');
    this.preset_name = '—';
    this.iop = BASE_IOP;
    this.vacuum = 0;
    this.flow = 0;
    this.inflow = 0;
    this.power = 0;
    this.occluded = false;
    this.occlusion_time = 0;
    this.surge = 0;
    this.surge_event = 0;
    this.chamber_depth = 1;
    this.temp = 0;
  }

  applyPreset(name) {
    this.preset_name = name;
    const p = PRESETS[name];
    if (!p) return;
    this.vac_limit = p.vac;
    this.flow_setting = p.flow;
    this.power_max = p.power;
  }

  irrigationPressure() { return this.bottle_cm * 0.7356; }

  /** Dipanggil tiap frame oleh langkah yang memakai pedal. */
  update(dt, pedal, cs, occlusionRequest) {
    this.surge_event = 0;
    const leak = cs.woundLeak();
    const asp = pedal.aspirationLevel();

    this.inflow = pedal.irrigating() ? Math.max(0, K_IN * (this.irrigationPressure() - this.iop)) : 0;

    const wantOcc = occlusionRequest && pedal.aspirating();
    if (wantOcc) {
      this.occlusion_time += dt;
      this.flow = lerp(this.flow, 0, expK(12, dt));
      const rise = this.flow_setting * asp * 9;
      this.vacuum = moveToward(this.vacuum, this.vac_limit * Math.max(asp, 0.35), rise * dt);
    } else {
      if (this.occluded && this.vacuum > 60) {
        this.surge_event = this.vacuum;
        this.surge = this.vacuum * K_SURGE * (60 / Math.max(this.bottle_cm, 30));
      }
      this.occlusion_time = 0;
      this.flow = this.flow_setting * asp;
      const freeVac = this.flow * 0.9;
      this.vacuum = lerp(this.vacuum, freeVac, expK(10, dt));
    }
    this.occluded = wantOcc;
    this.surge = lerp(this.surge, 0, expK(4, dt));

    if (pedal.refluxActive()) {
      this.vacuum = lerp(this.vacuum, 0, expK(18, dt));
      this.flow = -6;
    }

    this.power = this.power_max * pedal.phacoLevel();
    if (this.power > 0) cs.phaco_cde += this.power * dt / 100;

    const outflow = Math.max(this.flow, 0) + this.surge + K_LEAK * this.iop * leak;
    const ovdSupport = clamp(cs.ovd_ac, 0, 1.2);
    let dIop = (this.inflow - outflow) / COMPLIANCE;
    if (!pedal.irrigating()) {
      const restIop = lerp(6, BASE_IOP, clamp(ovdSupport + cs.aqueous * 0.5, 0, 1)) - leak * 3;
      dIop += (restIop - this.iop) * 1.5;
    }
    this.iop = clamp(this.iop + dIop * dt, 0, 90);

    let targetDepth = clamp(0.4 + this.iop / 60, 0.2, 1.35);
    targetDepth = Math.max(targetDepth, 0.3 + 0.6 * ovdSupport);
    this.chamber_depth = lerp(this.chamber_depth, targetDepth, expK(8, dt));

    const cooling = clamp((this.flow + this.inflow * 0.3) / 18, 0, 1);
    this.temp += (this.power / 100) * (1 - cooling) * 0.55 * dt;
    this.temp -= 0.12 * dt * (0.4 + cooling);
    this.temp = clamp(this.temp, 0, 1.5);

    cs.iop = this.iop;
    cs.chamber_depth = this.chamber_depth;
    cs.wound_temp = this.temp;
  }

  /** Mode pasif (langkah tanpa pedal). */
  updatePassive(dt, cs, extraInflow = 0) {
    this.active = false;
    this.power = 0;
    this.flow = 0;
    this.inflow = extraInflow;
    this.vacuum = lerp(this.vacuum, 0, expK(6, dt));
    this.occluded = false;
    this.surge = 0;
    this.surge_event = 0;
    const leak = cs.woundLeak();
    cs.aqueous = clamp(cs.aqueous - leak * 0.08 * dt + extraInflow * 0.01 * dt, 0.2, 1);
    let targetIop = 5 + 10 * cs.aqueous + 8 * Math.min(cs.ovd_ac, 1) + extraInflow * 0.5;
    if (cs.ovd_ac > 1.05) targetIop += (cs.ovd_ac - 1.05) * 90;
    this.iop = lerp(this.iop, targetIop, expK(2.5, dt));
    const targetDepth = clamp(0.3 + this.iop / 22, 0.25, 1.3);
    this.chamber_depth = lerp(this.chamber_depth, targetDepth, expK(5, dt));
    this.temp = Math.max(0, this.temp - 0.2 * dt);
    cs.iop = this.iop;
    cs.chamber_depth = this.chamber_depth;
    cs.wound_temp = this.temp;
  }

  chamberStability() { return clamp(1 - Math.abs(this.chamber_depth - 1) * 1.6, 0, 1); }
}
