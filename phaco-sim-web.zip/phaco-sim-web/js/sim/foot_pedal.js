// FootPedal — model pedal kaki mesin phaco (linear, 4 posisi + reflux).
//
// travel (0..1) = posisi fisik pedal, dipetakan ke zona:
//   Posisi 0 : 0.00 – 0.10  -> Rest
//   Posisi 1 : 0.10 – 0.35  -> Irigasi saja
//   Posisi 2 : 0.35 – 0.65  -> Irigasi + Aspirasi (linear)
//   Posisi 3 : 0.65 – 1.00  -> Irigasi + Aspirasi + Ultrasound (power linear)
// Reflux: tombol terpisah, hanya aktif di posisi 0.
import { clamp, lerp, expK } from '../core/math.js';

export const Z1 = 0.10, Z2 = 0.35, Z3 = 0.65;

export class FootPedal {
  constructor() {
    this.target = 0;
    this.travel = 0;
    this.reflux = false;
    this.position = 0;
    this._lastPosition = 0;
    this.detentCrossed = false;
  }

  setTarget(v) { this.target = clamp(v, 0, 1); }

  update(dt) {
    // pedal fisik: cepat turun, sedikit lebih lambat naik (pegas)
    const rate = this.target > this.travel ? 14 : 10;
    this.travel = lerp(this.travel, this.target, expK(rate, dt));
    if (Math.abs(this.travel - this.target) < 0.002) this.travel = this.target;
    if (this.travel < Z1) this.position = 0;
    else if (this.travel < Z2) this.position = 1;
    else if (this.travel < Z3) this.position = 2;
    else this.position = 3;
    this.detentCrossed = this.position !== this._lastPosition;
    this._lastPosition = this.position;
  }

  irrigating() { return this.position >= 1; }
  aspirating() { return this.position >= 2; }

  /** 0..1 di dalam zona aspirasi. */
  aspirationLevel() {
    if (this.position < 2) return 0;
    return clamp((this.travel - Z2) / (Z3 - Z2), 0.2, 1);
  }

  /** 0..1 power ultrasound linear di zona 3. */
  phacoLevel() {
    if (this.position < 3) return 0;
    return clamp((this.travel - Z3) / (1 - Z3), 0.05, 1);
  }

  refluxActive() { return this.reflux && this.position === 0; }

  static positionName(p) {
    return ['0 · REST', '1 · IRIGASI', '2 · I + ASPIRASI', '3 · I/A + PHACO'][p] ?? '?';
  }
}
