// NucleusModel — nukleus lensa sebagai height-field 2.5D.
//
// Grid N×N (tampak atas, frame lokal nukleus). Tiap sel menyimpan batas atas (top) &
// bawah (bot) material relatif terhadap pusat lensa. Mendukung:
//   * Sculpt/trench  -> menurunkan `top` di sekitar phaco tip
//   * Crack/chop     -> half-line retakan membagi sel menjadi segmen
//   * Emulsifikasi   -> menghapus sel dari segmen yang dipegang vakum
//   * Rotasi         -> rotasi frame lokal terhadap sumbu Y
import * as A from '../core/anatomy.js';
import { V2, V3, clamp, lerp, fposmod, deg2rad, rad2deg, rotY } from '../core/math.js';

export const N = 32;
const EMPTY_EPS = 0.05;

export class NucleusModel {
  constructor() {
    const n2 = N * N;
    this.top = new Float32Array(n2);
    this.bot = new Float32Array(n2);
    this.orig = new Float32Array(n2);
    this.seg = new Int32Array(n2);
    this.cracks = [];
    this.rotation_deg = 0;
    this.seg_offset = new Map();
    this.seg_count = 1;
    this.hardness = 2;
    this.total_initial = 0;
    this.version = 0;
    this.y_shift = 0;
    this.cell = 0;
    this._aliveCache = [];
    this._aliveVer = -1;
    this._massCache = 0;
    this._massVer = -1;
  }

  setup(grade) {
    this.hardness = clamp(Math.round(grade), 1, 4);
    this.cell = (2 * A.NUC_A) / N;
    this.total_initial = 0;
    for (let j = 0; j < N; j++) {
      for (let i = 0; i < N; i++) {
        const c = this.cellCenter(i, j);
        const h = A.ellipsoidHalf(c.length(), A.NUC_A, A.NUC_B);
        const k = this.idx(i, j);
        this.top[k] = h;
        this.bot[k] = -h;
        this.orig[k] = 2 * h;
        this.seg[k] = h > EMPTY_EPS ? 0 : -1;
        if (this.seg[k] >= 0) this.total_initial += 2 * h;
      }
    }
    this.cracks = [];
    this.seg_offset.clear();
    this.seg_count = 1;
    this.rotation_deg = 0;
    this.version++;
  }

  idx(i, j) { return j * N + i; }
  cellCenter(i, j) { return new V2(-A.NUC_A + (i + 0.5) * this.cell, -A.NUC_A + (j + 0.5) * this.cell); }
  centerWorld() { return new V3(0, A.LENS_CENTER_Y + this.y_shift, 0); }
  rotRad() { return deg2rad(this.rotation_deg); }
  offsetOf(s) { return this.seg_offset.get(s) ?? new V3(); }

  /** Titik dunia -> frame lokal segmen s. */
  worldToLocal(p, s) {
    return rotY(p.sub(this.centerWorld()), -this.rotRad()).sub(this.offsetOf(s));
  }

  alive(k) { return this.seg[k] >= 0; }
  thickness(k) { return this.seg[k] >= 0 ? Math.max(0, this.top[k] - this.bot[k]) : 0; }

  totalMass() {
    if (this._massVer === this.version) return this._massCache;
    let m = 0;
    for (let k = 0; k < this.seg.length; k++) if (this.seg[k] >= 0) m += this.top[k] - this.bot[k];
    this._massCache = m;
    this._massVer = this.version;
    return m;
  }

  remainingFraction() { return this.totalMass() / Math.max(this.total_initial, 0.001); }

  segmentMass(s) {
    let m = 0;
    for (let k = 0; k < this.seg.length; k++) if (this.seg[k] === s) m += this.top[k] - this.bot[k];
    return m;
  }

  aliveSegments() {
    if (this._aliveVer === this.version) return this._aliveCache;
    const set = new Set();
    for (let k = 0; k < this.seg.length; k++) if (this.seg[k] >= 0) set.add(this.seg[k]);
    this._aliveCache = [...set];
    this._aliveVer = this.version;
    return this._aliveCache;
  }

  isSegmented() { return this.cracks.length >= 2; }

  /** Sel material terdekat dari tip: {seg, k, dist, dy}; seg = -1 bila tidak ada. */
  contact(tip, reach = 0.45) {
    let best = { seg: -1, k: -1, dist: 999, dy: 0 };
    const locals = new Map();
    for (let k = 0; k < this.seg.length; k++) {
      const s = this.seg[k];
      if (s < 0) continue;
      let l = locals.get(s);
      if (!l) { l = this.worldToLocal(tip, s); locals.set(s, l); }
      const c = this.cellCenter(k % N, (k / N) | 0);
      const d = Math.hypot(l.x - c.x, l.z - c.y);
      if (d > reach || d >= best.dist) continue;
      if (l.y > this.top[k] + 0.3 || l.y < this.bot[k] - 0.2) continue;
      best = { seg: s, k, dist: d, dy: l.y - this.top[k] };
    }
    return best;
  }

  /** Ketinggian atas material tepat di bawah tip; NaN bila tidak ada. */
  surfaceUnder(tip) {
    for (const s of this.aliveSegments()) {
      const l = this.worldToLocal(tip, s);
      const i = Math.floor((l.x + A.NUC_A) / this.cell);
      const j = Math.floor((l.z + A.NUC_A) / this.cell);
      if (i < 0 || j < 0 || i >= N || j >= N) continue;
      const k = this.idx(i, j);
      if (this.seg[k] === s) return this.centerWorld().y + this.offsetOf(s).y + this.top[k];
    }
    return NaN;
  }

  /** Sculpting: menurunkan permukaan atas material di sekitar tip. */
  sculpt(tip, radius, amount) {
    let removed = 0;
    const locals = new Map();
    for (let k = 0; k < this.seg.length; k++) {
      const s = this.seg[k];
      if (s < 0) continue;
      let l = locals.get(s);
      if (!l) { l = this.worldToLocal(tip, s); locals.set(s, l); }
      const c = this.cellCenter(k % N, (k / N) | 0);
      const d = Math.hypot(l.x - c.x, l.z - c.y);
      if (d > radius) continue;
      if (l.y > this.top[k] + 0.18 || l.y < this.bot[k] - 0.1) continue;
      const falloff = 1 - d / radius;
      let newTop = Math.max(this.top[k] - amount * (0.4 + 0.6 * falloff), l.y - 0.12);
      newTop = Math.max(newTop, this.bot[k]);
      if (newTop < this.top[k]) {
        removed += this.top[k] - newTop;
        this.top[k] = newTop;
        if (this.top[k] - this.bot[k] < EMPTY_EPS) this.seg[k] = -1;
      }
    }
    if (removed > 0) this.version++;
    return removed;
  }

  /** Emulsifikasi fragmen s yang ter-oklusi di tip + tarik fragmen ke tip (followability). */
  emulsify(s, tip, amount, pull) {
    let nearest = -1, nd = 999;
    let l = this.worldToLocal(tip, s);
    for (let k = 0; k < this.seg.length; k++) {
      if (this.seg[k] !== s) continue;
      const c = this.cellCenter(k % N, (k / N) | 0);
      const d = Math.hypot(l.x - c.x, l.z - c.y);
      if (d < nd) { nd = d; nearest = k; }
    }
    if (nearest < 0) return 0;
    let removed = 0, budget = amount;
    const nc = this.cellCenter(nearest % N, (nearest / N) | 0);
    for (let k = 0; k < this.seg.length; k++) {
      if (this.seg[k] !== s || budget <= 0) continue;
      const c = this.cellCenter(k % N, (k / N) | 0);
      if (c.distanceTo(nc) > 0.42) continue;
      const th = this.top[k] - this.bot[k];
      const take = Math.min(th, budget);
      const mid = (this.top[k] + this.bot[k]) * 0.5;
      this.top[k] = mid + (th - take) * 0.5;
      this.bot[k] = mid - (th - take) * 0.5;
      budget -= take;
      removed += take;
      if (this.top[k] - this.bot[k] < EMPTY_EPS) this.seg[k] = -1;
    }
    if (pull > 0 && this.isSegmented()) {
      l = this.worldToLocal(tip, s);
      const delta = new V3(l.x - nc.x, 0, l.z - nc.y);
      let off = this.offsetOf(s).add(delta.mul(clamp(pull, 0, 1)));
      off.y = lerp(off.y, 0.35, clamp(pull, 0, 1) * 0.5);
      this.seg_offset.set(s, off);
    }
    this.version++;
    return removed;
  }

  /** Aspirasi tanpa ultrasound (nukleus lunak grade 1). */
  aspirateSoft(s, tip, amount) {
    if (this.hardness > 1.5) return 0;
    return this.emulsify(s, tip, amount * 0.5, 0.05);
  }

  /** Kedalaman trench rata-rata sepanjang garis lokal: {mean, coverage}. */
  trenchDepth(angleDeg) {
    const a = deg2rad(angleDeg);
    const dx = Math.cos(a), dy = Math.sin(a);
    let total = 0, deep = 0, n = 0;
    for (let si = 0; si <= 26; si++) {
      const s = -2.6 + si * 0.2;
      if (Math.abs(s) <= 0.25) continue;
      const px = dx * s, py = dy * s;
      const i = Math.floor((px + A.NUC_A) / this.cell);
      const j = Math.floor((py + A.NUC_A) / this.cell);
      if (i < 0 || j < 0 || i >= N || j >= N) continue;
      const k = this.idx(i, j);
      if (this.orig[k] > 0.1) {
        const frac = 1 - this.thickness(k) / this.orig[k];
        total += frac;
        if (frac >= 0.7) deep++;
        n++;
      }
    }
    if (n === 0) return { mean: 0, coverage: 0 };
    return { mean: total / n, coverage: deep / n };
  }

  addCrackLine(angleDeg) {
    this._addHalf(angleDeg);
    this._addHalf(angleDeg + 180);
    this.recomputeSegments();
  }

  addCrackHalf(angleDeg) {
    this._addHalf(angleDeg);
    this.recomputeSegments();
  }

  _addHalf(angleDeg) {
    const a = fposmod(angleDeg, 360);
    for (const c of this.cracks) if (A.angleDiff(c, a) < 12) return;
    this.cracks.push(a);
    this.cracks.sort((x, y) => x - y);
  }

  recomputeSegments() {
    this.seg_offset.clear();
    if (this.cracks.length < 2) {
      this.seg_count = 1;
      for (let k = 0; k < this.seg.length; k++) if (this.seg[k] >= 0) this.seg[k] = 0;
      this.version++;
      return;
    }
    this.seg_count = this.cracks.length;
    const dirs = this.cracks.map((ca) => new V2(Math.cos(deg2rad(ca)), Math.sin(deg2rad(ca))));
    for (let k = 0; k < this.seg.length; k++) {
      if (this.seg[k] < 0) continue;
      const c = this.cellCenter(k % N, (k / N) | 0);
      const phi = fposmod(rad2deg(Math.atan2(c.y, c.x)), 360);
      let onCrack = false;
      for (const dir of dirs) {
        if (c.dot(dir) > 0 && Math.abs(c.cross(dir)) < this.cell * 0.45) { onCrack = true; break; }
      }
      if (onCrack) { this.seg[k] = -1; continue; }
      let sector = this.cracks.length - 1;
      for (let m = 0; m < this.cracks.length; m++) {
        const a0 = this.cracks[m];
        let a1 = this.cracks[(m + 1) % this.cracks.length];
        if (a1 <= a0) a1 += 360;
        let p = phi;
        if (p < a0) p += 360;
        if (p >= a0 && p < a1) { sector = m; break; }
      }
      this.seg[k] = sector;
    }
    this.version++;
  }

  /** Hapus seluruh material (fast-forward sandbox setelah fakoemulsifikasi). */
  clearAll() {
    this.seg.fill(-1);
    this.top.fill(0);
    this.bot.fill(0);
    this.seg_offset.clear();
    this.version++;
  }

  worldAngleToLocal(worldDeg) { return fposmod(worldDeg + this.rotation_deg, 360); }

  // Rotasi tidak mengubah geometri lokal — renderer cukup memutar node (tanpa rebuild).
  rotate(deltaDeg) {
    this.rotation_deg += deltaDeg;
  }

  /** Ukuran fragmen terbesar (fraksi dari total awal). */
  largestSegmentFraction() {
    let best = 0;
    for (const s of this.aliveSegments()) best = Math.max(best, this.segmentMass(s));
    return best / Math.max(this.total_initial, 0.001);
  }
}
