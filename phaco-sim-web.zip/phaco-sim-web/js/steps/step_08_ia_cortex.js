// Langkah 8 — Irigasi & Aspirasi (I/A) korteks.
//
// Korteks = 24 sektor di forniks/ekuator kapsul.
//   1. Tip I/A ke perifer di bawah tepi rhexis (r ≥ 3.3 mm).
//   2. Pedal 2: korteks menutup port -> vakum naik; ≥ ambang -> tergenggam.
//   3. Tarik ke tengah (sentripetal) -> lembar korteks terkelupas & teraspirasi.
// Sektor subinsisional (±40° dari insisi utama) lebih melekat -> butuh vakum lebih tinggi.
// Bahaya: port menghisap kapsul saat tidak ada korteks -> REFLUX (≤ 1.6 s) atau PCR.
import { StepBase } from '../core/step_base.js';
import { CORTEX_SECTORS } from '../core/case_state.js';
import * as A from '../core/anatomy.js';
import { V3, clamp, fposmod } from '../core/math.js';

export class Step08IaCortex extends StepBase {
  constructor() {
    super();
    this.title = '8. I/A Korteks';
    this.short_title = 'I/A';
    this.target_time = 120;
    this._grasp_sector = -1;
    this._grasp_r = 0;
    this._caught = 0;
    this._caught_count = 0;
    this._sub_done = false;
  }

  enter() {
    this.obj('cortex', 'Aspirasi seluruh korteks (<= 5% tersisa)');
    this.obj('sub', 'Bersihkan korteks subinsisional');
    this.uses_pedal = true;
    this.show_pedal_settings = true;
    this.fluidics.active = true;
    this.fluidics.applyPreset('I/A');
    this.fluidics.bottle_cm = 75;
    this.right_label = 'I/A TIP';
    this.rig.insert('right', 'ia', this.cs.getIncision('main'), 2.2);
    this.setActions([]);
    this.hint = 'Bawa tip ke perifer (bawah tepi rhexis), pedal 2 untuk menggenggam korteks, lalu tarik ke tengah.';
    this._grasp_sector = -1;
    this._caught = 0;
    this._caught_count = 0;
  }

  _sectorOf(deg) { return Math.floor((fposmod(deg, 360) / 360) * CORTEX_SECTORS) % CORTEX_SECTORS; }

  _subincisional(deg) {
    return A.angleDiff(deg, this.cs.getIncision('main')?.angle ?? 180) < 40;
  }

  update(dt, input) {
    const cs = this.cs, f = this.fluidics, pedal = this.pedal, t = this.rig.right;
    this.moveTool(t, input.rs, input.rd, dt, input.fine, { aspirating: pedal.aspirating(), vacuum: f.vacuum });
    const tip = t.tip;
    const r = A.radial(tip);
    const md = A.meridianDeg(tip);
    const sec = this._sectorOf(md);
    const cortexHere = cs.cortex[sec];
    const periph = t.in_bag && r >= 3.3;
    let occl = false;
    if (this._grasp_sector >= 0) occl = true;
    else if (periph && cortexHere > 0.05 && pedal.aspirating()) occl = true;
    const last = this.safety.last;
    const nearCapsule = t.in_bag && ((last.posterior_gap ?? 99) < 0.3 || (last.equator_gap ?? 99) < 0.22);
    if (nearCapsule && cortexHere < 0.15 && pedal.aspirating() && this._grasp_sector < 0) occl = true;
    f.update(dt, pedal, cs, occl);
    const vac = f.vacuum;

    // --- genggam & kupas korteks ---
    if (this._grasp_sector < 0 && periph && cortexHere > 0.05 && pedal.aspirating()) {
      const sub = this._subincisional(md);
      const need = sub ? 300 : 150;
      if (vac >= need) {
        this._grasp_sector = sec;
        this._grasp_r = r;
        this.haptics.pulse(20, 0.4);
        this.hint = 'Korteks tergenggam. Tarik pelan ke tengah (sentripetal).';
      } else if (sub) {
        this.hint = 'Korteks subinsisional melekat kuat: perlu vakum >= 300 mmHg (pedal 2 lebih dalam).';
      }
    }
    if (this._grasp_sector >= 0) {
      if (!pedal.aspirating()) {
        this._grasp_sector = -1;
        this.hint = 'Genggaman lepas (pedal < 2).';
      } else {
        const pulled = Math.max(0, this._grasp_r - r);
        const amt = pulled * 0.5;
        const g = this._grasp_sector;
        cs.cortex[g] = Math.max(0, cs.cortex[g] - amt);
        for (const k of [-1, 1]) {
          const nb = (g + k + CORTEX_SECTORS) % CORTEX_SECTORS;
          cs.cortex[nb] = Math.max(0, cs.cortex[nb] - amt * 0.35);
        }
        this._grasp_r = Math.min(this._grasp_r, r);
        if (r < 2.4 || cs.cortex[g] <= 0.01) {
          cs.cortex[g] = 0;
          this._grasp_sector = -1;
          this.haptics.tick();
          this.hint = 'Lembar korteks teraspirasi. Lanjut ke sektor lain.';
        }
      }
    }

    // --- kapsul tersedot ---
    if (nearCapsule && cortexHere < 0.15 && pedal.aspirating() && vac > 120 && this._grasp_sector < 0) {
      if (this._caught <= 0) {
        this._caught_count++;
        this.comp.report('capsule_caught');
        this.haptics.alarm(2);
      }
      this._caught += dt;
      this.hint = '! KAPSUL TERSEDOT! Lepas pedal ke 0 + tekan REFLUX!';
      if ((this._caught > 1.6 || vac > 380) && !cs.pcr) {
        cs.pcr = true;
        cs.pcr_pos = new V3(tip.x, A.capsulePosteriorY(r) + cs.diaphragmShift(), tip.z);
        this.comp.report('pcr', 'kapsul teraspirasi');
        this.haptics.alarm(3);
      }
    } else if (pedal.refluxActive() || !pedal.aspirating()) {
      if (this._caught > 0) this.hint = 'Kapsul terlepas. Lanjutkan dengan hati-hati, port menghadap ke atas.';
      this._caught = 0;
    }

    let subLeft = 0;
    for (let i = 0; i < CORTEX_SECTORS; i++) {
      if (this._subincisional(((i + 0.5) / CORTEX_SECTORS) * 360)) subLeft += cs.cortex[i];
    }
    this._sub_done = subLeft < 0.1;
    const rem = cs.cortexRemaining();
    this.setDone('cortex', rem <= 0.05, `sisa ${Math.floor(rem * 100)}%`);
    this.setDone('sub', this._sub_done);
    if (cs.ovd_ac > 0) cs.ovd_ac = Math.max(0, cs.ovd_ac - (f.flow / 30) * 0.3 * dt);
    t.updateVisual();
  }

  exit() {
    this.fluidics.active = false;
    super.exit();
  }

  applyIdeal() {
    this.cs.cortex.fill(0);
    this.cs.ovd_ac = 0;
  }

  computeQuality() {
    let q = 100 * (1 - this.cs.cortexRemaining());
    q -= this._caught_count * 6;
    if (this._caught_count > 0) {
      this.note(`Kapsul tersedot ${this._caught_count}×. Arahkan port aspirasi ke atas/ke korteks, jangan ke kapsul posterior.`);
    }
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    return `Korteks tersisa: ${Math.floor(this.cs.cortexRemaining() * 100)}%\nGenggam: ${this._grasp_sector >= 0 ? 'YA' : '-'}\n`
      + `Sektor: ${A.clockHour(A.meridianDeg(this.rig.right.tip))}`;
  }
}
