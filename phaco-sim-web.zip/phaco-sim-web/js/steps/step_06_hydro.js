// Langkah 6 — Hidrodiseksi & hidrodelineasi + uji rotasi nukleus.
//
//   * Hidrodiseksi : kanula di bawah tepi rhexis (subkapsular), injeksi BSS -> gelombang.
//   * Tekanan kantong naik saat injeksi; dekompresi dengan menekan nukleus di tengah.
//     Tekanan > 100% -> capsular block -> PCR.
//   * Hidrodelineasi: kanula ke dalam lensa (epinukleus) -> cincin emas.
//   * Uji rotasi: nukleus harus berputar bebas.
import { StepBase, scoreBand } from '../core/step_base.js';
import * as A from '../core/anatomy.js';
import { V3, clamp, fposmod, rad2deg } from '../core/math.js';

export class Step06Hydro extends StepBase {
  constructor() {
    super();
    this.title = '6. Hidrodiseksi & Hidrodelineasi';
    this.short_title = 'Hidro';
    this.target_time = 50;
    this._peak_pressure = 0;
    this._rotated = 0;
    this._last_ang = 0;
    this._rotating = false;
    this._site_start = false;
    this._wave_timer = 0;
  }

  enter() {
    this.obj('dissect', 'Hidrodiseksi tuntas (gelombang cairan 100%)');
    this.obj('delin', 'Hidrodelineasi (cincin emas)');
    this.obj('rotate', 'Nukleus berputar bebas >= 45°');
    this.right_label = 'KANULA BSS';
    this.rig.insert('right', 'cannula', this.cs.getIncision('main'), 2.0);
    this.setActions([
      { id: 'inject', label: 'Injeksi\nBSS' },
      { id: 'press', label: 'Tekan\nNukleus' },
      { id: 'rotate', label: 'Putar\nNukleus' },
    ]);
    this.hint = 'Masuk lewat rhexis, geser ke bawah TEPI rhexis (subkapsular), lalu injeksi BSS pelan-pelan.';
    this._peak_pressure = 0;
    this._rotated = 0;
    this._rotating = false;
  }

  update(dt, input) {
    const cs = this.cs, t = this.rig.right;
    this.moveTool(t, input.rs, input.rd, dt, input.fine);
    const tip = t.tip;
    const r = A.radial(tip);
    const md = A.meridianDeg(tip);
    const rx = cs.rhexisRadiusAt(md);
    const shift = cs.diaphragmShift();
    const yAnt = A.capsuleAnteriorY(r) + shift;
    const subcapsular = t.in_bag && r > rx - 0.3 && r < rx + 1.2 && tip.y > yAnt - 0.5;
    const intralenticular = t.in_bag && r < rx - 0.3 && tip.y < yAnt - 0.5 && tip.y > yAnt - 1.8;

    let extraInflow = 0;
    if (this.held(input, 'inject')) {
      if (subcapsular) {
        if (!this._site_start) {
          this._site_start = true;
          cs.hydro_sites.push(md);
        }
        cs.hydro_dissection = Math.min(1, cs.hydro_dissection + 0.38 * dt);
        cs.bag_pressure += 0.42 * dt;
        this._wave_timer -= dt;
        if (this._wave_timer <= 0) {
          this._wave_timer = 1.2;
          this.sim.eye.hydro_wave = 0.02;
          this.haptics.pulse(30, 0.35);
        }
        this.hint = 'Gelombang cairan terlihat? Jangan injeksi terus — dekompresi dengan Tekan Nukleus.';
      } else if (intralenticular) {
        cs.hydro_delineation = Math.min(1, cs.hydro_delineation + 0.4 * dt);
        cs.bag_pressure += 0.15 * dt;
      } else {
        extraInflow = 18;
        cs.aqueous = Math.min(1, cs.aqueous + 0.1 * dt);
      }
    } else {
      this._site_start = false;
    }
    // dekompresi
    let decay = 0.12;
    if (this.held(input, 'press') && t.in_bag && r < 1.8) {
      decay = 1.1;
      cs.zonular_stress += 0.02 * dt;
    }
    cs.bag_pressure = Math.max(0, cs.bag_pressure - decay * dt);
    this._peak_pressure = Math.max(this._peak_pressure, cs.bag_pressure);
    if (cs.bag_pressure > 0.7) this.hint = '! Tekanan kantong tinggi! Tekan nukleus di tengah untuk dekompresi.';
    if (cs.bag_pressure > 1.0 && !cs.pcr) {
      this.comp.report('capsular_block');
      cs.pcr = true;
      cs.pcr_pos = new V3(0.6, A.capsulePosteriorY(0.6) + shift, 0.3);
      this.haptics.alarm(3);
      cs.bag_pressure = 0.3;
    }

    // uji rotasi
    if (this.held(input, 'rotate') && t.in_bag && r > 0.8 && r < 3.2) {
      const ang = rad2deg(Math.atan2(tip.z, tip.x));
      if (this._rotating) {
        const da = fposmod(ang - this._last_ang + 180, 360) - 180;
        if (cs.hydro_dissection >= 0.95) {
          cs.nucleus.rotate(-da);
          this._rotated += Math.abs(da);
        } else {
          cs.nucleus.rotate(-da * 0.25);
          cs.zonular_stress += Math.abs(da) * 0.006;
          if (Math.abs(da) > 0.2) this.comp.report('zonular_stress', 'nukleus belum bebas');
        }
      }
      this._last_ang = ang;
      this._rotating = true;
    } else {
      this._rotating = false;
    }
    if (this._rotated >= 45) cs.nucleus_free = true;

    this.fluidics.updatePassive(dt, cs, extraInflow);
    this.setDone('dissect', cs.hydro_dissection >= 1, `${Math.floor(cs.hydro_dissection * 100)}%`);
    this.setDone('delin', cs.hydro_delineation >= 0.6, `${Math.floor(cs.hydro_delineation * 100)}%`);
    this.setDone('rotate', cs.nucleus_free, `${Math.floor(this._rotated)}°`);
    t.updateVisual();
  }

  applyIdeal() {
    const cs = this.cs;
    cs.hydro_dissection = 1;
    cs.hydro_delineation = 1;
    cs.nucleus_free = true;
    cs.hydro_sites = [0, 180];
  }

  computeQuality() {
    const cs = this.cs;
    let q = 40 * cs.hydro_dissection + 20 * cs.hydro_delineation;
    q += (20 * scoreBand(this._peak_pressure, 0, 0.6, -1, 1.0)) / 100;
    let spread = 0;
    for (const a of cs.hydro_sites) for (const b of cs.hydro_sites) spread = Math.max(spread, A.angleDiff(a, b));
    q += 20 * clamp(spread / 90, 0, 1);
    if (spread < 60) this.note('Injeksi hidrodiseksi di >= 2 lokasi berjauhan (mis. subinsisional & seberangnya).');
    if (this._peak_pressure > 0.8) this.note('Tekanan kantong mendekati capsular block. Injeksi lebih pelan & dekompresi.');
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    const cs = this.cs;
    return `Diseksi: ${Math.floor(cs.hydro_dissection * 100)}%\nDelineasi: ${Math.floor(cs.hydro_delineation * 100)}%\n`
      + `Tekanan kantong: ${Math.floor(cs.bag_pressure * 100)}%\nRotasi: ${Math.floor(this._rotated)}°`;
  }
}
