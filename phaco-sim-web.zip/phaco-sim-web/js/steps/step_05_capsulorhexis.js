// Langkah 5 — Continuous Curvilinear Capsulorhexis (CCC) dengan sistotom.
//
//   * Inisiasi: tusuk kapsul di dekat pusat (tip menyentuh kapsul + TAHAN Grasp).
//   * Flap dibawa ke radius ±2.5 mm, lalu robekan diarahkan melingkar.
//   * Front robekan F bergerak ke arah tarikan (tip − F) dengan slack 0.25 mm.
//   * Bias run-out ke perifer, makin kuat bila OVD kurang & nukleus padat.
//   * Jarak tip-flap > 1.6 mm -> grip lepas; re-grasp dekat flap.
//   * |F| > 3.4 mm: peringatan; |F| > 4.1 mm: RUN-OUT.
//   * Selesai bila sapuan ≥ 340° dan front kembali dekat titik awal lingkaran.
import { StepBase, scoreBand } from '../core/step_base.js';
import { RHEXIS_BINS } from '../core/case_state.js';
import * as A from '../core/anatomy.js';
import { V2, TAU, clamp, fposmod, rad2deg } from '../core/math.js';

export class Step05Capsulorhexis extends StepBase {
  constructor() {
    super();
    this.title = '5. Kapsulorheksis (CCC)';
    this.short_title = 'CCC';
    this.target_time = 75;
    this._flap = new V2();
    this._grip = false;
    this._started = false;
    this._sweeping = false;
    this._sweep = 0;
    this._sweep_start = new V2();
    this._last_ang = 0;
    this._grip_losses = 0;
    this._runout = false;
    this._tear_tick = 0;
    this._path_last = new V2();
  }

  enter() {
    this.obj('init', 'Tusuk kapsul anterior di tengah & buat flap');
    this.obj('tear', 'Robek melingkar 360° kontinu');
    this.obj('size', 'Diameter 5.0–5.5 mm, sentris');
    this.right_label = 'SISTOTOM';
    this.rig.insert('right', 'cystotome', this.cs.getIncision('main'), 2.5);
    this.setActions([
      { id: 'grasp', label: 'Grasp /\nTusuk' },
      { id: 'ovd', label: 'Tambah\nOVD' },
    ]);
    this.hint = 'Turunkan sistotom ke kapsul di tengah pupil, lalu TAHAN Grasp untuk menusuk.';
    this._flap = new V2();
    this._grip = false;
    this._started = false;
    this._sweeping = false;
    this._sweep = 0;
    this._grip_losses = 0;
    this._runout = false;
    this.cs.rhexis_path = [];
    this.cs.rhexis_flap = false;
  }

  update(dt, input) {
    const cs = this.cs, t = this.rig.right;
    this.moveTool(t, input.rs, input.rd, dt, input.fine, { allow_capsule_contact: true });
    const tip2 = new V2(t.tip.x, t.tip.z);
    const contact = !!this.safety.last.capsule_contact;

    if (this.held(input, 'ovd')) cs.ovd_ac = Math.min(cs.ovd_ac + 0.2 * dt, 1.15);
    cs.ovd_ac = Math.max(0, cs.ovd_ac - cs.woundLeak() * 0.012 * dt);
    this.fluidics.updatePassive(dt, cs);

    if (cs.rhexis_done) { t.updateVisual(); return; }

    const grasp = this.held(input, 'grasp');
    if (!this._started) {
      if (grasp && contact && tip2.length() < 1.6) {
        this._started = true;
        this._grip = true;
        this._flap = tip2.clone();
        this._path_last = tip2.clone();
        cs.rhexis_flap = true;
        cs.rhexis_path.push(tip2.clone());
        this.haptics.pulse(30, 0.6);
        this.setDone('init');
        this.hint = 'Flap terbentuk. Tarik flap ke luar ±2.5 mm, lalu arahkan robekan melingkar.';
      } else if (grasp && contact) {
        this.hint = 'Tusuk lebih ke tengah (r < 1.6 mm).';
      }
    } else {
      if (grasp && !this._grip && tip2.distanceTo(this._flap) < 0.6) {
        this._grip = true;
        this.haptics.tick();
        this.hint = 'Flap di-grasp ulang. Lanjutkan robekan.';
      }
      if (!grasp) this._grip = false;
      if (this._grip) {
        const d = tip2.sub(this._flap);
        const dist = d.length();
        if (dist > 1.6) {
          this._grip = false;
          this._grip_losses++;
          this.haptics.pulse(25, 0.4);
          this.hint = 'Grip lepas! Kembali ke flap (<=0.6 mm) dan TAHAN Grasp lagi.';
        } else if (dist > 0.25) {
          const adv = Math.min(dist - 0.25, 2.2 * dt);
          const dir = d.mul(1 / dist);
          const fr = this._flap.length();
          let bias = 0;
          if (fr > 1.4) {
            bias = 0.12 + clamp(1.1 - cs.ovd_ac, 0, 1.1) * 0.7 + (cs.nucleus_grade - 1) * 0.03;
          }
          const outward = fr > 0.01 ? this._flap.normalized() : new V2();
          this._flap = this._flap.add(dir.add(outward.mul(bias)).normalized().mul(adv));
          this._tear_tick -= dt;
          if (this._tear_tick <= 0) {
            this._tear_tick = 0.12;
            this.haptics.tear();
          }
          if (this._flap.distanceTo(this._path_last) > 0.08) {
            cs.rhexis_path.push(this._flap.clone());
            this._path_last = this._flap.clone();
          }
        }
      }
      this._updateSweep();
      if (!cs.rhexis_done) this._checkRunout();
    }
    this.setDetail('tear', `${Math.floor(Math.abs(this._sweep))}°`);
    t.updateVisual();
  }

  _updateSweep() {
    const fr = this._flap.length();
    const ang = rad2deg(Math.atan2(this._flap.y, this._flap.x));
    if (!this._sweeping && fr > 2.0) {
      this._sweeping = true;
      this._sweep_start = this._flap.clone();
      this._last_ang = ang;
      this.hint = 'Sekarang robek melingkar. Tarik SEDIKIT ke arah tengah agar tidak lari ke perifer.';
      return;
    }
    if (this._sweeping) {
      const da = fposmod(ang - this._last_ang + 180, 360) - 180;
      this._sweep += da;
      this._last_ang = ang;
      if (Math.abs(this._sweep) >= 340 && this._flap.distanceTo(this._sweep_start) < 0.7) {
        this._complete();
      } else if (Math.abs(this._sweep) >= 390) {
        this.note('Ujung robekan tidak bertemu rapi dengan awal lingkaran (overlap/tag).');
        this._complete();
      }
    }
  }

  _checkRunout() {
    const fr = this._flap.length();
    if (fr > 3.4 && !this._runout) {
      this.hint = '! Robekan menuju perifer! Tambah OVD, re-grasp, tarik ke arah tengah.';
      this.haptics.pulse(60, 0.6);
    }
    if (fr > 4.1 && !this._runout) {
      this._runout = true;
      this.cs.rhexis_tear_deg = fposmod(rad2deg(Math.atan2(this._flap.y, this._flap.x)), 360);
      this.comp.report('rhexis_runout', A.clockHour(this.cs.rhexis_tear_deg));
      this.haptics.alarm(3);
      this._complete();
    }
  }

  _complete() {
    const cs = this.cs;
    const n = RHEXIS_BINS;
    const bins = new Float32Array(n);
    const counts = new Int32Array(n);
    for (const p of cs.rhexis_path) {
      if (p.length() < 1.2) continue;
      const a = fposmod(rad2deg(Math.atan2(p.y, p.x)), 360);
      const b = Math.floor((a / 360) * n) % n;
      bins[b] += p.length();
      counts[b]++;
    }
    let have = false;
    for (let i = 0; i < n; i++) if (counts[i] > 0) { bins[i] /= counts[i]; have = true; }
    if (!have) {
      bins.fill(2.6);
    } else {
      // interpolasi bin kosong dari tetangga terdekat
      const src = Float32Array.from(bins);
      for (let i = 0; i < n; i++) {
        if (counts[i] !== 0) continue;
        let l = i, r = i, steps = 0;
        while (counts[l] === 0 && steps < n) { l = (l - 1 + n) % n; steps++; }
        steps = 0;
        while (counts[r] === 0 && steps < n) { r = (r + 1) % n; steps++; }
        bins[i] = (src[l] + src[r]) * 0.5;
      }
    }
    if (this._runout) {
      const tb = Math.floor((cs.rhexis_tear_deg / 360) * n) % n;
      for (let k = -2; k <= 2; k++) {
        const b = (tb + k + n) % n;
        bins[b] = Math.max(bins[b], 4.0 - Math.abs(k) * 0.4);
      }
    }
    cs.rhexis_r = bins;
    cs.rhexis_done = true;
    cs.rhexis_flap = false;
    this._grip = false;
    this.setDone('tear');
    this.setDone('size', true, `Ø ${(cs.rhexisMeanRadius() * 2).toFixed(1)} mm`);
    this.haptics.pulse(60, 0.8);
    this.hint = 'Rhexis selesai (flap diangkat). Tekan LANJUT.';
  }

  _stats() {
    const cs = this.cs, n = RHEXIS_BINS;
    const mean = cs.rhexisMeanRadius();
    let vs = 0, cx = 0, cz = 0;
    for (let i = 0; i < n; i++) {
      const r = cs.rhexis_r[i];
      vs += (r - mean) * (r - mean);
      const a = (TAU * i) / n;
      cx += Math.cos(a) * r;
      cz += Math.sin(a) * r;
    }
    return { diam: mean * 2, sd: Math.sqrt(vs / n), decentr: (Math.hypot(cx, cz) / n) * 2 };
  }

  computeQuality() {
    if (!this.cs.rhexis_done) return 0;
    const s = this._stats();
    let q = scoreBand(s.diam, 5.0, 5.5, 3.5, 7.0) * 0.4;
    q += scoreBand(s.sd, 0, 0.15, -1, 0.7) * 0.35;
    q += scoreBand(s.decentr, 0, 0.3, -1, 1.4) * 0.25;
    if (this._runout) q -= 30;
    q -= Math.max(0, this._grip_losses - 3) * 3;
    if (s.diam > 6.0) this.note(`Rhexis terlalu besar (Ø ${s.diam.toFixed(1)} mm): tepi tidak overlap optik IOL 360°.`);
    else if (s.diam < 4.5) this.note(`Rhexis kecil (Ø ${s.diam.toFixed(1)} mm): phaco sulit, risiko phimosis kapsul.`);
    if (s.sd > 0.3) this.note(`Rhexis tidak bulat (SD radius ${s.sd.toFixed(2)} mm). Re-grasp lebih sering, dekat tepi robekan.`);
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  applyIdeal() { this.cs.setIdealRhexis(2.65); }

  telemetryExtra() {
    let txt = `Grip: ${this._grip ? 'YA' : 'tidak'}\nRadius robekan: ${this._flap.length().toFixed(2)} mm\n`
      + `Sapuan: ${Math.floor(Math.abs(this._sweep))}°\nOVD: ${Math.floor(this.cs.ovd_ac * 100)}%`;
    if (this.cs.rhexis_done) {
      const s = this._stats();
      txt += `\nØ ${s.diam.toFixed(2)} mm · SD ${s.sd.toFixed(2)} · decentr ${s.decentr.toFixed(2)}`;
    }
    return txt;
  }
}
