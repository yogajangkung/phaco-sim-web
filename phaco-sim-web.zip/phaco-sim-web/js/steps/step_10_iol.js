// Langkah 10 — Implantasi IOL lipat dengan injector + dialing haptik dengan Sinskey hook.
//
// "inject": ujung cartridge di luka utama. Slider PEDAL = PLUNGER. Saat haptik leading
//   keluar (±45%), bevel harus diarahkan turun ke kantong & kantong terisi OVD.
// "dial": Sinskey hook via side-port. Kaitkan lutut haptik trailing (cincin kuning),
//   TAHAN "Kait & Putar", putar ≥ 70° -> haptik trailing masuk kantong. Lalu sentrasi.
import { StepBase, scoreBand } from '../core/step_base.js';
import { SafetyMonitor } from '../core/safety_monitor.js';
import * as A from '../core/anatomy.js';
import { V2, V3, clamp, fposmod, rad2deg } from '../core/math.js';

export class Step10Iol extends StepBase {
  constructor() {
    super();
    this.title = '10. Implantasi & Dialing IOL';
    this.short_title = 'IOL';
    this.target_time = 80;
    this._phase = 'inject';
    this._lead_checked = false;
    this._fast_time = 0;
    this._too_fast = false;
    this._hooked = false;
    this._hook_last = 0;
    this._hook_prev = new V2();
    this._dialed = 0;
  }

  enter() {
    const cs = this.cs;
    this.obj('push', 'Dorong IOL keluar dari cartridge (plunger)');
    this.obj('lead', 'Haptik leading masuk kantong kapsul');
    this.obj('trail', 'Dialing: haptik trailing masuk kantong');
    this.obj('center', 'Sentrasi IOL (< 0.3 mm)');
    this._phase = 'inject';
    this.phase = 'inject';
    this.uses_pedal = true;
    this.pedal_label = 'PLUNGER';
    this.right_label = 'INJECTOR';
    this.rig.insert('right', 'injector', cs.getIncision('main'), 0.5);
    this.setActions([]);
    this.hint = 'Ujung cartridge di luka. TURUNKAN tip (slider) agar bevel mengarah ke kantong, lalu tekan PLUNGER perlahan.';
    this._lead_checked = false;
    this._fast_time = 0;
    this._too_fast = false;
    this._hooked = false;
    this._dialed = 0;
    cs.iol_progress = 0;
    cs.iol_present = false;
  }

  _anchor(t) {
    const inner = t.port.inner;
    const inward = new V3(-inner.x, 0, -inner.z).normalized();
    return inner.add(inward.mul(0.6));
  }

  update(dt, input) {
    this.fluidics.updatePassive(dt, this.cs);
    if (this._phase === 'inject') this._updateInject(dt, input);
    else this._updateDial(dt, input);
  }

  _updateInject(dt, input) {
    const cs = this.cs, t = this.rig.right;
    let desired = t.tip.add(SafetyMonitor.moveVector(input.rs, input.rd, dt, true));
    const anchor = this._anchor(t);
    const off = desired.sub(anchor);
    if (off.length() > 1.1) desired = anchor.add(off.normalized().mul(1.1));
    this.safety.constrain(t, desired, { dt });
    const inward = new V3(-anchor.x, 0, -anchor.z).normalized();
    const aimDown = clamp((0.9 - t.tip.y) * 0.4, -0.2, 0.6);
    const dir = inward.add(new V3(0, -aimDown, 0)).normalized();
    this.sim.injector_tip = t.tip.clone();
    this.sim.injector_dir = dir;

    const plunger = this.pedal.travel;
    if (plunger > 0.05) cs.iol_progress = Math.min(1, cs.iol_progress + plunger * 0.16 * dt);
    if (plunger > 0.85 && cs.iol_progress > 0.2 && cs.iol_progress < 0.95) {
      this._fast_time += dt;
      if (this._fast_time > 0.4 && !this._too_fast) {
        this._too_fast = true;
        this.note('IOL didorong terlalu cepat — unfolding tak terkontrol, risiko stres kapsul.');
        cs.zonular_stress += 0.2;
        this.comp.report('zonular_stress', 'IOL keluar terlalu cepat');
      }
    }
    cs.iol_present = cs.iol_progress > 0.04;
    this.setDetail('push', `${Math.floor(cs.iol_progress * 100)}%`);

    if (!this._lead_checked && cs.iol_progress >= 0.45) {
      this._lead_checked = true;
      const aimed = t.tip.y < 0.6;
      if (aimed && cs.ovd_bag >= 0.6) {
        cs.iol_lead_in_bag = true;
        this.setDone('lead');
        this.haptics.pulse(30, 0.5);
      } else {
        cs.iol_lead_in_bag = false;
        this.comp.report('iol_sulcus', 'haptik leading');
        this.note(aimed ? 'Kantong kurang OVD saat implantasi.'
          : 'Bevel injector tidak diarahkan ke kantong saat haptik leading keluar.');
      }
    }

    if (cs.iol_progress >= 1) {
      this.setDone('push');
      cs.iol_center = new V2(-0.7, 0.35);
      cs.iol_rot = 0;
      cs.iol_trail_in_bag = false;
      this.rig.remove('right');
      this.rig.insert('right', 'hook', cs.getIncision('side'), 2.0);
      this.right_label = 'SINSKEY HOOK';
      this.uses_pedal = false;
      this.pedal_label = 'PEDAL';
      this._phase = 'dial';
      this.phase = 'dial';
      this.setActions([{ id: 'dial', label: 'Kait &\nPutar' }]);
      this.hint = 'Kaitkan hook di lutut haptik trailing (cincin kuning), TAHAN Kait & Putar, putar melingkar.';
    }
    this.rig.right.updateVisual();
  }

  _updateDial(dt, input) {
    const cs = this.cs, t = this.rig.right, eye = this.sim.eye;
    this.moveTool(t, input.rs, input.rd, dt, input.fine);
    const c = cs.iol_center;
    const shift = cs.diaphragmShift();
    const hp = new V2(t.tip.x, t.tip.z);
    if (hp.distanceTo(c) < A.IOL_OPTIC_R && t.tip.y < cs.iol_y + shift + 0.15) t.tip.y = cs.iol_y + shift + 0.15;
    const knee = eye.iolTrailingKnee();
    eye.showTarget(knee, !cs.iol_trail_in_bag);

    if (this.held(input, 'dial')) {
      const ang = rad2deg(Math.atan2(hp.y - c.y, hp.x - c.x));
      if (!this._hooked) {
        if (hp.distanceTo(new V2(knee.x, knee.z)) < 0.9
          || (cs.iol_trail_in_bag && hp.distanceTo(c) < A.IOL_OPTIC_R + 0.6)) {
          this._hooked = true;
          this._hook_last = ang;
          this._hook_prev = hp.clone();
          this.haptics.tick();
        }
      } else {
        const da = fposmod(ang - this._hook_last + 180, 360) - 180;
        this._hook_last = ang;
        cs.iol_rot -= da;
        this._dialed += Math.abs(da);
        const push = hp.sub(this._hook_prev).mul(cs.iol_trail_in_bag ? 0.45 : 0.15);
        cs.iol_center = cs.iol_center.add(push).limitLength(2.0);
        this._hook_prev = hp.clone();
        if (Math.abs(da) > 0.5) this.haptics.pulse(8, 0.2);
      }
    } else {
      this._hooked = false;
    }

    if (!cs.iol_trail_in_bag && this._dialed >= 70 && cs.ovd_bag >= 0.4) {
      cs.iol_trail_in_bag = true;
      if (!cs.iol_lead_in_bag) {
        cs.iol_lead_in_bag = true;
        this.note('Haptik leading direposisi ke kantong saat dialing.');
      }
      this.setDone('lead');
      this.setDone('trail');
      this.haptics.pulse(40, 0.6);
      this.hint = 'Kedua haptik di kantong. Geser optik ke tengah (< 0.3 mm).';
    }
    if (cs.iol_trail_in_bag && cs.iol_lead_in_bag) {
      cs.iol_center = cs.iol_center.lerp(new V2(), 1 - Math.exp(-0.15 * dt));
    }
    const dec = cs.iol_center.length();
    this.setDetail('center', `${dec.toFixed(2)} mm`);
    this.setDone('center', cs.iol_trail_in_bag && dec < 0.3);
    this.setDetail('trail', `${Math.floor(this._dialed)}°`);
    t.updateVisual();
  }

  exit() {
    this.sim.eye.showTarget(new V3(), false);
    super.exit();
  }

  applyIdeal() {
    const cs = this.cs;
    cs.iol_present = true;
    cs.iol_progress = 1;
    cs.iol_lead_in_bag = true;
    cs.iol_trail_in_bag = true;
    cs.iol_center = new V2();
    cs.iol_rot = 20;
  }

  computeQuality() {
    const cs = this.cs;
    let q = cs.iol_lead_in_bag ? 25 : 5;
    q += cs.iol_trail_in_bag ? 25 : 0;
    q += scoreBand(cs.iol_center.length(), 0, 0.3, -1, 1.2) * 0.4;
    q += this._too_fast ? 0 : 10;
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    const cs = this.cs;
    if (this._phase === 'inject') {
      return `IOL keluar: ${Math.floor(cs.iol_progress * 100)}%\nPlunger: ${Math.floor(this.pedal.travel * 100)}%\n`
        + `Arah bevel: ${this.rig.right.tip.y < 0.6 ? 'ke kantong OK' : 'terlalu tinggi'}`;
    }
    return `Dialing: ${Math.floor(this._dialed)}°\nDesentrasi: ${cs.iol_center.length().toFixed(2)} mm\n`
      + `Hook: ${this._hooked ? 'terkait' : '-'}`;
  }
}
