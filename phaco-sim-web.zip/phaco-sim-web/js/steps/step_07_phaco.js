// Langkah 7 — Manajemen nukleus (Fakoemulsifikasi).
//
// "dc"   (Divide & Conquer): sculpt1 -> crack1 -> sculpt2 (putar 90°) -> crack2 -> quadrants -> epi
// "chop" (Phaco Chop horizontal): impale -> chop (≥ 4 fragmen) -> quadrants -> epi
// Kontrol: joystick KANAN = phaco tip, joystick KIRI = chopper.
// Pedal: 1 irigasi, 2 aspirasi (vakum naik bila oklusi), 3 ultrasound.
import { StepBase, scoreBand } from '../core/step_base.js';
import * as A from '../core/anatomy.js';
import { clamp, fposmod, rad2deg, deg2rad } from '../core/math.js';

export class Step07Phaco extends StepBase {
  constructor() {
    super();
    this.title = '7. Fakoemulsifikasi Nukleus';
    this.short_title = 'Phaco';
    this.target_time = 180;
    this._phase = '';
    this._trench1 = -1;
    this._trench2 = -1;
    this._crack_hold = 0;
    this._held_seg = -1;
    this._chop_active = false;
    this._chop_start = 0;
    this._chops = 0;
    this._impale_time = 0;
    this._surges = 0;
    this._cde_start = 0;
    this._endo_start = 0;
    this._rot_last = 0;
    this._rotating = false;
    this._emulsifying = false;
    this._best_depth = 0;
  }

  enter() {
    const cs = this.cs;
    this.uses_pedal = true;
    this.show_pedal_settings = true;
    this.pedal_label = 'PEDAL';
    this.right_label = 'PHACO TIP';
    this.left_label = 'CHOPPER';
    this.fluidics.active = true;
    this.fluidics.bottle_cm = 85;
    this.rig.insert('right', 'phaco', cs.getIncision('main'), 2.2);
    this.rig.insert('left', 'chopper', cs.getIncision('side'), 1.6);
    this._cde_start = cs.phaco_cde;
    this._endo_start = cs.endothelial_loss;
    this._surges = 0;
    this._chops = 0;
    this._trench1 = -1;
    this._trench2 = -1;
    this._impale_time = 0;
    this._held_seg = -1;
    if (cs.technique === 'chop') {
      this.obj('impale', 'Impale nukleus di tengah & tahan dengan vakum');
      this.obj('chop', 'Chop menjadi >= 4 fragmen');
      this.obj('remove', 'Emulsifikasi semua fragmen');
      this.obj('epi', 'Aspirasi epinukleus');
      this.setActions([
        { id: 'rotate', label: 'Putar\n(Chopper)' },
        { id: 'chop', label: 'CHOP' },
      ]);
      this._setPhase('impale');
    } else {
      this.obj('trench1', 'Pahat alur pertama (>= 75% kedalaman)');
      this.obj('crack1', 'Crack nukleus menjadi 2');
      this.obj('trench2', 'Putar 90° & pahat alur kedua');
      this.obj('crack2', 'Crack menjadi 4 kuadran');
      this.obj('remove', 'Emulsifikasi semua kuadran');
      this.obj('epi', 'Aspirasi epinukleus');
      this.setActions([
        { id: 'rotate', label: 'Putar\n(Chopper)' },
        { id: 'crack', label: 'CRACK' },
      ]);
      this._setPhase('sculpt1');
    }
  }

  _setPhase(ph) {
    this._phase = ph;
    this.phase = ph;
    const f = this.fluidics;
    switch (ph) {
      case 'sculpt1':
        f.applyPreset('Sculpt');
        this.hint = 'SCULPT: pedal 3, sapukan phaco tip lurus menjauhi insisi (kiri->kanan). Tiap sapuan sedikit lebih dalam.';
        break;
      case 'sculpt2':
        f.applyPreset('Sculpt');
        this.hint = 'Putar nukleus 90° dengan chopper (tahan PUTAR + gerak melingkar), lalu pahat alur kedua.';
        break;
      case 'crack1': case 'crack2':
        this.hint = 'CRACK: masukkan phaco & chopper ke dasar alur, lalu TAHAN tombol CRACK.';
        break;
      case 'impale':
        f.applyPreset('Chop');
        this.hint = 'IMPALE: pedal 3 singkat untuk menanam tip di tengah nukleus, lalu pedal 2 untuk menahan (vakum tinggi).';
        break;
      case 'chop':
        this.hint = 'CHOP: chopper ke perifer nukleus (bawah tepi rhexis), TAHAN CHOP dan tarik ke arah phaco tip.';
        break;
      case 'quadrants':
        f.applyPreset(this.cs.technique === 'chop' ? 'Chop' : 'Quadrant');
        this.hint = 'Oklusi fragmen (pedal 2) sampai vakum menahan, tarik ke tengah, lalu emulsifikasi (pedal 3).';
        break;
      case 'epi':
        f.applyPreset('Epi');
        this.hint = 'Aspirasi epinukleus (pedal 2–3 ringan). Hati-hati: kapsul posterior kini terbuka!';
        break;
      case 'done':
        this.hint = 'Nukleus bersih. Tekan LANJUT.';
        break;
    }
  }

  _holdVac() { return Math.max(100, this.fluidics.vac_limit * 0.4); }

  _collide(t, depthIn, dt) {
    const top = this.cs.nucleus.surfaceUnder(t.tip);
    if (Number.isNaN(top)) return;
    if (t.tip.y < top + 0.03 && t.prev_tip.y >= top - 0.05) {
      t.tip.y = top + 0.03;
      if (depthIn < -0.4) {
        this.cs.zonular_stress += 0.04 * dt;
        this.comp.report('zonular_stress', 'menekan nukleus');
      }
    }
  }

  update(dt, input) {
    const cs = this.cs, f = this.fluidics, pedal = this.pedal;
    const ph = this.rig.right, ch = this.rig.left;
    const nuc = cs.nucleus;
    const ctx = { aspirating: pedal.aspirating(), vacuum: f.vacuum };
    this.moveTool(ph, input.rs, input.rd, dt, input.fine, ctx);
    this.moveTool(ch, input.ls, input.ld, dt, input.fine, { ...ctx });
    this._collide(ch, input.ld, dt);
    if (pedal.position < 3) this._collide(ph, input.rd, dt);

    // --- oklusi ---
    const contact = nuc.contact(ph.tip, 0.4);
    const segmented = nuc.isSegmented();
    let occl = false;
    if (this._phase === 'impale' || this._phase === 'chop') occl = contact.seg >= 0;
    else if (segmented && this._phase !== 'epi') occl = contact.seg >= 0;
    f.update(dt, pedal, cs, occl);
    const power = f.power;
    const vac = f.vacuum;
    const hf = 0.6 + 0.35 * cs.nucleus_grade;
    this._emulsifying = false;

    // --- efek ultrasound ---
    if (power > 0) {
      if (!segmented || ['sculpt1', 'sculpt2', 'impale', 'crack1', 'crack2'].includes(this._phase)) {
        const rad = this._phase === 'impale' ? 0.35 : 0.55;
        const removed = nuc.sculpt(ph.tip, rad, (power / 100) * 1.4 / hf * dt);
        this._emulsifying = removed > 0;
      } else if (contact.seg >= 0) {
        const s = contact.seg;
        if (vac >= this._holdVac()) {
          const eff = clamp(vac / Math.max(f.vac_limit, 1), 0.3, 1);
          nuc.emulsify(s, ph.tip, (power / 100) * 2.4 / hf * dt * eff, 4 * dt);
          this._held_seg = s;
          this._emulsifying = true;
        } else {
          this.comp.report('chatter');
          cs.endothelial_loss += power * 0.0006 * dt;
          const off = nuc.offsetOf(s);
          off.y = Math.min(off.y + 0.6 * dt, 1.2);
          nuc.seg_offset.set(s, off);
        }
      } else {
        const r = A.radial(ph.tip);
        const nearEndo = ph.tip.y > A.corneaInnerY(r) - 0.9;
        cs.endothelial_loss += (power / 100) * 0.3 * dt * (nearEndo ? 2.5 : 1);
      }
      if (cs.wound_temp > 1 && !cs.wound_burn) {
        cs.wound_burn = true;
        this.comp.report('wound_burn');
        this.haptics.alarm(3);
      }
    } else if (occl && segmented && vac >= this._holdVac()) {
      // tahan & tarik fragmen ke zona aman tanpa ultrasound
      nuc.emulsify(contact.seg, ph.tip, 0, 3 * dt);
      this._held_seg = contact.seg;
    } else if (!occl) {
      this._held_seg = -1;
    }
    if (occl && pedal.aspirating() && cs.nucleus_grade === 1 && contact.seg >= 0 && segmented) {
      nuc.aspirateSoft(contact.seg, ph.tip, (f.flow / 30) * 0.6 * dt + 0.2 * dt);
    }

    const eye = this.sim.eye;
    eye.nucleus.held_segment = occl ? this._held_seg : -1;
    eye.particles.position = ph.tip.clone();
    eye.particles.emitting = this._emulsifying;
    this.haptics.phaco(power, dt);

    // OVD ikut teraspirasi selama phaco
    if (pedal.aspirating()) cs.ovd_ac = Math.max(0, cs.ovd_ac - (f.flow / 30) * 0.25 * dt);

    // --- surge & bilik ---
    if (f.surge_event > 180) {
      this._surges++;
      this.comp.report('surge', `${Math.floor(f.surge_event)} mmHg`);
      this.haptics.alarm(2);
      this.sim.cam.shake(0.6);
    }
    if (cs.chamber_depth < 0.5 && pedal.position >= 1) this.comp.report('chamber_collapse');

    this._rotation(input, ch);
    this._phaseLogic(input, dt, occl, vac);
    ph.updateVisual();
    ch.updateVisual();
  }

  _rotation(input, ch) {
    const cs = this.cs;
    const r = A.radial(ch.tip);
    if (this.held(input, 'rotate') && r > 0.8 && r < 3.9 && ch.in_bag) {
      const ang = rad2deg(Math.atan2(ch.tip.z, ch.tip.x));
      if (this._rotating) {
        const da = fposmod(ang - this._rot_last + 180, 360) - 180;
        if (cs.nucleus_free) {
          cs.nucleus.rotate(-da);
        } else {
          cs.nucleus.rotate(-da * 0.3);
          cs.zonular_stress += Math.abs(da) * 0.008;
          if (Math.abs(da) > 0.3) this.comp.report('zonular_stress', 'rotasi tanpa hidrodiseksi');
        }
      }
      this._rot_last = ang;
      this._rotating = true;
    } else {
      this._rotating = false;
    }
  }

  _bestTrench(center, span) {
    let best = { angle: center, mean: 0, coverage: 0 };
    for (let a = center - span * 0.5; a <= center + span * 0.5 + 1e-6; a += 10) {
      const info = this.cs.nucleus.trenchDepth(a);
      if (info.mean > best.mean) best = { angle: fposmod(a, 360), mean: info.mean, coverage: info.coverage };
    }
    return best;
  }

  _tipInTrench(t, angle) {
    const l = this.cs.nucleus.worldToLocal(t.tip, 0);
    const ar = deg2rad(angle);
    const along = l.x * Math.cos(ar) + l.z * Math.sin(ar);
    const perp = -l.x * Math.sin(ar) + l.z * Math.cos(ar);
    return Math.abs(perp) < 0.7 && Math.abs(along) > 0.3 && Math.abs(along) < 3.0 && l.y < 0.5;
  }

  _tryCrack(angle, input, dt) {
    if (!this.held(input, 'crack')) { this._crack_hold = 0; return false; }
    const ok = this._tipInTrench(this.rig.right, angle) && this._tipInTrench(this.rig.left, angle);
    if (!ok) {
      this.hint = 'Letakkan KEDUA tip (phaco & chopper) di dasar alur, lalu tahan CRACK.';
      this._crack_hold = 0;
      return false;
    }
    this._crack_hold += dt;
    this.hint = 'Dorong kedua dinding alur berlawanan arah...';
    if (this._crack_hold < 0.6) return false;
    this._crack_hold = 0;
    const info = this.cs.nucleus.trenchDepth(angle);
    if (info.mean < 0.6) {
      this.cs.zonular_stress += 0.25;
      this.comp.report('zonular_stress', 'alur dangkal');
      this.note('Crack gagal karena alur terlalu dangkal — pahat hingga ±80–90% tebal nukleus.');
      this.hint = 'Alur terlalu dangkal untuk crack! Pahat lebih dalam.';
      return false;
    }
    this.haptics.crack();
    return true;
  }

  _tryChop(input, occl, vac) {
    const ph = this.rig.right, ch = this.rig.left;
    const holding = occl && vac >= this.fluidics.vac_limit * 0.5;
    if (!this.held(input, 'chop')) { this._chop_active = false; return; }
    const chR = A.radial(ch.tip);
    const deep = ch.tip.y < this.cs.nucleus.centerWorld().y + 0.6 && ch.in_bag;
    if (!this._chop_active) {
      if (!holding) {
        this.hint = 'Tahan nukleus dulu: phaco tip tertanam + pedal 2 (vakum >= 50% limit).';
      } else if (chR >= 2.7 && deep) {
        this._chop_active = true;
        this._chop_start = ch.tip.distanceTo(ph.tip);
        this.hint = 'Tarik chopper ke arah phaco tip!';
      } else {
        this.hint = 'Chopper ke perifer nukleus (r >= 2.7 mm), dalam, di bawah tepi rhexis.';
      }
      return;
    }
    const d = ch.tip.distanceTo(ph.tip);
    if (!holding) {
      this._chop_active = false;
      this.cs.zonular_stress += 0.15;
      this.comp.report('zonular_stress', 'chop tanpa pegangan vakum');
      this.hint = 'Pegangan vakum lepas — nukleus terdorong. Impale ulang.';
      return;
    }
    if (this._chop_start - d >= 1.4) {
      const nuc = this.cs.nucleus;
      const local = nuc.worldAngleToLocal(A.meridianDeg(ch.tip));
      if (nuc.cracks.length < 2) nuc.addCrackLine(local);
      else nuc.addCrackHalf(local);
      this._chops++;
      this._chop_active = false;
      this.haptics.crack();
      this.hint = 'Chop berhasil! Putar nukleus dan chop lagi (target >= 4 fragmen).';
    }
  }

  _phaseLogic(input, dt, occl, vac) {
    const cs = this.cs, nuc = cs.nucleus;
    switch (this._phase) {
      case 'sculpt1': {
        const b = this._bestTrench(90, 180);
        this._best_depth = b.mean;
        this.setDetail('trench1', `${Math.floor(b.mean * 100)}%`);
        if (b.coverage >= 0.7 && b.mean >= 0.62) {
          this._trench1 = b.angle;
          this.setDone('trench1');
          this._setPhase('crack1');
        }
        break;
      }
      case 'crack1':
        if (this._tryCrack(this._trench1, input, dt)) {
          nuc.addCrackLine(this._trench1);
          this.setDone('crack1');
          this._setPhase('sculpt2');
        }
        break;
      case 'sculpt2': {
        const b2 = this._bestTrench(this._trench1 + 90, 60);
        this._best_depth = b2.mean;
        this.setDetail('trench2', `${Math.floor(b2.mean * 100)}%`);
        if (b2.coverage >= 0.7 && b2.mean >= 0.62) {
          this._trench2 = b2.angle;
          this.setDone('trench2');
          this._setPhase('crack2');
        }
        break;
      }
      case 'crack2':
        if (this._tryCrack(this._trench2, input, dt)) {
          nuc.addCrackLine(this._trench2);
          this.setDone('crack2');
          this._setPhase('quadrants');
        }
        break;
      case 'impale':
        if (occl && vac >= this.fluidics.vac_limit * 0.5 && A.radial(this.rig.right.tip) < 1.4) {
          this._impale_time += dt;
          if (this._impale_time > 0.5) {
            this.setDone('impale');
            this._setPhase('chop');
          }
        } else {
          this._impale_time = 0;
        }
        break;
      case 'chop':
        this._tryChop(input, occl, vac);
        this.setDetail('chop', `${nuc.aliveSegments().length} fragmen`);
        if (nuc.cracks.length >= 4 && nuc.largestSegmentFraction() < 0.4) {
          this.setDone('chop');
          this._setPhase('quadrants');
        }
        break;
      case 'quadrants': {
        const rem = nuc.remainingFraction();
        this.setDetail('remove', `sisa ${Math.floor(rem * 100)}%`);
        if (rem < 0.03) {
          nuc.clearAll();
          this.setDone('remove');
          this._setPhase('epi');
        }
        break;
      }
      case 'epi': {
        const ph = this.rig.right;
        const r = A.radial(ph.tip);
        if (this.pedal.aspirating() && ph.in_bag && r > 0.8 && r < 4.3) {
          const rate = this.pedal.aspirationLevel() * 0.09 + (this.fluidics.power / 100) * 0.25;
          cs.epi_mass = Math.max(0, cs.epi_mass - rate * dt);
        }
        this.setDetail('epi', `sisa ${Math.floor(cs.epi_mass * 100)}%`);
        if (cs.epi_mass < 0.04) {
          cs.epi_mass = 0;
          this.setDone('epi');
          this._setPhase('done');
        }
        break;
      }
    }
  }

  exit() {
    this.sim.eye.particles.emitting = false;
    this.sim.eye.nucleus.held_segment = -1;
    this.fluidics.active = false;
    super.exit();
  }

  applyIdeal() {
    const cs = this.cs;
    cs.nucleus.clearAll();
    cs.epi_mass = 0;
    cs.ovd_ac = 0.15;
    cs.nucleus_free = true;
    cs.phaco_cde += 4 + cs.nucleus_grade * 1.5;
  }

  computeQuality() {
    const cs = this.cs;
    const cde = cs.phaco_cde - this._cde_start;
    const g = cs.nucleus_grade;
    let q = scoreBand(cde, 0, g * 3, -1, g * 10) * 0.35;
    q += 40 * (1 - cs.nucleus.remainingFraction());
    q += 25 * (1 - cs.epi_mass);
    q -= this._surges * 4;
    const endo = cs.endothelial_loss - this._endo_start;
    q -= clamp(endo, 0, 20);
    if (this._surges > 0) this.note(`Terjadi ${this._surges} surge. Kurangi vakum limit / naikkan botol saat memegang fragmen terakhir.`);
    if (cde > g * 5) this.note(`CDE ${cde.toFixed(1)} tinggi untuk grade ${g}. Manfaatkan vakum & chop, kurangi ultrasound di bilik depan.`);
    if (endo > 4) this.note(`Energi ultrasound dekat endotel (${endo.toFixed(1)}% sel hilang). Emulsifikasi setinggi bidang iris, bukan di bilik depan atas.`);
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    const nuc = this.cs.nucleus;
    let txt = `Fase: ${this._phase.toUpperCase()}\n`;
    if (this._phase === 'sculpt1' || this._phase === 'sculpt2') {
      txt += `Kedalaman alur: ${Math.floor(this._best_depth * 100)}%\n`;
    } else if (['chop', 'quadrants', 'impale'].includes(this._phase)) {
      txt += `Fragmen: ${nuc.aliveSegments().length} · dipegang: ${this._held_seg >= 0 ? 'YA' : '-'}\n`;
    }
    txt += `Sisa nukleus: ${Math.floor(nuc.remainingFraction() * 100)}%\nEpinukleus: ${Math.floor(this.cs.epi_mass * 100)}%\n`
      + `CDE: ${this.cs.phaco_cde.toFixed(2)}`;
    return txt;
  }
}
