// Langkah 2 (paracentesis) & 4 (clear corneal incision utama).
import { IncisionStep } from './incision_step.js';
import * as A from '../core/anatomy.js';
import { clamp } from '../core/math.js';

// Langkah 2 — Paracentesis (side-port) dengan pisau 15°, ±90° dari insisi utama.
export class Step02Paracentesis extends IncisionStep {
  constructor() {
    super();
    this.title = '2. Paracentesis (Side-port)';
    this.short_title = 'Paracentesis';
    this.target_time = 30;
    this.inc_name = 'side';
    this.tool_kind = 'blade15';
    this.start_deg = 100;
    this.planned_deg = 90;     // jam 6 (±90° dari insisi utama temporal di jam 9)
    this.alt_deg = 270;
    this.angle_tol = 20;
    this.tunnel_lo = 0.5;
    this.tunnel_hi = 1.2;
    this.width = 1.0;
    this.advance_needed = 0.6;
  }

  enter() {
    super.enter();
    this.objectives[0].text = 'Masuk di limbus ±90° dari rencana insisi utama (jam 6 / jam 12)';
    this.hint = 'Pisau 15° di limbus bawah. Dorong ke arah pusat (joystick ATAS), jaga bidang sejajar iris.';
  }

  // aqueous bocor lewat side-port -> bilik mendangkal (memotivasi injeksi OVD)
  _onCreated() { this.cs.aqueous = clamp(this.cs.aqueous - 0.45, 0.2, 1); }

  applyIdeal() {
    const inner = A.pointOnLimbus(90, A.corneaInnerY(4.8) - 0.05, 4.8);
    this.cs.addIncision('side', 90, 0.9, inner, 1.0);
    this.cs.aqueous = 0.55;
  }
}

// Langkah 4 — Clear Corneal Incision utama (keratome 2.4 mm, temporal, terowongan ±2 mm).
export class Step04MainIncision extends IncisionStep {
  constructor() {
    super();
    this.title = '4. Clear Corneal Incision Utama';
    this.short_title = 'CCI';
    this.target_time = 40;
    this.inc_name = 'main';
    this.tool_kind = 'keratome';
    this.start_deg = 180;
    this.planned_deg = 180;
    this.angle_tol = 15;
    this.tunnel_lo = 1.75;
    this.tunnel_hi = 2.25;
    this.width = 2.4;
    this.advance_needed = 1.0;
  }

  enter() {
    super.enter();
    this.objectives[0].text = 'Masuk di limbus temporal (jam 9, ±15°)';
    this.hint = 'Keratome di limbus temporal. Dorong ke kanan sambil NAIKKAN sedikit (slider) mengikuti kubah kornea untuk terowongan ±2 mm.';
  }

  // sedikit OVD keluar saat insisi
  _onCreated() { this.cs.ovd_ac = Math.max(0, this.cs.ovd_ac - 0.08); }

  applyIdeal() {
    const inner = A.pointOnLimbus(180, A.corneaInnerY(3.6) - 0.05, 3.6);
    this.cs.addIncision('main', 180, 2.0, inner, 2.4);
  }
}
