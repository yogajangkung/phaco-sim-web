// Langkah 3 (OVD bilik depan) & 9 (OVD kantong kapsul).
import { StepBase, scoreBand } from '../core/step_base.js';
import { clamp } from '../core/math.js';

// Langkah 3 — Injeksi viskoelastik (OVD) ke bilik mata depan via side-port.
// Teknik baik: mulai dari sisi distal & dekat permukaan lensa, berhenti saat bilik dalam.
export class Step03Ovd extends StepBase {
  constructor() {
    super();
    this.title = '3. Injeksi Viskoelastik (OVD)';
    this.short_title = 'OVD';
    this.target_time = 30;
    this._inject_time = 0;
    this._distal_time = 0;
    this._peak = 0;
  }

  enter() {
    this.obj('fill', 'Isi bilik depan dengan OVD 90–110%');
    this.obj('depth', 'Bilik dalam & stabil (IOP 12–25 mmHg)');
    this.right_label = 'KANULA OVD';
    this.rig.insert('right', 'cannula', this.cs.getIncision('side'), 1.2);
    this.setActions([{ id: 'inject', label: 'Injeksi\nOVD' }]);
    this.hint = 'Bawa kanula ke sisi seberang (distal), dekat lensa, lalu TAHAN Injeksi sambil mundur perlahan.';
    this._inject_time = 0;
    this._distal_time = 0;
    this._peak = 0;
  }

  update(dt, input) {
    const cs = this.cs, t = this.rig.right;
    this.moveTool(t, input.rs, input.rd, dt, input.fine);
    if (this.held(input, 'inject')) {
      this._inject_time += dt;
      if (t.port && t.tip.distanceTo(t.port.inner) > 3.5) this._distal_time += dt;
      cs.ovd_ac = Math.min(cs.ovd_ac + 0.24 * dt, 1.4);
      cs.aqueous = Math.max(0.2, cs.aqueous - 0.25 * dt);
    }
    if (cs.ovd_ac > 1.12) {
      cs.ovd_ac = Math.max(1.12, cs.ovd_ac - 0.05 * dt);
      if (cs.iop > 28) this.comp.report('iop_high', `${cs.iop.toFixed(0)} mmHg`);
    }
    this._peak = Math.max(this._peak, cs.ovd_ac);
    this.fluidics.updatePassive(dt, cs);
    this.setDone('fill', cs.ovd_ac >= 0.9 && cs.ovd_ac <= 1.15, `${Math.floor(cs.ovd_ac * 100)}%`);
    this.setDone('depth', cs.iop >= 12 && cs.iop <= 25 && cs.chamber_depth > 0.85, `IOP ${cs.iop.toFixed(0)}`);
    t.updateVisual();
  }

  applyIdeal() {
    this.cs.ovd_ac = 1.0;
    this.cs.aqueous = 0.3;
  }

  computeQuality() {
    let q = scoreBand(this.cs.ovd_ac, 0.9, 1.1, 0.5, 1.4) * 0.6;
    const distal = this._distal_time / Math.max(this._inject_time, 0.01);
    q += clamp(distal / 0.5, 0, 1) * 40;
    if (distal < 0.3) this.note('Mulai injeksi OVD dari sisi distal agar aqueous tidak terperangkap.');
    if (this._peak > 1.2) this.note('OVD berlebih -> IOP tinggi; berhenti saat bilik sudah dalam.');
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() { return `OVD bilik depan: ${Math.floor(this.cs.ovd_ac * 100)}%`; }
}

// Langkah 9 — Mengisi kantong kapsul (dan bilik depan) dengan OVD sebelum implantasi IOL.
export class Step09OvdBag extends StepBase {
  constructor() {
    super();
    this.title = '9. Isi Kantong Kapsul dengan OVD';
    this.short_title = 'OVD Kantong';
    this.target_time = 30;
    this._peak = 0;
  }

  enter() {
    this.obj('bag', 'Kantong kapsul terisi OVD >= 85%');
    this.obj('ac', 'Bilik depan terisi OVD >= 60%');
    this.right_label = 'KANULA OVD';
    this.rig.insert('right', 'cannula', this.cs.getIncision('main'), 2.0);
    this.setActions([{ id: 'inject', label: 'Injeksi\nOVD' }]);
    this.hint = 'Masukkan kanula ke dalam kantong (lewat rhexis), injeksi untuk menggembungkan kantong, lalu isi bilik depan.';
    this._peak = 0;
  }

  update(dt, input) {
    const cs = this.cs, t = this.rig.right;
    this.moveTool(t, input.rs, input.rd, dt, input.fine);
    if (this.held(input, 'inject')) {
      if (t.in_bag) {
        cs.ovd_bag = Math.min(1.3, cs.ovd_bag + 0.32 * dt);
        cs.ovd_ac = Math.min(1.4, cs.ovd_ac + 0.05 * dt);
      } else {
        cs.ovd_ac = Math.min(1.4, cs.ovd_ac + 0.26 * dt);
      }
      cs.aqueous = Math.max(0.2, cs.aqueous - 0.2 * dt);
    }
    if (cs.ovd_ac > 1.12 && cs.iop > 28) this.comp.report('iop_high', `${cs.iop.toFixed(0)} mmHg`);
    this._peak = Math.max(this._peak, cs.ovd_ac);
    this.fluidics.updatePassive(dt, cs);
    this.setDone('bag', cs.ovd_bag >= 0.85, `${Math.floor(cs.ovd_bag * 100)}%`);
    this.setDone('ac', cs.ovd_ac >= 0.6, `${Math.floor(cs.ovd_ac * 100)}%`);
    t.updateVisual();
  }

  applyIdeal() {
    this.cs.ovd_bag = 1.0;
    this.cs.ovd_ac = 0.9;
  }

  computeQuality() {
    const q = scoreBand(this.cs.ovd_bag, 0.85, 1.1, 0.4, 1.4) * 0.6 + scoreBand(this.cs.ovd_ac, 0.6, 1.1, 0.2, 1.4) * 0.4;
    if (this._peak > 1.2) this.note('OVD berlebih -> IOP tinggi.');
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    return `OVD kantong: ${Math.floor(this.cs.ovd_bag * 100)}%\nOVD bilik depan: ${Math.floor(this.cs.ovd_ac * 100)}%`;
  }
}
