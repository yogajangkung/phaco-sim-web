import { Step01Preop } from './step_01_preop.js';
import { Step02Paracentesis, Step04MainIncision } from './step_02_04_incisions.js';
import { Step03Ovd, Step09OvdBag } from './step_03_09_ovd.js';
import { Step05Capsulorhexis } from './step_05_capsulorhexis.js';
import { Step06Hydro } from './step_06_hydro.js';
import { Step07Phaco } from './step_07_phaco.js';
import { Step08IaCortex } from './step_08_ia_cortex.js';
import { Step10Iol } from './step_10_iol.js';
import { Step11Closure } from './step_11_closure.js';

export const STEPS = [
  Step01Preop, Step02Paracentesis, Step03Ovd, Step04MainIncision, Step05Capsulorhexis,
  Step06Hydro, Step07Phaco, Step08IaCortex, Step09OvdBag, Step10Iol, Step11Closure,
];
