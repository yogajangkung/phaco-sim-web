// Langkah 1 — Pre-op: anestesi topikal, antiseptik, spekulum, sentrasi & fokus mikroskop.
import { StepBase } from '../core/step_base.js';
import { V2, clamp } from '../core/math.js';

export class Step01Preop extends StepBase {
  constructor() {
    super();
    this.title = '1. Pre-op: Anestesi, Spekulum & Sentrasi';
    this.short_title = 'Pre-op';
    this.target_time = 35;
    this._aligned = 0;
    this._order_error = false;
  }

  enter() {
    this.obj('anest', 'Teteskan anestesi topikal + povidone-iodine 5%');
    this.obj('spec', 'Pasang spekulum kelopak');
    this.obj('center', 'Sentrasi mikroskop di limbus (joystick KANAN)');
    this.obj('focus', 'Fokus & red reflex jelas (slider KANAN)');
    this.obj('pupil', 'Pupil cukup lebar (>= 6 mm)');
    this.setActions([
      { id: 'anest', label: 'Tetes\nAnestesi' },
      { id: 'spec', label: 'Pasang\nSpekulum' },
    ]);
    this.right_label = 'MIKROSKOP';
    this.left_label = '';
    this.hint = 'Geser mikroskop sampai kornea di tengah lingkaran, lalu atur fokus hingga red reflex terang.';
    this._aligned = 0;
    this._order_error = false;
  }

  update(dt, input) {
    const cs = this.cs;
    this.fluidics.updatePassive(dt, cs);
    if (this.pressed(input, 'anest') && !cs.anesthesia) {
      cs.anesthesia = true;
      this.setDone('anest');
    }
    if (this.pressed(input, 'spec') && !cs.speculum) {
      if (!cs.anesthesia) {
        this._order_error = true;
        this.note('Spekulum dipasang sebelum anestesi — pasien squeezing/tidak nyaman.');
      }
      cs.speculum = true;
      this.setDone('spec');
    }
    // joystick menggeser mikroskop: bayangan mata bergerak berlawanan
    const spd = input.fine ? 1.2 : 3.0;
    cs.scope_offset = cs.scope_offset.sub(input.rs.mul(spd * dt)).limitLength(6);
    cs.scope_focus = clamp(cs.scope_focus - input.rd * 4 * dt, -8, 8);

    const centered = cs.scope_offset.length() < 0.4;
    const focused = Math.abs(cs.scope_focus) < 0.45;
    this.setDetail('center', `offset ${cs.scope_offset.length().toFixed(1)} mm`);
    this.setDetail('focus', `defokus ${Math.abs(cs.scope_focus).toFixed(1)}`);
    if (centered && focused && cs.speculum) this._aligned += dt;
    else this._aligned = 0;
    if (this._aligned > 0.8) {
      this.setDone('center');
      this.setDone('focus');
    }
    this.setDone('pupil', cs.pupil_r >= 3.0, `${(cs.pupil_r * 2).toFixed(1)} mm`);
  }

  applyIdeal() {
    const cs = this.cs;
    cs.anesthesia = true;
    cs.speculum = true;
    cs.lid_open = 1;
    cs.scope_offset = new V2();
    cs.scope_focus = 0;
  }

  computeQuality() {
    let q = 100;
    if (this._order_error) q -= 20;
    q -= Math.abs(this.cs.scope_focus) * 10;
    q -= this.cs.scope_offset.length() * 15;
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    return `Offset mikroskop: ${this.cs.scope_offset.length().toFixed(2)} mm\nDefokus: ${Math.abs(this.cs.scope_focus).toFixed(2)}`;
  }
}
