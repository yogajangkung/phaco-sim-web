// IncisionStep — basis bersama untuk paracentesis & clear corneal incision (CCI).
//
//   * Pisau mulai di luar limbus. Melewati limbus (r ≤ 5.6 mm) di antara permukaan
//     epitel & endotel -> masuk stroma (fase "tunnel").
//   * Kubah kornea naik ke tengah: pisau sejajar iris menembus Descemet setelah ±1 mm.
//     Untuk terowongan lebih panjang (1.75–2.25 mm) pisau dinaikkan mengikuti kurvatura.
//   * Tembus endotel -> fase "ac". Setelah bahu pisau masuk penuh, TARIK PISAU.
//   * Pisau keluar dari epitel saat di stroma = button-hole.
import { StepBase, scoreBand } from '../core/step_base.js';
import { SafetyMonitor } from '../core/safety_monitor.js';
import * as A from '../core/anatomy.js';
import { V2, V3, clamp, deg2rad } from '../core/math.js';

export class IncisionStep extends StepBase {
  constructor() {
    super();
    this.inc_name = 'main';
    this.tool_kind = 'keratome';
    this.start_deg = 180;
    this.planned_deg = 180;
    this.alt_deg = -1;
    this.angle_tol = 15;
    this.tunnel_lo = 1.75;
    this.tunnel_hi = 2.25;
    this.width = 2.4;
    this.advance_needed = 1.0;
    this._phase = 'approach';
    this._entry = new V3();
    this._entry_deg = 0;
    this._inner = new V3();
    this._tunnel = 0;
    this._buttonhole = false;
    this._withdraw_t = 0;
    this._too_deep = false;
    this._lateral = 0;
  }

  enter() {
    this.obj('entry', 'Masuk di limbus pada meridian yang tepat');
    this.obj('tunnel', `Buat terowongan stroma ${this.tunnel_lo.toFixed(2)}–${this.tunnel_hi.toFixed(2)} mm`);
    this.obj('ac', 'Tembus ke bilik depan, masukkan bahu pisau penuh');
    this.obj('out', 'Tarik pisau keluar');
    this.right_label = 'PISAU';
    this.left_label = '';
    const t = this.rig.placeOutside('right', this.tool_kind, this.start_deg);
    t.tip.y = A.corneaOuterY(A.LIMBUS_R) - 0.3;
    this._phase = 'approach';
    this._tunnel = 0;
    this._buttonhole = false;
    this._too_deep = false;
    this._withdraw_t = 0;
    this._lateral = 0;
    this.setActions([]);
    this.hint = 'Arahkan pisau ke limbus (joystick kanan). Jaga ketinggian di tengah tebal kornea (slider kanan).';
  }

  _stromaBand(r) { return new V2(A.corneaInnerY(r), A.corneaOuterY(r)); }

  update(dt, input) {
    this.fluidics.updatePassive(dt, this.cs);
    const t = this.rig.right;
    const mv = SafetyMonitor.moveVector(input.rs, input.rd, dt, true);
    switch (this._phase) {
      case 'approach': {
        const p = t.tip.add(mv);
        const r = A.radial(p);
        const band = this._stromaBand(Math.min(r, A.LIMBUS_R));
        if (r <= A.LIMBUS_R) {
          if (p.y > band.y - 0.04) {
            // bertumpu di permukaan kornea, belum menembus
            p.y = band.y;
            const k = A.LIMBUS_R / Math.max(r, 0.001);
            p.x *= k; p.z *= k;
            this.hint = 'Pisau terlalu tinggi — turunkan sedikit agar masuk ke tengah stroma.';
          } else if (p.y < band.x + 0.04) {
            if (this.comp.report('iris_touch', 'masuk terlalu posterior')) this.haptics.touchTissue();
            const k2 = (A.LIMBUS_R + 0.05) / Math.max(r, 0.001);
            p.x *= k2; p.z *= k2;
            this.hint = 'Terlalu rendah (akar iris/sklera)! Naikkan pisau.';
          } else {
            this._entry = p.clone();
            this._entry_deg = A.meridianDeg(p);
            this._phase = 'tunnel';
            this.haptics.touchTissue();
            this.setDone('entry', true, A.clockHour(this._entry_deg));
            this.hint = 'Di dalam stroma. Dorong maju; naikkan sedikit untuk terowongan lebih panjang.';
          }
        }
        p.y = clamp(p.y, -1, 4);
        t.tip = p;
        t.approach_deg = A.meridianDeg(p);
        break;
      }
      case 'tunnel': {
        const p2 = t.tip.add(mv);
        const r2 = A.radial(p2);
        const band2 = this._stromaBand(r2);
        this._tunnel = Math.hypot(this._entry.x - p2.x, this._entry.z - p2.z);
        const ed = new V2(Math.cos(deg2rad(this._entry_deg)), Math.sin(deg2rad(this._entry_deg)));
        this._lateral = Math.max(this._lateral, Math.abs(ed.cross(new V2(p2.x, p2.z))));
        if (r2 > A.LIMBUS_R + 0.1) {
          this._phase = 'approach';
          this.setDone('entry', false);
        } else if (p2.y > band2.y - 0.05) {
          if (!this._buttonhole) {
            this._buttonhole = true;
            this.note('Button-hole: pisau keluar dari epitel. Jaga bidang pisau.');
            this.haptics.touchTissue();
          }
          p2.y = band2.y - 0.06;
        } else if (p2.y < band2.x) {
          // tembus Descemet -> bilik depan
          this._inner = p2.clone();
          this._phase = 'ac';
          if (this._tunnel < 0.35 && this.inc_name === 'main') {
            this.comp.report('descemet', `terowongan ${this._tunnel.toFixed(2)} mm`);
          }
          this.haptics.pulse(40, 0.7);
          this.setDone('tunnel', this._tunnel >= this.tunnel_lo * 0.6, `${this._tunnel.toFixed(2)} mm`);
          const inc = this.cs.addIncision(this.inc_name, this._entry_deg, this._tunnel, this._inner, this.width);
          t.port = inc;
          t.inside = true;
          this.hint = 'Masuk bilik depan. Majukan sedikit sampai bahu pisau masuk penuh, jangan sentuh iris/lensa.';
        }
        this.setDetail('tunnel', `${this._tunnel.toFixed(2)} mm`);
        t.tip = p2;
        break;
      }
      case 'ac': {
        this.safety.constrain(t, t.tip.add(mv), { dt });
        const adv = Math.hypot(this._inner.x - t.tip.x, this._inner.z - t.tip.z);
        this.setDetail('ac', `${adv.toFixed(1)} mm`);
        if (adv >= this.advance_needed) {
          this.setDone('ac', true);
          if (this.actions.length === 0) {
            this.setActions([{ id: 'withdraw', label: 'Tarik\nPisau' }]);
            this.hint = 'Bahu pisau sudah masuk. Tekan TARIK PISAU.';
          }
        }
        if (adv > this.advance_needed + 2 && !this._too_deep) {
          this._too_deep = true;
          this.note('Pisau masuk terlalu jauh ke bilik depan (risiko lensa/iris).');
        }
        if (this.pressed(input, 'withdraw') && this.isDone('ac')) {
          this._phase = 'withdraw';
          this.setActions([]);
        }
        break;
      }
      case 'withdraw': {
        this._withdraw_t += dt * 1.6;
        const out = A.pointOnLimbus(this._entry_deg, this._entry.y + 0.6, A.LIMBUS_R + 2.0);
        t.tip = t.tip.lerp(out, clamp(this._withdraw_t, 0, 1));
        if (this._withdraw_t >= 1) {
          this._phase = 'done';
          this.setDone('out');
          t.inside = false;
          this._onCreated();
          this.rig.remove('right');
          this.hint = 'Insisi selesai. Tekan LANJUT.';
        }
        break;
      }
    }
    t.updateVisual();
  }

  /** Efek insisi pada bilik. */
  _onCreated() {}

  _angleScore() {
    let d = A.angleDiff(this._entry_deg, this.planned_deg);
    if (this.alt_deg >= 0) d = Math.min(d, A.angleDiff(this._entry_deg, this.alt_deg));
    return scoreBand(d, 0, this.angle_tol, -1, this.angle_tol * 3);
  }

  computeQuality() {
    let q = this._angleScore() * 0.35
      + scoreBand(this._tunnel, this.tunnel_lo, this.tunnel_hi, this.tunnel_lo - 1.2, this.tunnel_hi + 1.5) * 0.45 + 20;
    if (this._buttonhole) q -= 15;
    if (this._too_deep) q -= 8;
    if (this._lateral > 0.8) {
      q -= 6;
      this.note('Pisau bergerak lateral di dalam terowongan (insisi melebar).');
    }
    if (this._tunnel < this.tunnel_lo) {
      this.note(`Terowongan pendek (${this._tunnel.toFixed(2)} mm): risiko bocor & prolaps iris.`);
    } else if (this._tunnel > this.tunnel_hi + 0.3) {
      this.note(`Terowongan panjang (${this._tunnel.toFixed(2)} mm): manuver sulit (oarlocking) & distorsi kornea.`);
    }
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    const t = this.rig.right;
    const r = A.radial(t.tip);
    const md = A.meridianDeg(t.tip);
    return `Meridian: ${A.clockHour(md)} (${md.toFixed(0)}°)\nTerowongan: ${this._tunnel.toFixed(2)} mm\n`
      + `Ketinggian pisau: ${(t.tip.y - A.corneaInnerY(Math.min(r, 7))).toFixed(2)} mm`;
  }
}
