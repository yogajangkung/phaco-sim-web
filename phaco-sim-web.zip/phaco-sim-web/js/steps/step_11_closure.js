// Langkah 11 — Aspirasi OVD (di depan & belakang IOL), hidrasi stroma luka, cek IOP & selesai.
// Penyederhanaan: aspirasi OVD di belakang IOL terjadi bila tip I/A di tepi optik
// (2.3–3.4 mm dari pusat IOL) & rendah, dipercepat dengan "Goyang IOL" (rock-and-roll).
import { StepBase, scoreBand } from '../core/step_base.js';
import { V2, clamp } from '../core/math.js';

export class Step11Closure extends StepBase {
  constructor() {
    super();
    this.title = '11. Aspirasi OVD, Hidrasi Luka & Selesai';
    this.short_title = 'Penutupan';
    this.target_time = 90;
    this._phase = 'ovd';
    this._iop_ok = 0;
    this._burps = 0;
  }

  enter() {
    this.obj('ovd_ac', 'Aspirasi OVD bilik depan');
    this.obj('ovd_bag', 'Aspirasi OVD di belakang IOL');
    this.obj('hyd_main', 'Hidrasi stroma luka utama');
    this.obj('hyd_side', 'Hidrasi stroma side-port');
    this.obj('iop', 'IOP akhir 14–22 mmHg, luka kedap');
    this._iop_ok = 0;
    this._burps = 0;
    this._setPhase('ovd');
  }

  _setPhase(ph) {
    this._phase = ph;
    this.phase = ph;
    this.rig.removeAll();
    if (ph === 'ovd') {
      this.uses_pedal = true;
      this.show_pedal_settings = true;
      this.fluidics.active = true;
      this.fluidics.applyPreset('OVD Removal');
      this.fluidics.bottle_cm = 75;
      this.right_label = 'I/A TIP';
      this.rig.insert('right', 'ia', this.cs.getIncision('main'), 2.0);
      this.setActions([{ id: 'rock', label: 'Goyang\nIOL' }]);
      this.hint = 'Pedal 2: aspirasi OVD di bilik depan, lalu di tepi optik/belakang IOL (Goyang IOL membantu).';
    } else if (ph === 'hydrate') {
      this.uses_pedal = false;
      this.show_pedal_settings = false;
      this.fluidics.active = false;
      this.right_label = 'KANULA BSS';
      this.rig.insert('right', 'cannula', this.cs.getIncision('side'), 1.2);
      this.setActions([{ id: 'inject', label: 'Injeksi\nBSS' }, { id: 'burp', label: 'Burp\nLuka' }]);
      this.hint = 'Arahkan kanula ke tepi stroma tiap luka (dekat insisi) & injeksi BSS sampai stroma memutih (kedap).';
    }
  }

  update(dt, input) {
    const cs = this.cs, t = this.rig.right, pedal = this.pedal;
    if (this._phase === 'ovd') {
      this.moveTool(t, input.rs, input.rd, dt, input.fine, { aspirating: pedal.aspirating() });
      this.fluidics.update(dt, pedal, cs, false);
      if (pedal.aspirating()) {
        const rate = (this.fluidics.flow / 40) * 0.4 * dt;
        const d = new V2(t.tip.x, t.tip.z).distanceTo(cs.iol_center);
        const low = t.tip.y < cs.iol_y + cs.diaphragmShift() + 0.7;
        if (d > 2.3 && d < 3.4 && low) {
          const rock = this.held(input, 'rock');
          cs.ovd_bag = Math.max(0, cs.ovd_bag - rate * 0.8 * (rock ? 2.2 : 1));
          if (rock) cs.zonular_stress += 0.01 * dt;
        } else {
          cs.ovd_ac = Math.max(0, cs.ovd_ac - rate);
        }
      }
      this.setDone('ovd_ac', cs.ovd_ac < 0.05, `${Math.floor(cs.ovd_ac * 100)}%`);
      this.setDone('ovd_bag', cs.ovd_bag < 0.05, `${Math.floor(cs.ovd_bag * 100)}%`);
      if (this.isDone('ovd_ac') && this.isDone('ovd_bag')) {
        cs.ovd_ac = 0;
        cs.ovd_bag = 0;
        cs.aqueous = 0.8;
        this._setPhase('hydrate');
      }
    } else if (this._phase === 'hydrate') {
      this.moveTool(t, input.rs, input.rd, dt, input.fine);
      let extra = 0;
      if (this.held(input, 'inject')) {
        let hydrated = false;
        for (const inc of cs.incisions) {
          const mid = inc.inner.add(inc.outer).mul(0.5);
          if (t.tip.distanceTo(inc.inner) < 1.2 || t.tip.distanceTo(mid) < 1.2) {
            inc.sealed = Math.min(1, inc.sealed + 0.55 * dt);
            hydrated = true;
          }
        }
        if (!hydrated) {
          extra = 22;
          cs.aqueous = Math.min(1, cs.aqueous + 0.25 * dt);
        } else {
          extra = 6;
          cs.aqueous = Math.min(1, cs.aqueous + 0.06 * dt);
        }
      }
      if (this.pressed(input, 'burp')) {
        this._burps++;
        cs.aqueous = Math.max(0.3, cs.aqueous - 0.25);
      }
      this.fluidics.updatePassive(dt, cs, extra);
      const mainS = cs.getIncision('main')?.sealed ?? 0;
      const sideS = cs.getIncision('side')?.sealed ?? 0;
      this.setDone('hyd_main', mainS >= 1, `${Math.floor(mainS * 100)}%`);
      this.setDone('hyd_side', sideS >= 1, `${Math.floor(sideS * 100)}%`);
      const iopOk = cs.iop >= 14 && cs.iop <= 22;
      if (iopOk && this.isDone('hyd_main') && this.isDone('hyd_side')) this._iop_ok += dt;
      else this._iop_ok = 0;
      if (cs.iop > 30) {
        this.comp.report('iop_high', `${cs.iop.toFixed(0)} mmHg`);
        this.hint = 'IOP tinggi — tekan Burp Luka untuk mengeluarkan sedikit cairan.';
      }
      this.setDone('iop', this._iop_ok > 1.2, `IOP ${cs.iop.toFixed(0)}`);
      if (this.isDone('iop')) this.hint = 'Luka kedap & IOP normal. Tekan SELESAI untuk debriefing.';
    }
    const tt = this.rig.right;
    if (tt.tool_type !== '') tt.updateVisual();
  }

  exit() {
    this.fluidics.active = false;
    super.exit();
  }

  applyIdeal() {
    const cs = this.cs;
    cs.ovd_ac = 0;
    cs.ovd_bag = 0;
    for (const inc of cs.incisions) inc.sealed = 1;
    cs.aqueous = 1;
  }

  computeQuality() {
    const cs = this.cs;
    let q = 30 * (1 - clamp(cs.ovd_bag + cs.ovd_ac, 0, 1));
    const sealed = cs.incisions.reduce((s, inc) => s + inc.sealed, 0);
    q += (40 * sealed) / Math.max(1, cs.incisions.length);
    q += scoreBand(cs.iop, 14, 22, 6, 35) * 0.3;
    if (cs.ovd_bag > 0.1) this.note('OVD tertinggal di belakang IOL -> risiko lonjakan IOP pasca-op (capsular bag distension).');
    return clamp(q - this.eventPenalty(), 0, 100);
  }

  telemetryExtra() {
    const cs = this.cs;
    let s = `Fase: ${this._phase.toUpperCase()}\nOVD bilik depan ${Math.floor(cs.ovd_ac * 100)}% · belakang IOL ${Math.floor(cs.ovd_bag * 100)}%\n`
      + `IOP: ${cs.iop.toFixed(0)} mmHg`;
    for (const inc of cs.incisions) s += `\nLuka ${inc.name}: ${Math.floor(inc.sealed * 100)}% kedap`;
    return s;
  }
}
