#!/usr/bin/env bash
# Server lokal untuk Phaco Sim 3D. Pemakaian: ./serve.sh [port]
PORT="${1:-8090}"
cd "$(dirname "$0")"
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "Laptop : http://localhost:${PORT}"
[ -n "$IP" ] && echo "HP/LAN : http://${IP}:${PORT}   (satu jaringan Wi-Fi)"
exec python3 -m http.server "$PORT" --bind 0.0.0.0
